Euronews addon for Kodi
======================

About
-----
Euronews, the most watched news channel in Europe, covers international news in various languages

Kodi Addon for http://www.euronews.com

This addon is not published nor endorsed by euronews.com


Artwork
---------------------
Artwork sourced from public domain:

http://logos.wikia.com/wiki/Euronews?file=Euronews_2016.png


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html