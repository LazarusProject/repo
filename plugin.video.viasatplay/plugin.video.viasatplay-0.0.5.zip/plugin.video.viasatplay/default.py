# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,requests,json

from resources.lib import cache, client, control

REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


viasat_play = 'http://www.viasat3.hu/viasat-play/minden-video'

def shows():
    shows = cache.get(getShows, 24, viasat_play)
    for item in shows:
        addDir3(item[0].encode('utf-8'), item[1], 1, '', 'http://cdn.sptndigital.com/sites/all/themes/responsive/responsive_viasat_pink/images/page-bg.jpg?1455931139', '0')
    return


def getShows(url):
    result = requests.get(url).content
    shows = client.parseDOM(result, 'form', attrs={'action': '/viasat-play/minden-video'})
    shows = client.parseDOM(shows, 'option'),client.parseDOM(shows, 'option', ret='value')
    shows = zip(shows[0], shows[1])
    shows = [i for i in shows if not i[1] == '']
    shows = list(set(shows))
    shows = sorted(shows, key=lambda tup:tup[0])
    return shows


def episodes():
    videos = cache.get(getEpisodes, 12, 'http://www.viasat3.hu/' + url + '?page=' + page)
    for item in videos[0]:
        try:
            title = client.parseDOM(item, 'h2', attrs={'class': 'title'})[0]
            link = client.parseDOM(item, 'a', ret='href')[0]
            img = client.parseDOM(item, 'img', attrs={'typeof': 'foaf:Image'}, ret='src')[0]
            duration = client.parseDOM(item, 'span', attrs={'class': 'hossz'})[0]
            duration = re.compile('/span>\s(.*)').findall(duration)[0]
            duration = duration.split(':')
            duration = str(int(duration[0]) * 60 + int(duration[1]))
            addDir4(title.encode('utf-8'), link, 2, img, fanart, duration)
        except:
            pass
    if not videos[1] =='0':
        addDir3('[COLOR green]''Következő oldal''[/COLOR]', url, 1, '', fanart, videos[1])
    return


def getEpisodes(url):
    result = requests.get(url).content
    #result = result.decode('iso-8859-1').encode('utf8')
    videos = client.parseDOM(result, 'div', attrs={'class': 'card video'})
    try:
        page = client.parseDOM(result, 'li', attrs={'class': 'pager-next first last'})[0]
        page = re.compile('page=([0-9]+)').findall(page)[0]
    except: page = ''
    if page == '': page = '0'
    
    return videos, page


def getvideo():
    try:
        headers = {'User-Agent': 'Apple-iPhone/701.341'}
        xbmc.executebuiltin('ActivateWindow(busydialog)')

        result = requests.get('http://www.viasat3.hu' + url, headers=headers).content
        
        if 'spt_video_gate_age_locked_form' in result:
            ret = control.yesnoDialog('Ennek a videónak a tartalma a kiskorúakra káros lehet.', ' Elmúltál 18 éves?', '')
            if ret == 0: return
            form = client.parseDOM(result, 'div', attrs={'class': 'terms active screen'})
            form = client.parseDOM(form, 'input', ret = 'value')
            form = [i for i in form if 'form-' in i][0]
            form = form.encode('utf-8')
            post = urllib.urlencode({'terms': '1', 'form_build_id': form, 'form_id': 'spt_video_gate_age_locked_form', '_triggering_element_name': 'op', '_triggering_element_value': 'Elküld'})
            result = client.request('http://www.viasat3.hu/system/ajax', post=post, headers=headers)
            result = json.loads(result)[1]['data']
        
        try: embed_url = client.parseDOM(result, 'iframe', ret='src')[-1]
        except: embed_url = client.parseDOM(result, 'meta', attrs={'name': 'twitter:player'}, ret='content')[0]
        
        result = requests.get(embed_url, headers=headers).content    
        
        source_url = client.parseDOM(result, 'link', attrs={'rel': 'alternate'}, ret='href')[0]
        result = requests.get(source_url, headers=headers).content
        result = client.parseDOM(result, 'media:group')[0]
        
        source_url = re.compile('url="?\'?([^"\'>]*)').findall(result)[0]
        source_url = source_url.replace(';','&')
        source_url = source_url + '&switch=http&formats=mpeg4&format=SMIL&embedded=true&tracking=true'

        result = requests.get(source_url, headers=headers).content
            
        direct_link = re.compile('video src="?\'?([^"\'>]*)').findall(result)[0]
        
        control.idle()
        
        videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels={'Title': name})
        xbmc.Player().play(direct_link, videoitem)
    except: 
        control.idle()
        return


def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Duration": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=urllib.unquote_plus(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
    shows()
elif mode==1:
    episodes()
elif mode==2:
    getvideo()
elif mode==3:
    cache.clear()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
