# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,requests

from resources.lib import cache, client

MAX_TRIES = 3

viasat_play = 'http://www.viasat3.hu/viasat-play/minden-video'

def shows():
    shows = cache.get(getShows, 24, viasat_play)
    for item in shows:
        addDir3(item[0].encode('utf-8'), item[1], 1, '', 'http://cdn.sptndigital.com/sites/all/themes/responsive/responsive_viasat_pink/images/page-bg.jpg?1455931139', '0')
    addDir4('[COLOR blue]''Gyorsítótár törlése''[/COLOR]', '0', 3, '', 'http://cdn.sptndigital.com/sites/all/themes/responsive/responsive_viasat_pink/images/page-bg.jpg?1455931139', '')
    return


def getShows(url):
    result = requests.get(url).content
    shows = client.parseDOM(result, 'form', attrs={'action': '/viasat-play/minden-video'})
    shows = client.parseDOM(shows, 'option'),client.parseDOM(shows, 'option', ret='value')
    shows = zip(shows[0], shows[1])
    shows = [i for i in shows if not i[1] == '']
    shows = list(set(shows))
    shows = sorted(shows, key=lambda tup:tup[0])
    return shows


def episodes():
    videos = cache.get(getEpisodes, 12, 'http://www.viasat3.hu/' + url + '?page=' + page)
    for item in videos[0]:
        try:
            title = client.parseDOM(item, 'h2', attrs={'class': 'title'})[0]
            link = client.parseDOM(item, 'a', ret='href')[0]
            img = client.parseDOM(item, 'img', attrs={'typeof': 'foaf:Image'}, ret='src')[0]
            duration = client.parseDOM(item, 'span', attrs={'class': 'duration'})[0]
            duration = re.compile('/span>\s(.*)').findall(duration)[0]
            duration = duration.split(':')
            duration = str(int(duration[0]) * 60 + int(duration[1]))
            addDir4(title.encode('utf-8'), link, 2, img, fanart, duration)
        except:
            pass
    if not videos[1] =='0':
        addDir3('[COLOR green]''Következő oldal''[/COLOR]', url, 1, '', fanart, videos[1])
    return


def getEpisodes(url):
    result = requests.get(url).content
    #result = result.decode('iso-8859-1').encode('utf8')
    videos = client.parseDOM(result, 'div', attrs={'class': 'card video'})
    try:
        page = client.parseDOM(result, 'li', attrs={'class': 'pager-next first last'})[0]
        page = re.compile('page=([0-9]+)').findall(page)[0]
    except: page = ''
    if page == '': page = '0'
    
    return videos, page


def getvideo():
    tries = 0
    while tries < MAX_TRIES:
        try:
            xbmc.executebuiltin('ActivateWindow(busydialog)')
            result = cache.get(getVideoLink, 24, 'http://www.viasat3.hu' + url)
            
            source_url = re.compile('url="?\'?([^"\'>]*)').findall(result)[0]
            q_list = re.compile('height="([0-9]+)').findall(result)
            if len(q_list) > 1: q_list = sorted(q_list, key=int, reverse=True)
            q_list = [i+'p' for i in q_list]
            bitrates = re.compile('bitrate="([0-9]+)').findall(result)
            source_url = source_url.replace(';','&')
            source_url = source_url + '&manifest=f4m&format=SMIL&Tracking=true&Embedded=true&formats=F4M,MPEG4'
            result = requests.get(source_url).content
            
            direct_link = re.compile('video src="?\'?([^"\'>]*)').findall(result)[0]
            direct_link = direct_link.replace(';','&')
            if not 'hdcore' in direct_link: direct_link = direct_link + '&hdcore=3.5.0'
                
            #bitrates = client.request(direct_link)
            #bitrates = client.parseDOM(bitrates, 'media', ret='bitrate')
            if len(bitrates) > 1: bitrates = sorted(bitrates, key=int, reverse=True)
                
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            if len(bitrates) > 1:
                dialog = xbmcgui.Dialog()
                q = dialog.select('Minőség', q_list)
                if q == -1: return
                bitrate = bitrates[q]
            else: bitrate = '0'
            playF4mLink(direct_link,name,int(bitrate))
            break
        except: 
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            tries += 1

def getVideoLink(url):
    result = requests.get(url).content
    try: embed_url = client.parseDOM(result, 'iframe', ret='src')[0]
    except: embed_url = client.parseDOM(result, 'meta', attrs={'name': 'twitter:player'}, ret='content')[0]
    result = requests.get(embed_url).content    
    source_url = client.parseDOM(result, 'link', attrs={'rel': 'alternate'}, ret='href')[0]
    result = requests.get(source_url).content
    result = client.parseDOM(result, 'media:group')[0]

    return result


def playF4mLink(url,name,maxbitrate,proxy=None,use_proxy_for_chunks=False,auth_string=None,streamtype='HDS',setResolved=False,swf=""):
    from F4mProxy import f4mProxyHelper
    player=f4mProxyHelper()

    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
    player.playF4mLink(url, name, proxy, use_proxy_for_chunks,maxbitrate,simpleDownloader,auth_string,streamtype,setResolved,swf)
    
    return 

def clearCache():
    cache.clear()


def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Duration": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
page=None
maxbitrate=0
simpleDownloader=False

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=urllib.unquote_plus(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
    shows()
elif mode==1:
    episodes()
elif mode==2:
    getvideo()
elif mode==3:
    clearCache()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
