# -*- coding: utf-8 -*-

### AdflyUrlGrabber ###
#Author:D4Vinci
#rewrited by MGF15
#algorithm from StoreClerk


def adfly_crack(code):
	import base64

	zeros = ''
	ones = ''
	for n,letter in enumerate(code):
		if n % 2 == 0:
			zeros += code[n]
		else:
			ones = code[n] + ones
	key = zeros + ones
	key = list(key)
	i = 0
	while i < len(key):
		if key[i].isdigit():
			for j in range(i+1,len(key)):
				if key[j].isdigit():
					u = int(key[i])^int(key[j])
					if u < 10:
						key[i] = str(u)
					i = j					
					break
		i+=1
	key = ''.join(key).decode('base64')[16:-16]
	return key


def changelog_textbox():
    try:
        import os, xbmc, xbmcgui, xbmcaddon, xbmcvfs

        path = xbmcaddon.Addon().getAddonInfo('path').decode('utf-8')

        logfile = xbmcvfs.File(os.path.join(path, 'changelog.txt'))
        text = logfile.read()
        logfile.close()

        dialog = xbmcgui.Dialog()
        dialog.textviewer(xbmc.getLocalizedString(24036), text)
        return
    except:
        return