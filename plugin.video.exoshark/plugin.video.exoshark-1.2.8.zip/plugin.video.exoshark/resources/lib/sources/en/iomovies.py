# -*- coding: utf-8 -*-

'''
    ExoShark Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re, urllib, urlparse
import HTMLParser
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import cfscrape
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['oakmovies.com', 'ionlinemovies.com']
        self.base_link = 'http://oakmovies.com'
        self.search_link = '/?s=%s'
        self.scraper = cfscrape.create_scraper()
        self.useragent = 'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = cleantitle.getsearch(title)
            start_url = urlparse.urljoin(self.base_link, self.search_link % search_id.replace(' ', '+'))
            headers = {'User_Agent': self.useragent}
            html = self.scraper.get(start_url, headers=headers).content
            Regex = re.compile('data-movie-id=.+?href="(.+?)".+?class="mli-info"><h2>(.+?)</h2>.+?rel="tag">(.+?)</a></div>',re.DOTALL).findall(html)
            for url, name, date in Regex:
                if cleantitle.get(title) == cleantitle.get(name) and year == date:
                    url = url.encode('utf-8')
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources

            html = self.scraper.get(url).content
            source = re.compile('<iframe.+?src="(.+?)"', re.DOTALL).findall(html)[0]
            if 'consistent.stream' in source:
                headers = {'User_Agent': self.useragent}
                holder = client.request(source, headers=headers)
                page = re.compile(""":title=["'](.+?)["']\>""").findall(holder)[0]
                decode = HTMLParser.HTMLParser().unescape(page)
                items = re.compile('"src":"([^"]+)"', re.DOTALL).findall(decode)
                items = [i.replace('\\/', '/') for i in items]

                for item in items:
                    try:
                        if '1080p' in item: quality = '1080p'
                        elif '720p' in item: quality = '720p'
                        elif '.ts.' in item or 'cam' in item: quality = 'CAM'
                        else: quality = 'SD'
                        valid, hoster = source_utils.is_host_valid(item, hostDict)
                        urls, host, direct = source_utils.check_directstreams(item, hoster)
                        if valid:
                            for x in urls: sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': x['url'], 'direct': direct, 'debridonly': False})
                        else:
                            sources.append({'source': 'CDN', 'quality': quality, 'language': 'en', 'url': item, 'direct': True, 'debridonly': False})
                    except:
                        pass
            return sources
        except:
            return sources


    def resolve(self, url):
        return url
