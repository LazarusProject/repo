# -*- coding: utf-8 -*-

### AdflyUrlGrabber ###
#Author:D4Vinci
#rewrited by MGF15
#algorithm from StoreClerk


def adfly_crack(code):
	import base64

	zeros = ''
	ones = ''
	for n,letter in enumerate(code):
		if n % 2 == 0:
			zeros += code[n]
		else:
			ones = code[n] + ones
	key = zeros + ones
	key = list(key)
	i = 0
	while i < len(key):
		if key[i].isdigit():
			for j in range(i+1,len(key)):
				if key[j].isdigit():
					u = int(key[i])^int(key[j])
					if u < 10:
						key[i] = str(u)
					i = j
					break
		i+=1
	key = ''.join(key).decode('base64')[16:-16]
	return key


def captcha_resolve(response, cap_cookie):
    try:
        import os
        from resources.lib.modules import client
        from resources.lib.modules import control

        i = os.path.join(control.dataPath,'img')
        f = control.openFile(i, 'w')
        f.write(client.request(response, cookie=cap_cookie))
        f.close()
        f = control.image(450,5,375,115, i)
        d = control.windowDialog
        d.addControl(f)
        control.deleteFile(i)
        d.show()
        t = ''
        k = control.keyboard('', t)
        k.doModal()
        c = k.getText() if k.isConfirmed() else None
        if c == '': c = None
        d.removeControl(f)
        d.close()
        return c
    except:
        return


def changelog_textbox():
    try:
        import os, xbmc, xbmcgui, xbmcaddon, xbmcvfs

        path = xbmcaddon.Addon().getAddonInfo('path').decode('utf-8')

        logfile = xbmcvfs.File(os.path.join(path, 'changelog.txt'))
        text = logfile.read()
        logfile.close()

        dialog = xbmcgui.Dialog()
        dialog.textviewer(xbmc.getLocalizedString(24036), text)
        return
    except:
        return


def check_subtitle(tvshowtitle, year, season, episode):
    try:
        from resources.lib.modules import client
        from resources.lib.modules import control
        import urllib, xbmcgui, json, re

        tvshowtitle = re.sub('(\(\d{4}\))', '', tvshowtitle)
        tvshowtitle = tvshowtitle.strip()
        tvshowtitle2 = re.sub('\'', '’', tvshowtitle)
        titl = urllib.quote_plus(tvshowtitle)
        titl2 = urllib.quote_plus(tvshowtitle2)
        t = '%s (%s)' % (tvshowtitle, year)
        t2 = '%s (%s)' % (tvshowtitle2, year)

        tvdb_url = 'http://thetvdb.com/api/GetSeries.php?seriesname=%s' % (titl)
        supersub_url = 'https://www.feliratok.info'
        search_url = '/index.php?term=%s&nyelv=0&action=autoname'
        ssub_url = '/index.php?search=&nyelv=Magyar&sid=%s&complexsearch=true&evad=%s&epizod1=%s&evadpakk=%s&tab=all'

        subt_url0 = supersub_url + search_url % (titl)
        r = client.request(subt_url0)
        if 'Nincs tal\u00e1lat' in r:
            if not titl == titl2:
                subt_url0 = supersub_url + search_url % (titl2)
                r = client.request(subt_url0)
                if 'Nincs tal\u00e1lat' in r:
                    control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                    return
            else:
                control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                return
        subs = re.findall('\{[^\{\}]+\}', r)
        tvshow_id = ''

        for item in subs:
            name = json.loads(item)['name']
            name2 = re.sub('(\s*\([A-Z]{2}\))', '', name)
            name2 = name2.strip()
            if name.lower() == t.lower() or name2.lower() == t.lower():
                tvshow_id = json.loads(item)['ID']
            if name.lower() == t2.lower() or name2.lower() == t2.lower():
                tvshow_id = json.loads(item)['ID']

        if tvshow_id == '':
            r = client.request(tvdb_url, timeout='10')
            r = client.parseDOM(r, 'Series')
            r = [i for i in r if 'FirstAired>%s' % year in i]
            if len(r) == 0:
                control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                return
            try:
                aliasname = client.parseDOM(r, 'AliasNames')[0]
            except:
                control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
                return
            t = '%s (%s)' % (aliasname, year)
            for item in subs:
                name = json.loads(item)['name']
                name2 = re.sub('(\s*\([A-Z]{2}\))', '', name)
                name2 = name2.strip()
                if name.lower() == t.lower() or name2.lower() == t.lower():
                    tvshow_id = json.loads(item)['ID']
                if name.lower() == t2.lower() or name2.lower() == t2.lower():
                    tvshow_id = json.loads(item)['ID']

        if tvshow_id == '':
            control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
            return

        subt_url = supersub_url + ssub_url % (tvshow_id, season, episode, '0')
        subt_r = client.request(subt_url)
        subt_o = re.findall('(?s)<div class="eredeti">[^<>]+<\/div>.+?<td align="center"[^<>]+>\s*(.+?)\s*<\/td>\s*<td align[^<>]+>\s*\d{4}-\d{2}-\d{2}', subt_r)
        subt_m = re.findall('<div class="eredeti">([^"]+)<\/div>', subt_r)
        if len(subt_m) == 0:
            subt_url = supersub_url + ssub_url % (tvshow_id, season, episode, 'on')
            subt_r = client.request(subt_url)
            subt_o = re.findall('(?s)<div class="eredeti">[^<>]+<\/div>.+?<td align="center"[^<>]+>\s*(.+?)\s*<\/td>\s*<td align[^<>]+>\s*\d{4}-\d{2}-\d{2}', subt_r)
            subt_m = re.findall('<div class="eredeti">([^"]+)<\/div>', subt_r)
            subt_m = [u'[\u00C9vadpakk] ' + i for i in subt_m]
        if len(subt_m) == 0:
            control.infoDialog(u'Nincs el\u00E9rhet\u0151 magyar felirat', sound=True, icon='INFO')
            return

        subt = ['%s - (%s)' % (i, j) for i, j in zip(subt_m, subt_o)]
        subtext_r = '[CR]===================================================[CR][B][Magyar felirat][/B] '.join(subt)
        subtext = u'[COLOR lawngreen][B]%s SuperSubtitles felirat el\u00E9rhet\u0151:[/B][/COLOR][CR][B][Magyar felirat][/B] %s' % (len(subt), subtext_r)
        subtext = re.sub('<.+?>', '', subtext)
        try:
            subtext = subtext.encode('utf-8')
        except:
            pass

        subtitle_dialog = xbmcgui.Dialog()
        subtitle_dialog.textviewer('Feliratok', subtext)
        return
    except:
        return


def movierls(title, year):
    try:
        from resources.lib.modules import client
        from resources.lib.modules import cleantitle
        from resources.lib.modules import control
        import xbmcgui, re

        dvdrls_url = 'https://www.newdvdreleasedates.com'
        search_url = '/ajaxsearch.php?q=%s'

        t = title.replace(' ', '%20')
        query = dvdrls_url + search_url % t
        r = client.request(query)
        result = re.findall('(<a.+?>.+?<\/a>)', r)

        result = [(client.parseDOM(i, 'a')[0], client.parseDOM(i, 'a', ret = 'href')[0]) for i in result]
        result = [i[1] for i in result if cleantitle.get(title) == cleantitle.get(i[0].rsplit('(%s' % year, 1)[0].strip().encode('utf-8')) and year in i[0]]
        if not len(result) == 1:
            control.infoDialog(u'Nem tal\u00E1lhat\u00F3 inform\u00E1ci\u00F3 a megjelen\u00E9sekr\u0151l', sound=True, icon='INFO')
            return

        r1 = client.request(dvdrls_url + result[0])
        items_table = client.parseDOM(r1, 'table')[0]
        items = re.findall('<span class=\'name\'>([^<>]+)<.+?((?:Digital (?:<\/span>)Download|DVD rental|DVD.+?Blu-ray.+?4K|DVD.+?Blu-ray|DVD|Blu-ray|4K|not available)).+?(\w+\s*\d{1,2},\s*\d{4}).+?<\/tr>', items_table)
        if items == []:
            control.infoDialog(u'Nem tal\u00E1lhat\u00F3 inform\u00E1ci\u00F3 a megjelen\u00E9sekr\u0151l', sound=True, icon='INFO')
            return

        releases = []

        monthDict = {'January': u'janu\u00E1r',
                     'February': u'febru\u00E1r',
                     'March': u'm\u00E1rcius',
                     'April': u'\u00E1prilis',
                     'May': u'm\u00E1jus',
                     'June': u'j\u00FAnius',
                     'July': u'j\u00FAlius',
                     'August': 'augusztus',
                     'September': 'szeptember',
                     'October': u'okt\u00F3ber',
                     'November': 'november',
                     'December': 'december'}

        for hoster, media, date in items:
            try:
                media = re.sub('<.+?>', '', media)
                if 'dvd' in media.lower() and 'blu-ray' in media.lower() and '4k' in media.lower(): media = 'DVD, BLU-RAY, 4K'
                elif 'dvd' in media.lower() and 'blu-ray' in media.lower() and not '4k' in media.lower(): media = 'DVD, BLU-RAY'
                elif 'digital download' in media.lower(): media = 'VOD'
                elif 'dvd rental' in media.lower(): media = u'K\u00F6lcs\u00F6n\u00F6zhet\u0151 DVD'
                elif 'not available' in media.lower(): media = u'Nem el\u00E9rhet\u0151'
                date = date.replace(',', '').split(' ')
                month = monthDict[date[0]]
                date = '%s. %s %s.' % (date[2], month, date[1])
                text = u'[B]%s[/B] | %s\nMegjelen\u00E9s: %s' % (hoster.strip(), media.strip(), date.strip())
                releases.append(text)
            except:
                control.infoDialog(u'Nem tal\u00E1lhat\u00F3 inform\u00E1ci\u00F3 a megjelen\u00E9sekr\u0151l', sound=True, icon='INFO')
                return

        rlstext = '[CR][CR]'.join(releases)

        try:
            rlstext = rlstext.encode('utf-8')
        except:
            pass

        rls_dialog = xbmcgui.Dialog()
        rls_dialog.textviewer(u'Megjelen\u00E9sek', rlstext)
        return
    except:
        control.infoDialog(u'Nem tal\u00E1lhat\u00F3 inform\u00E1ci\u00F3 a megjelen\u00E9sekr\u0151l', sound=True, icon='INFO')
        return


def imdbinfo(imdbid):
    try:
        from resources.lib.modules import control
        from resources.lib.modules import client
        import re, HTMLParser, xbmc, xbmcgui

        xbmc.executebuiltin( "ActivateWindow(busydialog)" )

        html = client.request('http://www.imdb.com/title/%s/' % imdbid)
        html = HTMLParser.HTMLParser().unescape(html)

        title = client.parseDOM(html, 'h1')[0]
        title = re.sub('(?s)(<.+)', '', title)
        rating = client.parseDOM(html, 'span', attrs={'itemprop': 'ratingValue'})[0]
        votes = client.parseDOM(html, 'span', attrs={'itemprop': 'ratingCount'})[0]
        try:
            rated = client.parseDOM(html, 'span', attrs={'itemprop': 'contentRating'})[0]
        except:
            rated = 'Nincs'
        desc = client.parseDOM(html, 'div', attrs={'itemprop': 'description'})[0]
        desc = re.sub('(?s)(<[^<>]+>)', '', desc)
        genre = client.parseDOM(html, 'span', attrs={'itemprop': 'genre'})
        genr = ', '.join(genre)
        imdbtext = u'[B]%s[/B] | %s\n\n\u00C9rt\u00E9kel\u00E9s: %s (%s szavazat alapj\u00E1n)\nKorhat\u00E1r-besorol\u00E1s: %s\n\nBevezet\u0151:\n%s' \
                    % (title.strip(), genr.strip(), rating.strip(), votes.strip(), rated.strip(), desc.strip())
        try: imdbtext = imdbtext.encode('utf-8')
        except: pass

        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        imdb_dialog = xbmcgui.Dialog()
        imdb_dialog.textviewer(u'IMDb Inf\u00F3', imdbtext)
    except:
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        control.infoDialog(u'Az IMDb adatlap nem el\u00E9rhet\u0151', sound=True, icon='INFO')
        return
