# -*- coding: utf-8 -*-

### AdflyUrlGrabber ###
#Author:D4Vinci
#rewrited by MGF15
#algorithm from StoreClerk

import base64

def adfly_crack(code):
	zeros = ''
	ones = ''
	for n,letter in enumerate(code):
		if n % 2 == 0:
			zeros += code[n]
		else:
			ones = code[n] + ones
	key = zeros + ones
   
	key = list(key)

	i = 0

	while i < len(key):

		if key[i].isdigit():

			for j in range(i+1,len(key)):

				if key[j].isdigit():
                    
					u = int(key[i])^int(key[j])
                    
					if u < 10:
                        
						key[i] = str(u)
                        
					i = j					
					break
		i+=1

	key = ''.join(key).decode('base64')[16:-16]

	return key