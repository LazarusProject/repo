# -*- coding: utf-8 -*-

import re,urllib,urlparse
from resources.lib.modules import cleantitle
from resources.lib.modules import client


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['hu']
        self.domains = ['m.filmgo.cc']
        self.base_link = 'https://m.filmgo.cc'
        self.host_link = 'http://www.linkadatbazis.xyz'
        self.search_link = '/search.php?query=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            query = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(localtitle))
            r = client.request(query)
            result = re.sub('(?s)(.*?<\/h1>)', '', r)
            result = result.split('</a>')

            result = [i for i in result if self.host_link + '/test/' in i]
            result = [(re.findall('<b>([^<>]+)<\/b>', i)[0], i) for i in result]
            result = [(cleantitle.get(i[0]), i[1]) for i in result]
            result = [i[1] for i in result if cleantitle.get(localtitle) == cleantitle.get(i[0].encode('utf-8'))]
            if len(result) == 0: raise Exception()

            result = [i for i in result if re.findall('<\/b>\s*\((\d{4})\)\s*<', i)[0] == year in i]
            urlr = client.parseDOM(result, 'a', ret='href')[0]
            urlr = urlr.rsplit('film_id=', 1)[1]
            url = self.host_link + '/link/link.php?links=' + urlr
            url = url.encode('utf-8')

            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url == None: return sources

            r = client.request(url)
            if not '"lejatszas">' in r: raise Exception()

            items = client.parseDOM(r, 'table', attrs={'class': 'links'})[0]
            items = re.findall('(?s)flag\/(.+?)\..+?b>\s*(.+?)\s*<.+?">\s*(.+?)\s*<.+?url\/(\w+\:\/\/.+?)">', items)

            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]

            for item in items:
                try:
                    host = item[1].split('.', 1)[0].strip().lower()
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()
                    host = host.encode('utf-8')
                    info = 'szinkron' if item[0] == 'hu-hu' or item[0] == 'lt' else ''
                    q = item[2].lower()
                    if q == 'hd': quality = 'HD'
                    elif 'cam' in q or 'ts' in q or q == 'mozis': quality = 'CAM'
                    else: quality = 'SD'
                    url = client.replaceHTMLCodes(item[3])
                    url = url.encode('utf-8')
                    sources.append({'source': host, 'quality': quality, 'language': 'hu', 'info': info, 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass

            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            result = client.request(url)
            try: url = client.parseDOM(result, 'iframe', ret='src')[0]
            except: url = client.parseDOM(result, 'IFRAME', ret='SRC')[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except:
            return
