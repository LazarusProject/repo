# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, urlparse
from resources.lib import client

REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)

ehftv_url = 'http://www.ehftv.com/'

def mainPage():
    r = client.request(ehftv_url)
    result = client.parseDOM(r, 'div', attrs={'class':'schedule'})
    result = client.parseDOM(result, 'li', attrs={'class':'clearfix'})
    
    addDir('[B][COLOR green]VIDEOS[/COLOR][/B]', ehftv_url, 1, '', '', '')
    
    for i in result:
        try:
            url = client.parseDOM(i, 'a', ret = 'href')[0]
            url = url.encode('utf-8')

            img = client.parseDOM(i, 'img', ret = 'src')[0]
            img = img.encode('utf-8')
            img = urlparse.urljoin(ehftv_url, img)
            
            title = client.parseDOM(i, 'h4')[0]
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            time = client.parseDOM(i, 'h5')[0]
            time = client.replaceHTMLCodes(time)
            time = time.encode('utf-8')
            
            teams = client.parseDOM(i, 'h3')[0]
            teams = client.replaceHTMLCodes(teams)
            teams = teams.encode('utf-8')
            
            if '>Now Live<' in i:
                live = '[B][COLOR red]LIVE [/COLOR][/B]'
                m = 3
            else: 
                live = ''
                m = 0
            addFile(live + time + ' | ' + teams + ' | ' + title, url, m, img, '', '')
        except:
            pass


def getVideos():
    r = client.request(ehftv_url)
    
    try: portal = re.search('portal-hidden"\s*value\s*=\s*"([a-z]+)"', r).group(1)
    except: portal = 'int'
    
    videos = client.parseDOM(r, 'ul', attrs={'class':'droptabs'})[0]
    videos = videos.replace('\n', '')
    videos = client.parseDOM(videos, 'li')
    for i in videos:
        try:
            title = client.parseDOM(i, 'a')[0].strip()
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            id = client.parseDOM(i, 'a', ret = 'href')[0]
            id = id.split("'")
            id = [i for i in id if bool(re.search(r'\d', i)) == True]
            if len(id) < 4: id = ['0','0','0','0']
            url = 'http://www.ehftv.com/ajax.php?cmd=filterSelectMediatype&filter_id=%s&_mediatyp=%s&_stage=%s&_cat_3=%s&pagetype=home&portal=%s' % (id[0], id[1], id[2], id[3], portal)
            addDir(title, url, 2, '', '', '')
        except:
            pass


def getEpisodes():
    r = client.request(url)
    episodes = client.parseDOM(r, 'div', attrs={'class':'teaser'})
    for i in episodes:
        try:
            link = client.parseDOM(i, 'a', ret = 'href')[0]
            link = link.encode('utf-8')
            
            img = client.parseDOM(i, 'img', ret = 'src')[0]
            img = img.encode('utf-8')
            
            title = client.parseDOM(i, 'div', attrs={'class':'category'})[0]
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            teams = client.parseDOM(i, 'h3')[0]
            teams = re.search('([^<]+)', teams).group(1)
            teams = client.replaceHTMLCodes(teams)
            teams = teams.strip().encode('utf-8')
            
            time = client.parseDOM(i, 'time', ret = 'datetime')[0]
            time = time.encode('utf-8')
            addFile(time + ' | ' + teams + ' | ' + title, link, 3, img, '', '')
        except:
            pass

 
def getVideo():
    try:
        query = urlparse.urljoin(ehftv_url, url)
        result = client.request(query)
        
        available = client.parseDOM(result, 'div', attrs={'class':'row'})[-1]
        if '<span class="no">' in available:
            xbmcgui.Dialog().ok('ehfTV', 'Due to existing TV rights it is not possible to broadcast this stream in your country.')
            return
        
        result = client.parseDOM(result, 'div', attrs={'class':'player-wrapper'})
        
        query = client.parseDOM(result, 'iframe', ret = 'src')[0]
        
        streamid = urlparse.parse_qs(query)['/player.php?play'][0]
        
        query = urlparse.urljoin(ehftv_url, query)
        result = client.request(query)
        
        label = re.search('var label\s*=\s*"([^"]+)', result).group(1)
        
        for match in re.finditer('url\s*:\s*["|\'](.+?)["\'],', result):
            if streamid in match.group(1): query = match.group(1)
        if not query.startswith('http'): query = 'http:' + query
        query = query.replace('" + label + "', label)
        
        result = client.request(query, mobile = True)
        
        link = client.parseDOM(result, 'token', ret = 'url')[0]
        auth = client.parseDOM(result, 'token', ret = 'auth')[0]
        
        direct_link = link + '?hdnea=' + auth
        
        videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels={'Title': name})
        xbmc.Player().play(direct_link, videoitem)
    except:
        return


def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def addDir(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass


if mode==None:
    mainPage()
elif mode==0:
    'no stream'
elif mode==1:
    getVideos()
elif mode==2:
    getEpisodes()
elif mode==3:
    getVideo()


xbmcplugin.endOfDirectory(int(sys.argv[1]))