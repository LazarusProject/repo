# -*- coding: utf-8 -*-
import sys, xbmc, xbmcgui, urllib, re, xbmcplugin, urlparse, json
from resources.lib import client
from resources.lib import control

ehftv_url = 'http://www.ehftv.com'

def mainPage():
    r = client.request(ehftv_url)
    result = client.parseDOM(r, 'div', attrs={'class':'schedule'})
    result = client.parseDOM(result, 'li', attrs={'class':'clearfix'})
    
    addDir('[B][COLOR green]VIDEOS[/COLOR][/B]', ehftv_url, 1, '', '', '')
    
    for i in result:
        try:
            url = client.parseDOM(i, 'a', ret = 'href')[0]
            url = url.encode('utf-8')

            img = client.parseDOM(i, 'img', ret = 'src')[0]
            img = img.encode('utf-8')
            img = urlparse.urljoin(ehftv_url, img)
            
            title = client.parseDOM(i, 'h4')[0]
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            time = client.parseDOM(i, 'h5')[0]
            time = client.replaceHTMLCodes(time)
            time = time.encode('utf-8')
            
            teams = client.parseDOM(i, 'h3')[0]
            teams = client.replaceHTMLCodes(teams)
            teams = teams.encode('utf-8')
            
            if '>Now Live<' in i:
                live = '[B][COLOR red]LIVE[/COLOR][/B]'; m = 3; pl = True
            else: 
                live = ''; m = 0; pl = False
            addFile('%s %s | [B][COLOR white]%s[/COLOR][/B] | [COLOR blue]%s[/COLOR]' % (live, time, teams, title), url, m, img, '', '', IsPlayable = pl)
        except:
            pass


def getVideos():
    r = client.request(ehftv_url)
    
    try: portal = re.search('portal-hidden"\s*value\s*=\s*"([a-z]+)"', r).group(1)
    except: portal = 'int'
    
    videos = client.parseDOM(r, 'ul', attrs={'class':'droptabs'})[0]
    videos = videos.replace('\n', '')
    videos = client.parseDOM(videos, 'li')
    for i in videos:
        try:
            title = client.parseDOM(i, 'a')[0].strip()
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            id = client.parseDOM(i, 'a', ret = 'href')[0]
            id = id.split("'")
            id = [i for i in id if bool(re.search(r'\d', i)) == True]
            if len(id) < 4: id = ['0','0','0','0']
            url = 'http://www.ehftv.com/ajax.php?cmd=filterSelectMediatype&filter_id=%s&_mediatyp=%s&_stage=%s&_cat_3=%s&pagetype=home&portal=%s' % (id[0], id[1], id[2], id[3], portal)
            addDir(title, url, 2, '', '', '')
        except:
            pass


def getEpisodes():
    r = client.request(url)
    episodes = client.parseDOM(r, 'div', attrs={'class':'teaser'})
    for i in episodes:
        try:
            link = client.parseDOM(i, 'a', ret = 'href')[0]
            link = link.encode('utf-8')
            
            img = client.parseDOM(i, 'img', ret = 'src')[0]
            img = img.encode('utf-8')
            
            title = client.parseDOM(i, 'div', attrs={'class':'category'})[0]
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            teams = client.parseDOM(i, 'h3')[0]
            teams = re.search('([^<]+)', teams).group(1)
            teams = client.replaceHTMLCodes(teams)
            teams = teams.strip().encode('utf-8')
            
            time = client.parseDOM(i, 'time', ret = 'datetime')[0]
            time = time.encode('utf-8')
            addFile('%s | [B][COLOR white]%s[/COLOR][/B] | [COLOR blue]%s[/COLOR]' % (time, teams, title), link, 3, img, '', '', IsPlayable=True)
        except:
            pass

 
def getVideo():
    try:
        query = urlparse.urljoin(ehftv_url, url)
        result = client.request(query)
        
        available = client.parseDOM(result, 'div', attrs={'class':'row'})[-1]
        if '<span class="no">' in available:
            xbmcgui.Dialog().ok('ehfTV', 'Due to existing TV rights it is not possible to broadcast this stream in your country.')
            return

        result = client.parseDOM(result, 'div', attrs={'class':'player-wrapper'})[0]

        videoid = re.search('videoid\s*:\s*["\']([^"\']+)', result).group(1)
        language = re.search('language\s*:\s*["\']([^"\']+)', result).group(1)
        partnerid = re.search('partnerid\s*:\s*["\']([^"\']+)', result).group(1)
        host = re.search('configUrl\s*:\s*"([^"]+)', result).group(1)
        if host.startswith('//'): host = 'http:' + host

        query = urllib.urlencode({'videoid': videoid, 'partnerid': partnerid, 'language': language, 'format': 'iphone'})
        result = client.request(host + '?' + query)
        
        streamAccess = json.loads(result)['video']['streamAccess']
        
        area = urlparse.parse_qs(streamAccess)['area'][0]
        area = area.encode('utf-8')
        
        target = urlparse.parse_qs(streamAccess)['target'][0]
        target = target.encode('utf-8')
        
        label = urlparse.parse_qs(streamAccess)['label'][0]
        label = label.encode('utf-8')
        
        partner = urlparse.parse_qs(streamAccess)['partner'][0]
        partner = partner.encode('utf-8')
        
        post = urllib.urlencode({'videoId': videoid, 'target': target, 'partner': partner, 'label': label, 'area': area, 'format': 'iphone'})
        
        result = client.request(streamAccess, post=post)
        sources = json.loads(result)['data']['stream-access']
        
        result = client.request(sources[0])
        
        m3u8 = client.parseDOM(result, 'token', ret='url')[0]
        hdnea = client.parseDOM(result, 'token', ret='auth')[0]

        sources = client.request(m3u8 + '?hdnea=' + hdnea)
        sources = sources.replace('\n', '')
        sources = re.findall('\d{3,4}x(\d{3,4}).+?(http[^#]+)', sources)
        sources = list(dict(sources).items())
        sources = sorted(sources, key=lambda x: x[0])[::-1]

        auto_pick = control.setting('auto_pick') == 'true'
        if len(sources) == 1:
            source = sources[0][1]
        elif len(sources) > 1:
            if auto_pick:
                source = sources[0][1]
            else:
                result = xbmcgui.Dialog().select('Quality', [source[0] if source[0] else 'Uknown' for source in sources])
                if result == -1:
                    return
                else:
                    source = sources[result][1]

        try: title = re.search('white]([^\[]+)', name).group(1)
        except: title = name

        item = control.item(path=source)
        item.setArt({'icon': iconimage, 'thumb': iconimage})
        item.setInfo(type='Video', infoLabels = {'Title': title})
        control.resolve(int(sys.argv[1]), True, item)
    except:
        return


def addFile(name, url, mode, iconimage, fanart, description, IsPlayable=False):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    if not IsPlayable == False: liz.setProperty("IsPlayable", "true")
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def addDir(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass


if mode==None:
    mainPage()
elif mode==0:
    'no stream'
elif mode==1:
    getVideos()
elif mode==2:
    getEpisodes()
elif mode==3:
    getVideo()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
