# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urlparse,sys

from resources.lib import noisyshark


REMOTE_DBG = False


# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))

url = params.get('url')

action = params.get('action')

title = params.get('title')

image = params.get('image')

search_text = params.get('search_text')

page = params.get('page')
if page == None or len(page)<1:
    page ='1'


if action == None:
    noisyshark.indexer().root()

elif action == 'categories':
    noisyshark.indexer().categories()

elif action == 'videos':
    noisyshark.indexer().videos(url, page)

elif action == 'getvideo':
    noisyshark.indexer().getvideo(url, image, title)

elif action == 'search':
    noisyshark.indexer().search()

elif action == 'search_result':
    noisyshark.indexer().search_result(search_text)

