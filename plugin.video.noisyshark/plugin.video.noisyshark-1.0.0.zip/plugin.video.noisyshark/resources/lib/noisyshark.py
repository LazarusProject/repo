# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys,xbmcgui,urllib,re,urlparse,json

from resources.lib import client
from resources.lib import control
from resources.lib import cache
from resources.lib import directory


class indexer:
    def __init__(self):
        self.list = []
        self.main_url = 'http://koncertsziget.hu'
        self.email = control.setting('email')
        self.password = control.setting('password')
        if not (self.email == '' or self.password == ''):
            self.cookie = cache.get(self.login, 2, 'cookie')
        else:
            self.cookie = ''


    def root(self):        
        self.list = [

        {
        'title': 'Kategóriák',
        'action': 'categories',
        },
                     
        {
        'title': 'Keresés',
        'action': 'search',
        }
        ]

        directory.add(self.list)
        return self.list


    def categories(self):
        query = urlparse.urljoin(self.main_url, '/index.php?pg=films')
        r = client.request(query, cookie=self.cookie)
        result = client.parseDOM(r, 'ul', attrs={'class': 'categories_ul'})
        result = client.parseDOM(result, 'a', ret='href'), client.parseDOM(result, 'a')
        result = zip(result[0], result[1])
        for i in result:
            self.list.append({'title': i[1].encode('utf-8'), 'url': i[0].encode('utf-8')})
        for i in self.list: i.update({'action': 'videos'})

        directory.add(self.list)


    def videos(self, url, page):
        query = urlparse.urljoin(self.main_url, url + '&page=' + page)
        r = client.request(query, cookie=self.cookie)
        r = client.parseDOM(r, 'div', attrs={'class': 'content_lyrics'})
        result = client.parseDOM(r, 'div', attrs={'class': 'list_box_content\s*'})
        for i in result:
            try:
                title = client.parseDOM(i, 'div', attrs={'class': 'list_box_content_title'})
                title = client.parseDOM(title, 'a')[0].encode('utf-8')
    
                link = client.parseDOM(i, 'div', attrs={'class': 'list_box_button'})
                link = client.parseDOM(link, 'a', ret='href')[0].encode('utf-8')
    
                img = client.parseDOM(i, 'div', attrs={'class': 'list_box_pic'})
                img = client.parseDOM(img, 'a', ret='href')[0].encode('utf-8')
                img = urlparse.urljoin(self.main_url, img)
    
                plot = client.parseDOM(i, 'div', attrs={'class': 'list_box_content_content'})[0].encode('utf-8')
    
                try:
                    duration = client.parseDOM(i, 'div', attrs={'class': 'list_box_content_details'})[0]
                    duration = re.search('Hossz:([^<]+)', duration).group(1)
                    duration = re.findall('(\d+)', duration)
                    if len(duration) == 2: duration = str(int(duration[0]) * 3600 + int(duration[1]) * 60)
                    elif len(duration) == 1: duration = str(int(duration[0]) * 60)
                    else: duration = '0'
                except:
                    duration = '0'
    
                self.list.append({'title': title, 'url': link, 'image': img, 'poster': img, 'plot': plot, 'duration': duration, 'action': 'getvideo', 'isFolder': 'false'})
            except:
                pass
        
        try:
            next = client.parseDOM(r, 'ul', attrs={'class': 'paging'})[0]
            if u'k\u00F6vetkez\u0151' in next.lower():
                self.list.append({'title': '[COLOR green]Következő oldal[/COLOR]', 'url': url, 'action': 'videos', 'page': str(int(page) + 1)})
        except:
            pass

        directory.add(self.list)


    def getvideo(self, url, image, title):
        try:
            query = urlparse.urljoin(self.main_url, url)
            r = client.request(query, cookie=self.cookie)

            media_id = re.search('(?://|\.)player\.vimeo\.com/video/([0-9a-zA-Z]+)', r).group(1)
            web_url =  'https://player.vimeo.com/video/%s/config' % media_id

            headers = {'Referer': 'https://vimeo.com/', 'Origin': 'https://vimeo.com'}
            data = client.request(web_url, headers=headers)
            data = json.loads(data)
            sources = [(vid['url'], vid['height']) for vid in data.get('request', {}).get('files', {}).get('progressive', {})]
            try: sources.sort(key=lambda x: x[1], reverse=True)
            except: pass
            source = self.pick_source(sources)

            directory.resolve(source)
        except: 
            control.idle()
            return


    def pick_source(self, sources, auto_pick=None):
        if auto_pick is None:
            auto_pick = control.setting('autopick') == '1'

        if len(sources) == 1:
            return sources[0][0]
        elif len(sources) > 1:
            if auto_pick:
                return sources[0][0]
            else:
                result = xbmcgui.Dialog().select('Minőség', [str(source[1]) if source[1] else 'Uknown' for source in sources])
                if result == -1:
                    return
                else:
                    return sources[result][0]


    def search(self):
        try:
            control.idle()
    
            t = 'Keresés'
            k = control.keyboard('', t) ; k.doModal()
            q = k.getText() if k.isConfirmed() else None
    
            if (q == None or q == ''): raise Exception()
    
            url = '%s?action=search_result&search_text=%s' % (sys.argv[0], urllib.quote_plus(q))
            control.execute('Container.Update(%s)' % url)
        except:
            return


    def search_result(self, search_text):
        try:
            query = urlparse.urljoin(self.main_url, '/?search_field=%s&pg=search&action=search' % urllib.quote_plus(search_text))
            r = client.request(query, cookie=self.cookie)
            result = r.split('Vide\xc3\xb3k k\xc3\xb6z\xc3\xb6tt:', 1)[1].split('<b>')[0]
            result = zip(client.parseDOM(result, 'a'),client.parseDOM(result, 'a', ret='href'))
            if len(result) == 0: raise Exception()
            for i in result:
                self.list.append({'title': i[0].split('>>')[1].strip().encode('utf-8'), 'url': urlparse.urljoin(self.main_url, i[1].encode('utf-8')), 'action': 'getvideo', 'isFolder': 'false'})
            directory.add(self.list)
        except:
            return


    def play(self, source, title, image):
        liz=control.item(iconImage=image, thumbnailImage=image)
        liz.setInfo(type="Video", infoLabels={'Title': title})
        control.player.play(source, liz)


    def login(self, params):
        post = urllib.urlencode({'login_email': self.email, 'password': self.password, 'pg': 'login'})
        cookie = client.request(self.main_url, post=post, output = 'cookie')
        return cookie
