#!/usr/bin/python3
#
# Transmission magnet link uploader
#
# Uses httplib2 & PyQt4
# http://code.google.com/p/httplib2/
# http://www.riverbankcomputing.co.uk/software/pyqt/download
#

# Standard
from PyQt4 import QtGui, QtCore
from json import dumps
import requests
from sys import argv, exit
import sys
import urlparse


# 3rd Party
# Settings
url = 'http://192.168.0.18:9091/transmission/rpc'
username = 'transmission'
password = 'transmission'
icon = 'C:\\Scripts\\Magnet-icon.png'

# Functions

# Show Message Box
def show_message(title, message):
    app = QApplication([])
    QMessageBox.information(None, title, message)

# Show Tray Message
def show_tray_message(title, message):
    return

# Get RPC Session ID
def get_session_id():
    sessionid_request = requests.get(url, auth=(username, password), verify=False)
    return sessionid_request.headers['x-transmission-session-id']

# Post Magnet Link
def post_link(magnetlink):
    sessionid = get_session_id()
    if sessionid:
        headers = {"X-Transmission-Session-Id": sessionid}
        body = dumps({"method": "torrent-add", "arguments": {"filename": magnetlink}})
        post_request = requests.post(url, data=body, headers=headers, auth=(username, password), verify=False)
        if str(post_request.text).find("success") == -1:
            title =  argv[0] + ' - Error'
            message = 'Magnet Link: ' + magnetlink + '\nAnswer: ' + post_request.text
            show_message(title, message)
        else:
            message = '\n'.join(names) + '\n' + '\n'.join(trackers)
            show_tray_message('Magnet Link Added', message)

# End of Functions

# Main prog
if __name__ == '__main__':

    # Check Argument and Extract Name/Trackers or Display Alert Message
    if len(argv) < 2:
        show_message(argv[0] + ' - Alert', 'Usage: ' + argv[0] + ' [magnet link]')
        exit(1)
    elif argv[1].startswith('magnet'):
        names = []
        trackers = []
        for item in argv[1].split('&'):
            decoded = urlparse.unquote(item)
            if decoded.startswith('dn='):
                names.append(decoded.replace('dn=', ''))
            if decoded.startswith('tr='):
                trackers.append(decoded.replace('tr=', ''))
    else:
        show_message(argv[0] + ' - Alert', argv[1] + ' not magnet link!')
        exit(1)
   
    post_link(argv[1])

