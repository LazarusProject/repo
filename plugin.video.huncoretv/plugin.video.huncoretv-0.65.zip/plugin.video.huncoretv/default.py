#!/usr/bin/env python
# -*- coding: utf-8 -*- 

import HTMLParser
import base64
from libtorrent import bencode, bdecode
import libtorrent
import os
import re
import requests
import shutil
import sys
import threading
from time import sleep
import time
import urllib
import urllib2
import urlparse

import xbmcaddon
import xbmcgui
import xbmcplugin
import logging

logging.captureWarnings(True)
addon = xbmcaddon.Addon(id='plugin.video.huncoretv')
thisAddonDir = xbmc.translatePath(addon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

logined = False

xbmcplugin.setContent(addon_handle, 'movies')
baseUrl = 'https://ncore.cc'

felhasznalo = addon.getSetting('felhasznalonev')
jelszo = addon.getSetting('jelszo')
torrentPath = addon.getSetting('torrentPath')
torrentFullDownload = addon.getSetting('torrentFullDownload')
while (felhasznalo == "" or jelszo == "" or torrentPath == ""):
    addon.openSettings()
    felhasznalo = addon.getSetting('felhasznalonev')
    jelszo = addon.getSetting('jelszo')
    torrentPath = addon.getSetting('torrentPath')

filmHUNtipus=""
if addon.getSetting('xvid_hun') == 'true':
    filmHUNtipus = filmHUNtipus + ',xvid_hun'
if addon.getSetting('dvd_hun') == 'true':
    filmHUNtipus = filmHUNtipus + ',dvd_hun'
if addon.getSetting('dvd9_hun') == 'true':
    filmHUNtipus = filmHUNtipus + ',dvd9_hun'
if addon.getSetting('hd_hun') == 'true':
    filmHUNtipus = filmHUNtipus + ',hd_hun'
filmHUNtipus= filmHUNtipus[1:]

filmENGtipus=""
if addon.getSetting('xvid') == 'true':
    filmENGtipus = filmENGtipus + ',xvid'
if addon.getSetting('dvd') == 'true':
    filmENGtipus = filmENGtipus + ',dvd'
if addon.getSetting('dvd9') == 'true':
    filmENGtipus = filmENGtipus + ',dvd9'
if addon.getSetting('hd') == 'true':
    filmENGtipus = filmENGtipus + ',hd'
filmENGtipus= filmENGtipus[1:]

filmXXXtipus=""
if addon.getSetting('xxx_xvid') == 'true':
    filmXXXtipus = filmXXXtipus + ',xxx_xvid'
if addon.getSetting('xxx_dvd') == 'true':
    filmXXXtipus = filmXXXtipus + ',xxx_dvd'
if addon.getSetting('xxx_hd') == 'true':
    filmXXXtipus = filmXXXtipus + ',xxx_hd'
filmXXXtipus= filmXXXtipus[1:]

sorozatHUNtipus=""
if addon.getSetting('xvidser_hun') == 'true':
    sorozatHUNtipus = sorozatHUNtipus + ',xvidser_hun'
if addon.getSetting('dvdser_hun') == 'true':
    sorozatHUNtipus = sorozatHUNtipus + ',dvdser_hun'
if addon.getSetting('hdser_hun') == 'true':
    sorozatHUNtipus = sorozatHUNtipus + ',hdser_hun'
sorozatHUNtipus= sorozatHUNtipus[1:]

sorozatENGtipus=""
if addon.getSetting('xvidser') == 'true':
    sorozatENGtipus = sorozatENGtipus + ',xvidser'
if addon.getSetting('dvdser') == 'true':
    sorozatENGtipus = sorozatENGtipus + ',dvdser'
if addon.getSetting('hdser') == 'true':
    sorozatENGtipus = sorozatENGtipus + ',hdser'
sorozatENGtipus= sorozatENGtipus[1:]


try:
    torrentSession
except NameError:
    torrentSession = libtorrent.session()
    torrentSession.listen_on(6881, 6889)

def newSession():
    s = requests.Session()
    s.headers.update({
        'User-Agent': 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.6 Safari/537.36',
    })
    return s

try:
    session
except NameError:
    session = newSession()
    

def doLogin():
    global session
    if felhasznalo != "":
        response = session.get(baseUrl + '/profile.php')
        if (felhasznalo + ' profilja') not in response.content:
            payload = {'nev': felhasznalo, 'pass': jelszo, 'ne_leptessen_ki' : True}
            session.post(baseUrl + '/login.php',data = payload)
            response = session.get(baseUrl + '/profile.php')
            if (felhasznalo + ' profilja') in response.content:
                logined = True
                #sys.stderr.write("sikeres login")
            else:
                logined = False
                sys.stderr.write("sikertelen login")
                xbmc.executebuiltin('Helytelen felhasználónév, vagy jelszó!')
                addon.openSettings()
    return

def load(url, post = None):
    global session
    doLogin()
        
    r = ""
    try:
        if post:
            r = session.post(url, data=post, timeout=10).text
        else:
            r = session.get(url).text
    except AttributeError:
        xbmc.executebuiltin("HIBA: {0}".format(AttributeError.message))
        session = newSession()
        doLogin()
        if post:
            r = session.post(url, data=post, verify=False, timeout=10).text
        else:
            r = session.get(url, verify=False).text

    return r.encode('utf-8')

def play_torrenturl(fileToPlay, video_url, videoname, thumbnail):
    info = libtorrent.torrent_info(torrentPath + '/mytorrent.torrent')

    for root, dirs, files in os.walk(torrentPath):
        for f in files:
            if (f != 'mytorrent.torrent') :
                os.unlink(os.path.join(root, f))
        for d in dirs:
            shutil.rmtree(os.path.join(root, d))

    torrentHandler = torrentSession.add_torrent({'ti': info, 'save_path': torrentPath})
    for x in range(0, info.num_files()):
        file_entry = info.file_at(x)
        if file_entry.path == fileToPlay:
            pr = info.map_file(x, 0, 1)
            first_piece = pr.piece
            break
    
    elonyMB = (1024*1024*300)
    elonyPiece = int(elonyMB/info.piece_length()) + 1
    elony = int(file_entry.size / elonyMB) #300MB előnyt a lejátszónak adunk
    if (elony == 0):
        waitForPercent = 99
    else:
        waitForPercent = int(100 / elony) 
        
    n_pieces = file_entry.size / info.piece_length() + 1
    x = int(n_pieces / 6) + 1
    for i in range(0, info.num_pieces()):
        if i in range(first_piece, first_piece+n_pieces):
            y = int(int(i-first_piece)/x)
            if (i < first_piece + elonyPiece):
                sys.stderr.write('priority: 7')
                torrentHandler.piece_priority(i, 7)
            else:
                sys.stderr.write('priority: ' + str(6 - y))
                torrentHandler.piece_priority(i, 6 - y)
        else:
            torrentHandler.piece_priority(i, 0)

    progress = xbmcgui.DialogProgress()
    progress.create('Progress: ' + torrentHandler.name())
    while (not torrentHandler.is_seed()):
        s = torrentHandler.status()
        state_str = ['queued', 'checking', 'downloading metadata', 'downloading', 'finished', 'seeding', 'allocating', 'checking fastresume']
        
        if (progress.iscanceled()):
            break

        progress.update(int(s.progress * 100), 'Download rate: ' + str(s.download_rate / 1000) + ' kB/s', 'Peers: ' + str(s.num_peers), 'State: ' + state_str[s.state] + ', ' + str(int(s.progress * 100)) + '% and waiting for ' + str(waitForPercent) + '%')

        if (int(s.progress * 100) > waitForPercent) & (torrentFullDownload == 'false'):
            play_torrent(videoname, thumbnail, torrentPath + fileToPlay)
        
        if (xbmc.Player().isPlaying()):
            progress.close()
            break
            
        if s.progress>=1:
            break
        time.sleep(1)
    
    if (torrentFullDownload == 'true') & (not xbmc.Player().isPlaying()):
        play_torrent(videoname, thumbnail, torrentPath + fileToPlay)
    
    while xbmc.Player().isPlaying():
        time.sleep(1)
    
    if (torrentHandler.is_seed()):
        for i in range(0, info.num_pieces()):
            torrentHandler.piece_priority(i, 0)
    
    return

def play_torrent(videoname, thumbnail, filePath):
    videoitem = xbmcgui.ListItem(label=videoname, thumbnailImage=thumbnail)
    videoitem.setInfo(type='Video', infoLabels={'Title': videoname})
    xbmc.Player().play(filePath, videoitem)
    return

def build_torrent_sub_directory(video_url, videoname):
    video_url = base64.b64decode(video_url)
    #sys.stderr.write('build_torrent_sub_directory: ' + video_url)
    video_url = video_url.replace('action=details', 'action=download')
    video_url = video_url.replace('https', 'http')
    #sys.stderr.write('torrent file url: ' + video_url)
    
    torrentData = load(video_url)
    content = session.get(video_url, stream=True)
    content.raw.decode_content = True
    output = open(torrentPath + '/mytorrent.torrent', 'wb')
    shutil.copyfileobj(content.raw, output) 
    output.close()

    info = libtorrent.torrent_info(torrentPath + '/mytorrent.torrent')
    
    for x in range(0, info.num_files()):
        file_entry = info.file_at(x)
        localurl = sys.argv[0]+'?mode=playTorrent&videoName=' + videoname + '&movieURL=' + video_url + '&fileToPlay=' + file_entry.path
        li = xbmcgui.ListItem(os.path.basename(file_entry.path).decode('utf-8'))
        #sys.stderr.write('file_entry.path: ' + file_entry.path)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)
    return 

def play_videourl(video_url, videoname, thumbnail):
    ##sys.stderr.write('play_videourl - video_url: ' + video_url + ', videoname: ' + videoname + '\n')
    content = load(video_url);
    embeded_url = re.compile('file:.*?"(.*?)"', re.MULTILINE|re.DOTALL).findall(content)
    
    if (len(embeded_url) == 0):
        embeded_url = re.compile('<source src="(.*?)"', re.MULTILINE|re.DOTALL).findall(content)

    videoitem = xbmcgui.ListItem(label=videoname, thumbnailImage=thumbnail)
    videoitem.setInfo(type='Video', infoLabels={'Title': videoname})
    xbmc.Player().play(embeded_url[0], videoitem)
    return

def build_main_directory():
    localurl = sys.argv[0]+'?mode=changeDir&dirName=Ajanlo'
    li = xbmcgui.ListItem('Ajánló')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

    localurl = sys.argv[0]+'?mode=changeDir&dirName=Kereses'
    li = xbmcgui.ListItem('Keresés')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)
    return

def build_kereso_to_subdir(keresoUrl):
    if (keresoUrl is None):
        return
    
    if ('mire=' not in keresoUrl):
        kb=xbmc.Keyboard('', 'Keresés', False)
        kb.doModal()
        if (kb.isConfirmed()):
            searchText = kb.getText()
            searchText = urllib.quote_plus(searchText)
            #sys.stderr.write('kereő URL: ' + baseUrl + keresoUrl + '&mire=' + searchText)
            url_content = load(baseUrl + keresoUrl + '&mire=' + searchText.replace(' ', '+'))
        else:
            return
    else:
        url_content = load(baseUrl + '/' + keresoUrl)
        
    torrentURL = re.compile('<div class="box_nev2">(.*?)<div style="clear:both;">', re.MULTILINE | re.DOTALL).findall(url_content)
    
    hParser = HTMLParser.HTMLParser()
    if (len(torrentURL) > 0):
        for x in range(0, len(torrentURL)):
            #sys.stderr.write('torrentURL[x]: ' + torrentURL[x])
            egyTorrent = re.compile('href="torrents.php.*?id=(.*?)" onclick.*?title="(.*?)".*?mutat\(\'(.*?)\'.*?class="box_meret2">(.*?)<', re.MULTILINE | re.DOTALL).findall(torrentURL[x])
            if (len(egyTorrent) > 0):
                #sys.stderr.write('egyTorrent[0]: ' + egyTorrent[0][0])
                #sys.stderr.write('egyTorrent[1]: ' + egyTorrent[0][1])
                #sys.stderr.write('egyTorrent[2]: ' + egyTorrent[0][2])
                #sys.stderr.write('egyTorrent[3]: ' + egyTorrent[0][3])
                localurl = sys.argv[0]+'?mode=listTorrent&videoName=' + egyTorrent[0][1] + '&movieURL=' + base64.b64encode(hParser.unescape(baseUrl + "/torrents.php?action=details&id=" + egyTorrent[0][0]))
                urllib.urlretrieve(egyTorrent[0][2].replace("'",""), torrentPath + "/" + egyTorrent[0][1] + ".png")
                li = xbmcgui.ListItem("(" + egyTorrent[0][3].decode('utf-8') + ") " + egyTorrent[0][1].decode('utf-8'), thumbnailImage=torrentPath + "/" + egyTorrent[0][1] + ".png")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_sub_directory(subDir):
    #RSS torrent
    hParser = HTMLParser.HTMLParser()
    
    if (subDir[0] == 'Ajanlo'):
        url_content = load(baseUrl + '/recommended.php')
        filmSorozat = re.compile('<a name="film">&nbsp;</a>(.*?)<a name="jatek">&nbsp;</a>', re.MULTILINE | re.DOTALL).findall(url_content)
        ajanloList = re.compile('<a href="(.*?)".*?<img src="(.*?)".*?title="(.*?)"', re.MULTILINE).findall(filmSorozat[0])

        if (len(ajanloList) > 0):
            for x in range(0, len(ajanloList)):
                #sys.stderr.write("thumbnailImage: " + torrentPath + "/" + ajanloList[x][2] + ".png")
                urllib.urlretrieve(ajanloList[x][1], torrentPath + "/" + ajanloList[x][2] + ".png")

                localurl = sys.argv[0]+'?mode=listTorrent&videoName=' + ajanloList[x][2] + '&movieURL=' + base64.b64encode(hParser.unescape(baseUrl + "/" + ajanloList[x][0]))
                li = xbmcgui.ListItem(ajanloList[x][2].decode('utf-8'), thumbnailImage=torrentPath + "/" + ajanloList[x][2] + ".png")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

    if (subDir[0] == 'Kereses'):
        localurl = sys.argv[0]+'?mode=changeDir&dirName=FilmHUN'
        li = xbmcgui.ListItem('Film - HUN')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

        localurl = sys.argv[0]+'?mode=changeDir&dirName=SorozatHUN'
        li = xbmcgui.ListItem('Sorozat - HUN')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

        localurl = sys.argv[0]+'?mode=changeDir&dirName=FilmENG'
        li = xbmcgui.ListItem('Film - ENG')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

        localurl = sys.argv[0]+'?mode=changeDir&dirName=SorozatENG'
        li = xbmcgui.ListItem('Sorozat - ENG')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)

        localurl = sys.argv[0]+'?mode=changeDir&dirName=XXX'
        li = xbmcgui.ListItem('XXX')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=localurl, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)

    if (subDir[0] == 'FilmHUN'):
        build_kereso_to_subdir('/torrents.php?tipus=kivalasztottak_kozott&kivalasztott_tipus=' + filmHUNtipus) #xvid_hun,dvd_hun,dvd9_hun,hd_hun')
        xbmcplugin.endOfDirectory(addon_handle)

    if (subDir[0] == 'SorozatHUN'):
        build_kereso_to_subdir('/torrents.php?tipus=kivalasztottak_kozott&kivalasztott_tipus=' + sorozatHUNtipus) #xvidser_hun,dvdser_hun,hdser_hun')
        xbmcplugin.endOfDirectory(addon_handle)

    if (subDir[0] == 'FilmENG'):
        build_kereso_to_subdir('/torrents.php?tipus=kivalasztottak_kozott&kivalasztott_tipus=' + filmENGtipus) #xvid,dvd,dvd9,hd')
        xbmcplugin.endOfDirectory(addon_handle)

    if (subDir[0] == 'SorozatENG'):
        build_kereso_to_subdir('/torrents.php?tipus=kivalasztottak_kozott&kivalasztott_tipus=' + sorozatENGtipus) #xvidser,dvdser,hdser')
        xbmcplugin.endOfDirectory(addon_handle)

    if (subDir[0] == 'XXX'):
        build_kereso_to_subdir('/torrents.php?tipus=kivalasztottak_kozott&kivalasztott_tipus=' + filmXXXtipus) #xxx_xvid,xxx_dvd,xxx_hd')
        xbmcplugin.endOfDirectory(addon_handle)

    return

# main...
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

mode = args.get('mode', None)
subDir = args.get('dirName', None)
nextPrevURL = args.get('nextPrevURL', None)
movieURL = args.get('movieURL', None)
videoName = args.get('videoName', None)
fileToPlay = args.get('fileToPlay', None)
thumbnail = args.get('thumbnail', None)
stype = args.get('stype', None)

if mode is None:
    ##sys.stderr.write('mode: NONE \n')
    build_main_directory()
elif mode[0] == 'changeDir':
    ##sys.stderr.write('mode: ' + mode[0] + ', subDir: ' + subDir[0] + '\n')
    build_sub_directory(subDir)
elif mode[0] == 'nextPrev':
    if (nextPrevURL is not None):
        build_kereso_to_subdir(base64.b64decode(nextPrevURL[0]))
elif mode[0] == 'playTorrent':
    play_torrenturl(fileToPlay[0], movieURL[0], videoName[0], None)
elif mode[0] == 'listTorrent':
    build_torrent_sub_directory(movieURL[0], videoName[0])
elif mode[0] == 'playMovie':
    if (thumbnail is None):
        if (stype is None):
            ##sys.stderr.write('stype is None\n')
            play_videourl(baseUrl + '/' + movieURL[0] + '&stype=flash', videoName[0], None)
        else:
            ##sys.stderr.write('stype: ' + stype[0] + '\n')
            play_videourl(baseUrl + '/' + movieURL[0] + '&stype=' + stype[0], videoName[0], None)
    else: 
        if (stype is None):
            ##sys.stderr.write('stype is None\n')
            play_videourl(baseUrl + '/' + movieURL[0] + '&stype=flash', videoName[0], thumbnail[0])
        else:
            ##sys.stderr.write('stype: ' + stype[0] + '\n')
            play_videourl(baseUrl + '/' + movieURL[0] + '&stype=' + stype[0], videoName[0], thumbnail[0])
