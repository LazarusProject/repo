import xbmcaddon

MainBase = 'https://goo.gl/DlAQo7'
addon = xbmcaddon.Addon('plugin.video.Retro')