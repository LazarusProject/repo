# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, time, xbmcaddon, os, msresolver
#from curses.ascii import isdigit

thisAddon = xbmcaddon.Addon(id='plugin.video.moviesharkcc')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')
SettingsDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources')).decode('utf-8')
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ).decode('utf-8')

from resources.lib import client

moviecc_url = 'http://www.moovie.cc/'
api_key = thisAddon.getSetting('api_key')
addon_handle = int(sys.argv[1])

def __init__(self):
        self.getConstants()

def just_removed(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = 'A keresett linket eltávolították!'
    xbmcgui.Dialog().ok(addonname, line1, 'Video kiszolgáló: ' + file_host.upper())   
    return

def setviewmode(mode):
    addon_settings = xbmcaddon.Addon(id='plugin.video.moviesharkcc')
    mainview = int(addon_settings.getSetting('mainview'))
    streamview = int(addon_settings.getSetting('streamview'))

    if mode == 'main_folder':
        if mainview == 1:
            mainview = 502
        elif mainview == 2:
            mainview = 51
        elif mainview == 3:
            mainview = 500
        elif mainview == 4:
            mainview = 501
        elif mainview == 5:
            mainview = 508
        elif mainview == 6:
            mainview = 504
        elif mainview == 7:
            mainview = 503
        elif mainview == 8:
            mainview = 515    
        else:
            mainview = 0
        return(mainview)
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %mainview)
    elif mode == 'movie_folder':
        if streamview == 1:
            streamview = 502
        elif streamview == 2:
            streamview = 51
        elif streamview == 3:
            streamview = 500
        elif streamview == 4:
            streamview = 501
        elif streamview == 5:
            streamview = 508
        elif streamview == 6:
            streamview = 504
        elif streamview == 7:
            streamview = 503
        elif streamview == 8:
            streamview = 515
        else:
            streamview = 0
        return(streamview)            
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %streamview)
 
    return

def find_fanart(imdbnum):
    fanart_info = [' ',' ','0',' ', ' ']
    image_url = ''
    year = ''
    genre = ''
    genre2 = ''
    overview = ''

    top_url = 'http://api.themoviedb.org/3/find/' + imdbnum +'?api_key=' + api_key + '&external_source=imdb_id&language=hu'
    i = client.source(top_url)
    
    if '"overview":null' in i:
        top_url = 'http://api.themoviedb.org/3/find/' + imdbnum +'?api_key=' + api_key + '&external_source=imdb_id&language=en'

    if '"overview":null' not in i:
        if '"release_date"' in i:
            if '"release_date":null' not in i:
                year = re.compile('release_date":"([0-9]+)').findall(i)
        if '"first_air_date"' in i:
            if '"first_air_date":null' not in i:
                year = re.compile('"first_air_date":"([0-9]+)').findall(i)
        if '"backdrop_path":null' not in i:
            image_url = re.compile('backdrop_path":"([^"]+)').findall(i)
        else:
            if '"poster_path":null' not in i:
                image_url = re.compile('"poster_path":"([^"]+)').findall(i)
        if '"original_name":null' not in i:
            orig_name = re.compile('"original_name":"([^"]+)').findall(i)   

        overview = re.compile('overview":"(.+?(?=\",\"))').findall(i)
        genre = re.compile('vote_average":([^,]+)').findall(i)
        genre2 = re.compile('vote_count":([^"}"]+)').findall(i)
        if genre:
            genre = 'Pontszam: ' + genre[0]
        if genre2:
            genre = genre + ' Szavazat: ' + genre2[0]
        
        if image_url:
            fanart_info[0] = 'https://image.tmdb.org/t/p/w780' + image_url[0]

        if overview:
            fanart_info[1] = overview[0].strip(' \t\n\r')

        if year:
            fanart_info[2] = year[0]

        if genre:
            fanart_info[3] = genre
        
        if orig_name:
            fanart_info[4] = orig_name[0]
            
    return fanart_info


def home():
    addDir('Filmek',                     '', 1, '', '', '1', 1, '', '', '','','')
    addDir('Sorozatok',                  '', 1, '', '', '2', 1, '', '', '','','')
    addDir('Keresés',                    '', 5, '', '', '', 1, '', '', '','','')
    return

def filmek():
    addDir('Legújabb',                  '', 2, '', '', description, 1, 'new', '', 'not', '','')
    addDir('Legfrissebb (megjelenés)',  '', 2, '', '', description, 1, 'year', '', 'not', '','')
    addDir('Legnézettebb',              '', 2, '', '', description, 1, 'most_watched', '', 'not', '','')
    addDir('Legjobbra értékelt',        '', 2, '', '', description, 1, 'most_pop', '', 'not', '','')
    addDir('Kategóriák',                '', 12, '', '', description, 1, 'most_watched', '', '', '','')
    return

def listak():
    if description == '1': m = 3
    else:
        m = 8      
    for a, b, c in getMovies(description, category, page, genre): addDir(c, a, m, moviecc_url + b, moviecc_url + b, description, 1, '', '', '', '','')    
    addDir('[COLOR green]Következő oldal[/COLOR]', '', 2, '', '', description, page + 1, category, '', genre, '','')
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def kategoriak():
    url = moviecc_url + 'kategoriak'
    i = client.source(url)
    i = re.compile(moviecc_url + 'kategoriak/(.+?)\/.+?title="(.+?) filmek').findall(i)
    for a, b in i:
        a = str(a) + ','
        addDir(b, '', 2, '', '', description, 1, category, '', a, '', '')
    return
    

def kereses(search_text, page):
    for a, b, c, d, e in searchMovies(search_text, page): 
        addDir(c, a, 11, moviecc_url + b, moviecc_url + b, e, 1, '', d, '', '','')
    addDir('[COLOR green]Következő oldal[/COLOR]', '', 6, '', '', '', page + 1, search_text, '', '', '','')
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def getType():
    i =  client.source(moviecc_url + 'online-filmek/' + url)
    i = client.source('http://filmbazis.org/' + re.compile('filmbazis.org\/(.+?)\/').findall(i)[0])
    if 'g_season = "0"' in i:
        m = 3
    else:
        m = 8
    addDir(name, url, m, iconimage, fanart, description, '', '', year, '', '', '')
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def forrasok_Film():
    fanart_info = [' ',' ','0',' ',' ', ' ']
    hostDict = getConstants()
    addon_settings = xbmcaddon.Addon()
    
    i =  client.source(moviecc_url + 'online-filmek/' + url)
    plot_info = re.compile('plot">\s*([^<]*)').findall(i)[0]
    plot_info = plot_info.strip('\t\n\r')
    if '<h2></h2>' not in i:
        orig_title = re.compile('</h1>\n.+?<h2>(.+?)</h2>').findall(i)[0]
    else:
        orig_title = name
    if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
        if 'imdb_id=tt' in i:
            imdb_id = re.compile('m/title/([^"/]+)"').findall(i)[0]        
            if imdb_id:
                fanart_info = find_fanart(imdb_id)
        else:
            fanart_info[0] = iconimage
    if fanart_info[0] == ' ':
        fanart_info[0] = iconimage
    for a, b, c, d in getMovieSources(i):
        b = b.split('.')[0].replace(' ','')
        if b.lower() in hostDict:    
            addFile('[COLOR blue]' + c + '[/COLOR]' + ' ' + a + ' ' + '[COLOR green]' + b.upper() + '[/COLOR]', name, d, 4, iconimage, fanart_info[0], plot_info, b, fanart_info[2], fanart_info[3], '', orig_title[0])
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def forrasok_Sorozat():    
    hostDict = getConstants()
    episode = re.compile('([0-9]*). rész').findall(name)
    season = re.compile('([0-9]*). Évad').findall(name)
    n_episode = int(episode[0]) + 1
    n_episode = str(n_episode)
    
    query = 'http://filmbazis.org/movies.php'
    post = {'type': 'get_movie_links', 'query': 'movie_id:' + url + '|' + 'season:' + season[0]}
    post = urllib.urlencode(post)
    i = client.source(query, post = post)

    if '<tr id="episode_' + n_episode in i:
        n = 'episode_' + n_episode + '"'
    else:
        n = '</a></td></tr>'

    i = re.compile('episode_' + episode[0] + '"([\S\s]*)' + n).findall(i)
    i = re.compile('bubble="(.+?)".+?\n.+?site.+?">(.+?)<[b|/|f].+?\n.+?quality[ |"].+?>(.+?)</.+?\n.+?\n.+?\n.+?\n.+?href="(.+?)"').findall(i[0])
    for a, b, c, d in i:
        b = b.split('.')[0]
        if b.lower() in hostDict:    
            addFile(season[0] + '.' + ' ' + 'Évad' + ' ' + episode[0] + '.' + ' ' + 'rész' + '  ' + '[COLOR blue]' + c + '[/COLOR]' + ' ' + '(' + a + ')' + ' ' + '[COLOR green]' + b.upper() + '[/COLOR]', title, d, 4, iconimage, fanart, description, b, year, genre, season[0], orig_title)            
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return
 
def getvideo():
    videoitem = xbmcgui.ListItem(label=title, thumbnailImage=iconimage)
    if season != '':
        episode = re.compile('([0-9]*). rész').findall(name)
        videoitem.setInfo(type='Video', infoLabels={'TVshowtitle': orig_title, 'Season': season, 'Episode': episode[0]})
    else:
        videoitem.setInfo(type='Video', infoLabels={'OriginalTitle': orig_title})
    xbmc.Player().play(getMovieSource(url, host), videoitem)
    return

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('' , 'Keresés')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()
        kereses(search_text, 1)
        return

##########

def getMovies(type, sort, page, genre):
    if genre == 'not': genre = ''
    
    query = moviecc_url + 'core/ajax/movies.php'
    post = {'type': 'get_movies', 'query': 'type:' + str(type) + '|' + 'sort:' + str(sort) + '|' + 'page:' + str(page) + '|' + 'genres:' + str(genre) + '|'}
    post = urllib.urlencode(post)
    i = client.source(query, post = post)
    
    return re.compile('online-filmek/(.+?)".+?\n.+?src="' + moviecc_url + '(.+?)".+?\n.+?\n.+?\n.+?\n.+?bubble_title.+?bubble="(.+?)"').findall(i)

def searchMovies(keywords, page):
    query = moviecc_url + 'core/ajax/movies.php'
    post = {'type': 'search', 'query': 'keywords:' + keywords + '|' + 'page:' + str(page)}
    post = urllib.urlencode(post)
    i = client.source(query, post = post)

    return re.compile('movie_search_cover_li.+?\n.+?\n.+?href="/online-filmek/(.+?)".+?src="/(.+?)".+?\n.+?\n.+?\n.+?">(.+?)<.+?>\((.+?)\).+?\n.+?\n.+?<p>([^<]*)').findall(i)

def getMovieSources(i):
    i = client.source('http://filmbazis.org/' + re.compile('filmbazis.org\/(.+?)\/').findall(i)[0])
    i = re.compile('movie_id:(.+?)\|').findall(i)[0]
    query = 'http://filmbazis.org/movies.php'
    post = {'type': 'get_movie_links', 'query': 'movie_id:' + i + '|' + 'season:0'}
    post = urllib.urlencode(post)
    i = client.source(query, post = post)
    i = i.replace('\n','')
    return re.compile('bubble="(.+?)".+?site.+?">(.+?)<[b|/|f].+?quality[ |"].+?>(.+?)</.+?href="(.+?)"').findall(i)

def getSeason():
    fanart_info = [' ',' ','0',' ',' ', ' ']
    
    addon_settings = xbmcaddon.Addon()
    
    i = client.source(moviecc_url + 'online-filmek/' + url)
    plot_info = re.compile('plot">\s*([^<]*)').findall(i)[0]
    plot_info = plot_info.strip('\t\n\r')
    if '<h2></h2>' not in i:
        orig_title = re.compile('</h1>\n.+?<h2>(.+?)</h2>').findall(i)[0]
    else:
        orig_title = name
    if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
        if 'imdb_id=tt' in i:
            imdb_id = re.compile('m/title/([^"/]+)"').findall(i)[0]        
            if imdb_id:
                fanart_info = find_fanart(imdb_id)
        else:
            fanart_info[0] = iconimage
    if fanart_info[0] == ' ':
        fanart_info[0] = iconimage
    
    movie_id = re.compile('filmbazis.org\/(.+?)\/').findall(i)[0]
    i = client.source('http://filmbazis.org/' + movie_id)
    season = re.compile('<tr id="season_(.+?)"').findall(i)
    for a in season:
        addDir(a + '.' + ' ' + 'Évad', movie_id, 9, iconimage, fanart_info[0], plot_info, '', '', fanart_info[2], fanart_info[3], name, orig_title)
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def getEpisodes():
    season = re.compile('([0-9]*). ').findall(name)
    i = client.source('http://filmbazis.org/' + url)
    movie_id = re.compile('movie_id:(.+?)\|').findall(i)
    query = 'http://filmbazis.org/movies.php'
    post = {'type': 'get_movie_links', 'query': 'movie_id:' + movie_id[0] + '|' + 'season:' + season[0]}
    post = urllib.urlencode(post)
    i = client.source(query, post = post)

    episode = re.compile('<tr id="episode_([0-9]*).+?\n.+?\n.+?\n.+?\n.+?\n.+?alt="(.+?)"').findall(i)
    for a, b in episode:
        addDir(season[0] + '.' + ' ' + 'Évad' + ' ' + a + '.' + ' ' + 'rész' + ' ' + '(' + b + ')', movie_id[0], 10, iconimage, fanart, description, '', '', year, genre, title, orig_title)   
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

##########
def getMovieSource(url, type):

    i = client.source(url)
    i = client.parseDOM(i, 'table', attrs={'class': 'links'})
    i = client.parseDOM(i, 'a', attrs={'target': '_blank'}, ret='href')[0]
    
    direct_url = msresolver.resolve(i)
    if isinstance(direct_url, basestring):
        return direct_url
    else:
           just_removed(type)
    
##########

def getConstants():
        try:
            try: hostDict = msresolver.relevant_resolvers(order_matters=True)
            except: hostDict = msresolver.plugnplay.man.implementors(msresolver.UrlResolver)
            hostDict = [i.domains for i in hostDict if not '*' in i.domains]
            hostDict = [i.lower() for i in reduce(lambda x, y: x+y, hostDict)]
            hostDict = [i.split('.')[0] for i in hostDict]
            hostDict = list(set(hostDict))
        except:
            hostDict = []
        return hostDict

def addDir(name, url, mode, iconimage, fanart, description, page, category, year, genre, title, orig_title):
    addon_settings = xbmcaddon.Addon()
    
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&category="+str(category)+"&page="+str(page)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&year="+urllib.quote_plus(year)+"&genre="+urllib.quote_plus(genre)+"&title="+urllib.quote_plus(title)+"&orig_title="+urllib.quote_plus(orig_title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description, "Year": year, "Genre": genre } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    return ok

def addFile(name, title, url, mode, iconimage, fanart, description, host, year, genre, season, orig_title):
    addon_settings = xbmcaddon.Addon()
    
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&title="+urllib.quote_plus(title)+"&host="+urllib.quote_plus(host)+"&year="+urllib.quote_plus(year)+"&genre="+urllib.quote_plus(genre)+"&season="+urllib.quote_plus(season)+"&orig_title="+urllib.quote_plus(orig_title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Year": year, "Genre": genre, "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    xbmcplugin.setContent(addon_handle, 'movies')    
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = 0
category = ''
search_text = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    title = urllib.unquote_plus(params["title"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    category = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    search_text = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    host = urllib.unquote_plus(params["host"])
except:
    pass
try:        
    year = urllib.unquote_plus(params["year"])
except:
    pass
try:        
    genre = urllib.unquote_plus(params["genre"])
except:
    pass
try:        
    season = urllib.unquote_plus(params["season"])
except:
    pass
try:        
    orig_title = urllib.unquote_plus(params["orig_title"])
except:
    pass

if mode == None:
    home()
elif mode == 1:
    filmek()
elif mode == 2:
    listak()
elif mode == 3:
    forrasok_Film()
elif mode == 4:
    getvideo()
elif mode == 5:
    open_search_panel()
elif mode == 6:
    kereses(search_text, page)
elif mode == 7:
    sorozatok()
elif mode == 8:
    getSeason()
elif mode == 9:
    getEpisodes()
elif mode == 10:
    forrasok_Sorozat()
elif mode == 11:
    getType()
elif mode == 12:
    kategoriak()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
