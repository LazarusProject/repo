# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, time, xbmcaddon, os, urlparse, json, base64

import msresolver as urlresolver
from resources.lib import client
from resources.lib import control
from resources.lib import metainfo


REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)



moviecc_url = 'http://www.moovie.cc/'
host_url = 'http://filmbazis.org/'
addon_handle = int(sys.argv[1])


def setviewmode(mode):
    mainview = int(control.setting('mainview'))
    streamview = int(control.setting('streamview'))

    if mode == 'main_folder':
        if mainview == 1:
            mainview = 502
        elif mainview == 2:
            mainview = 51
        elif mainview == 3:
            mainview = 500
        elif mainview == 4:
            mainview = 501
        elif mainview == 5:
            mainview = 508
        elif mainview == 6:
            mainview = 504
        elif mainview == 7:
            mainview = 503
        elif mainview == 8:
            mainview = 515    
        else:
            mainview = 0
        return(mainview)
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %mainview)
    elif mode == 'movie_folder':
        if streamview == 1:
            streamview = 502
        elif streamview == 2:
            streamview = 51
        elif streamview == 3:
            streamview = 500
        elif streamview == 4:
            streamview = 501
        elif streamview == 5:
            streamview = 508
        elif streamview == 6:
            streamview = 504
        elif streamview == 7:
            streamview = 503
        elif streamview == 8:
            streamview = 515
        else:
            streamview = 0
        return(streamview)            
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %streamview)
 
    return


def home():
    addDir('Filmek',                     '', 1, '', '', '1', 1, '', '', '')
    addDir('Sorozatok',                  '', 1, '', '', '2', 1, '', '', '')
    addDir('Keresés',                    '', 5, '', '', '', 1, '', '', '')
    return


def filmek():
    addDir('Legújabb',                  '', 2, '', '', description, 1, 'new', '', '0')
    addDir('Legfrissebb (megjelenés)',  '', 2, '', '', description, 1, 'year', '', '0')
    addDir('Legnézettebb',              '', 2, '', '', description, 1, 'most_watched', '', '0')
    addDir('Legjobbra értékelt',        '', 2, '', '', description, 1, 'most_pop', '', '0')
    addDir('Kategóriák',                '', 12, '', '', description, 1, 'most_watched', '', '')
    return


def listak():
    m = 3 if description == '1' else 8
    gen = '|genres:' + title + ',|' if not title == '0' else ''
    query = urlparse.urljoin(moviecc_url, '/core/ajax/movies.php')
    post = urllib.urlencode({'type': 'get_movies', 'query': 'type:' + description + '|sort:' + category + '|page:' + str(page) + gen})
    i = client.request(query, post = post)
    
    result = client.parseDOM(i, 'li', attrs={'class': 'movie_cover_li'})
    for item in result:
        try:
            url = client.parseDOM(item, 'a', ret='href')[0]
            url = urlparse.urljoin(moviecc_url, url)
            
            img = client.parseDOM(item, 'img', ret='src')[0]
            img = urlparse.urljoin(moviecc_url, img)
            
            titl = client.parseDOM(item, 'a', ret='bubble')[0]
            titl = client.replaceHTMLCodes(titl)
            titl = titl.encode('utf-8')
            
            addDir(titl, url, m, img, img, description, 1, '', '', '')
        except:
            pass
    addDir('[COLOR green]Következő oldal[/COLOR]', '', 2, '', '', description, page + 1, category, '', gen)
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def kategoriak():
    i = client.request(moviecc_url)
    result = client.parseDOM(i, 'select', attrs={'id': 's_genres'})
    genre = client.parseDOM(result, 'option')
    id = client.parseDOM(result, 'option', ret='value')
    result = zip(genre, id)
    
    for item in result:
        try:
            id = item[1]
            id = id.encode('utf-8')
            
            genre = item[0]
            genre = genre.encode('utf-8')
            addDir(genre, '', 2, '', '', description, 1, 'new', '', id)
        except:
            pass


def getType():
    i =  client.request(url)
    query = client.parseDOM(i, 'table', attrs={'class': 'links'})
    query = client.parseDOM(query, 'a', ret='href')[0]
    i = client.request(query)
    if 'g_season = "0"' in i:
        m = 3
    else:
        m = 8
    addDir(name, url, m, iconimage, fanart, '', '', '', '', '')
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)


def forrasok_Film():
    hostDict = getConstants()

    i =  client.request(url)
    try:
        plot_info = client.parseDOM(i, 'div', attrs={'id': 'plot'})[0]
        plot_info = plot_info.encode('utf-8').strip()
    except: plot_info = '0'

    try: imdb_id = re.search('imdb.com/title/(tt[0-9]+)/', i).group(1)   
    except: imdb_id = '0'

    meta = metainfo.get_movie(imdb_id, name)
    if not 'plot' in meta: meta.update({'plot': plot_info})

    movie_id = re.search('movie_id\s*:([0-9]+)', i).group(1)
    post = urllib.urlencode({'type': 'get_movie_links', 'query': 'movie_id:' + movie_id + '|' + 'season:0'})
    query = urlparse.urljoin(host_url, '/movies.php')
    i = client.request(query, post = post)

    i = i.replace('\n','')
    result = client.parseDOM(i, 'tr', attrs={'class': 'movie-link'})
    for item in result:
        try:
            host = client.parseDOM(item, 'span')[0]
            host = host.encode('utf-8').split('.')[0].strip()
            if not host.lower() in hostDict: raise Exception()
            
            lang = client.parseDOM(item, 'img', ret='alt')[0]
            lang = lang.encode('utf-8')
            
            quality = client.parseDOM(item, 'span')[1]
            quality = quality.encode('utf-8')

            link = client.parseDOM(item, 'a', ret='href')[0]
            addFile('[COLOR blue]%s[/COLOR] | %s | [COLOR green]%s[/COLOR]' % (quality, lang, host), name, link, 4, iconimage, meta)
        except:
            pass
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def forrasok_Sorozat():    
    meta = json.loads(metastring)
    
    hostDict = getConstants()
    
    season = meta['season'].encode('utf-8')
    episode = meta['episode'].encode('utf-8')
    n_episode = str(int(episode) + 1)

    post = urllib.urlencode({'type': 'get_movie_links', 'query': 'movie_id:' + url + '|season:' + season})
    query = urlparse.urljoin(host_url, '/movies.php')
    i = client.request(query, post = post)

    if '<tr id="episode_' + n_episode in i:
        n = 'episode_' + n_episode + '"'
    else:
        n = '</a></td></tr>'

    i = re.compile('episode_' + episode + '"([\S\s]*)' + n).findall(i)[0]
    
    result = client.parseDOM(i, 'tr', attrs={'class': 'movie-episode-link movie-episode-' + episode})
    for item in result:
        try:
            host = client.parseDOM(item, 'span')[0]
            host = host.encode('utf-8').split('.')[0].strip()
            if not host.lower() in hostDict: raise Exception()
            
            lang = client.parseDOM(item, 'img', ret='alt')[0]
            lang = lang.encode('utf-8')
            
            quality = client.parseDOM(item, 'span')[1]
            quality = quality.encode('utf-8')

            link = client.parseDOM(item, 'a', ret='href')[0]
            addFile('%sx%s | [COLOR blue]%s[/COLOR] | %s | [COLOR green]%s[/COLOR]' % (season, episode, quality, lang, host), title, link, 4, iconimage, meta)            
        except:
            pass

    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def getvideo():
    try: 
        control.busy() 
        i = client.request(url)
        i = client.parseDOM(i, 'table', attrs={'class': 'links'})
        u = client.parseDOM(i, 'a', attrs={'target': '_blank'}, ret='href')[0]

        direct_url = None
        hmf = urlresolver.HostedMediaFile(url=u, include_disabled=True, include_universal=False)
        if hmf.valid_url() == True: direct_url = hmf.resolve()
        if direct_url == False or direct_url == None: raise Exception()
        
        meta = json.loads(metastring)

        if 'episode' in meta: label = '%s %sx%s' % (title, meta['season'].encode('utf-8'), meta['episode'].encode('utf-8'))
        else: label = title
        videoitem = xbmcgui.ListItem(label=label, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels=meta)
        
        control.idle()
        
        xbmc.Player().play(direct_url, videoitem)
    except:
        control.idle()
        control.infoDialog('A keresett videót eltávolították')

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('' , 'Keresés')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()
        searchMovies(search_text)
        return

##########

def searchMovies(keywords):
    query = urlparse.urljoin(moviecc_url, '/core/search.json')
    i = client.request(query)
    result = json.loads(i)
    for item in result:
        try:
            if (keywords.lower() in item['title_hun'].lower()) or (keywords.lower() in item['title_eng'].lower()):
                title = item['title_hun'].encode('utf-8')
                img = urlparse.urljoin(moviecc_url, '/images/movies/' + item['id'] +'/poster.jpg')
                link = urlparse.urljoin(moviecc_url, '/online-filmek/' + item['title_url'])
                addDir(title, link, 11, img, img, '', '', '', '', '')
        except:
            pass
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)

    
def getSeason(): 
    i = client.request(url)
    try:
        plot_info = client.parseDOM(i, 'div', attrs={'id': 'plot'})[0]
        plot_info = plot_info.encode('utf-8').strip()
    except: plot_info = '0'
    
    movie_id = re.search('movie_id\s*:([0-9]+)', i).group(1)
    
    try: imdb_id = re.search('imdb.com/title/(tt[0-9]+)/', i).group(1)
    except: imdb_id = '0'

    meta = metainfo.get_tvshow(imdb_id, name)
    if not 'plot' in meta: meta.update({'plot': plot_info})

    query = client.parseDOM(i, 'table', attrs={'class': 'links'})
    query = client.parseDOM(query, 'a', ret='href')[0]

    i = client.request(query)
    season = re.findall('id\s*=\s*"season_([0-9]+)', i)
    for a in season:
        meta.update({'season': a})
        addDir('%s. évad' % a, movie_id, 9, iconimage, '', '', '', '', meta, name)

    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def getEpisodes():
    meta = json.loads(metastring)
    season = meta['season'].encode('utf-8')

    post = urllib.urlencode({'type': 'get_movie_links', 'query': 'movie_id:' + url + '|' + 'season:' + season})
    query = urlparse.urljoin(host_url, '/movies.php')
    i = client.request(query, post = post)
    i = i.replace('\n', '')
    episode = re.compile('<tr id="episode_([0-9]+).+?alt="(.+?)"').findall(i)
    for a, b in episode:
        meta.update({'episode': a})
        addDir('%s. évad %s. epizód (%s)' % (season, a, b), url, 10, iconimage, '', '', '', '', meta, title)   

    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return


def getConstants():
        try:
            try: hostDict = urlresolver.relevant_resolvers(order_matters=True)
            except: hostDict = urlresolver.plugnplay.man.implementors(urlresolver.UrlResolver)
            hostDict = [i.domains for i in hostDict if not '*' in i.domains]
            hostDict = [i.lower() for i in reduce(lambda x, y: x+y, hostDict)]
            hostDict = [i.rsplit('.', 1)[0] for i in hostDict]
            hostDict = list(set(hostDict))
        except:
            hostDict = []
        return hostDict


def get_trailer():
    url = base64.urlsafe_b64decode('aHR0cDovL3d3dy5maWxtY3NvdGFueS5uZXQvX2NvbnRyb2xsZXJzL3NpdGVIYW5kbGVyLnBocD9jb21tYW5kPWxvYWRZVFRyYWlsZXImYWxpYXM9')
    try:
        result = client.request(url + name.replace(' ', '+'))
        youtube_id = re.compile('www\.youtube\.com/embed/([^\?]+)').findall(result)[0]
        
        if youtube_id:
            direct_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + youtube_id
            xbmc.Player().play(direct_url)
    except:
        return


def addDir(name, url, mode, iconimage, fanart, description, page, category, meta, title):
    if meta == '': meta = {'fanart': ''}
    metastring = json.dumps(meta)
    fanart = meta['fanart'] if not meta['fanart'] == '' else iconimage
    if 'episode' in meta: type = 'episodes'
    elif 'season' in meta and not 'episode' in meta: type = 'tvshows'
    else: type = 'movies'
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&category="+str(category)+"&page="+str(page)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&metastring="+urllib.quote_plus(metastring)+"&title="+urllib.quote_plus(title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels=meta )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    xbmcplugin.setContent(addon_handle, type)
    return ok

def addFile(name, title, url, mode, iconimage, meta):
    metastring = json.dumps(meta)
    fanart = meta['fanart'] if not meta['fanart'] == '' else iconimage
    type = 'episodes' if 'episode' in meta else 'movies'
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&metastring="+urllib.quote_plus(metastring)+"&title="+urllib.quote_plus(title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels=meta )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    xbmcplugin.setContent(addon_handle, type)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = 0
category = ''
search_text = ''
title = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    title = urllib.unquote_plus(params["title"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    category = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    search_text = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    metastring = urllib.unquote_plus(params["metastring"])
except:
    pass


if mode == None:
    home()
elif mode == 1:
    filmek()
elif mode == 2:
    listak()
elif mode == 3:
    forrasok_Film()
elif mode == 4:
    getvideo()
elif mode == 5:
    open_search_panel()
elif mode == 7:
    sorozatok()
elif mode == 8:
    getSeason()
elif mode == 9:
    getEpisodes()
elif mode == 10:
    forrasok_Sorozat()
elif mode == 11:
    getType()
elif mode == 12:
    kategoriak()
elif mode == 13:
    get_trailer()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
