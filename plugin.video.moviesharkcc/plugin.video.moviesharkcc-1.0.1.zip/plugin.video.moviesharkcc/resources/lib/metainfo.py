# -*- coding: utf-8 -*-

from resources.lib import client
from resources.lib import control

import os,sys,re,json,urllib,urlparse


mooviecc_url = control.setting('mscc_url')
fanart_tv_art_link = 'http://webservice.fanart.tv/v3/%s/%s'
fanart_tv_headers = {'api-key': 'YTVmNDlkYjM0ZWJlZmYxZTRmNTIwNjQxYmExYWRjYTU='.decode('base64')}
tvdb_by_imdb = 'http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s'

def get_meta(i, title, type):
    meta = {'fanart': '', 'title': title}
    try:
        try: imdb = re.search('imdb.com/title/(tt[0-9]+)/', i).group(1)
        except: imdb = '0'
        imdb = imdb.encode('utf-8')
        if not imdb == '0': meta.update({'imdb': imdb})
        
        try:
            plot = client.parseDOM(i, 'div', attrs={'id': 'plot'})[0]
            plot = plot.split('<br>')[1]
            plot = client.replaceHTMLCodes(plot)
        except: plot = '0'
        plot = plot.encode('utf-8')
        if not plot == '0': meta.update({'plot': plot})
        
        try: 
            poster = client.parseDOM(i, 'div', attrs={'id': 'poster'})
            poster = client.parseDOM(poster, 'img', ret='src')[0]
            poster = urlparse.urljoin(mooviecc_url, poster)
        except: poster = '0'
        poster = poster.encode('utf-8')
        if not poster == '0': meta.update({'poster': poster})

        try:
            year = client.parseDOM(i, 'tr')[1]
            year = client.parseDOM(year, 'a')[0]
        except:
            year = '0'
        year = year.encode('utf-8')
        if not year == '0': meta.update({'year': year})
        
        try:
            duration = re.search('(\d+)', client.parseDOM(i, 'tr')[2]).group(1)
            duration = str(int(duration) * 60)
        except: duration = '0'
        duration = duration.encode('utf-8')
        if not duration == '0': meta.update({'duration': duration})
        
        try:
            rating = client.parseDOM(i, 'tr')[3]
            rating, votes = re.search('td>(\d.+?)\s/\s*(\d.+?)\s', rating).groups()
        except: rating = votes = '0'
        rating = rating.encode('utf-8')
        votes = votes.encode('utf-8')
        if not rating == '0': meta.update({'rating': rating})
        if not votes == '0': meta.update({'votes': votes})
        
        try:
            genre = client.parseDOM(i, 'tr')[4]
            genre = client.parseDOM(genre, 'a')
            genre = ' / '.join(genre)
        except: genre = '0'
        genre = genre.encode('utf-8')
        if not genre == '0': meta.update({'genre': genre})
        
        try:
            writer = client.parseDOM(i, 'tr')[6]
            writer = client.parseDOM(writer, 'a')[0]
            writer = client.replaceHTMLCodes(writer)
        except: writer = '0'
        writer = writer.encode('utf-8')
        if not writer == '0': meta.update({'writer': writer})

        try:
            director = client.parseDOM(i, 'tr')[7]
            director = client.parseDOM(director, 'a')[0]
            director = client.replaceHTMLCodes(director)
        except: director = '0'
        director = director.encode('utf-8')
        if not director == '0': meta.update({'director': director})

        try:
            cast = client.parseDOM(i, 'tr')[8]
            cast = client.parseDOM(cast, 'a')
            cast = [client.replaceHTMLCodes(x) for x in cast]
            try: cast = [x.encode('utf-8') for x in cast]
            except: cast = []
        except: cast = '0'
        if not cast == '0': meta.update({'cast': cast})
        
        if type == 'tvshow': meta.update({'tvshowtitle': title, 'mediatype': 'episode'})

        try:
            if not control.setting('fanart_tv') == 'true' or imdb == '0': raise Exception()
            if type == 'tvshow':
                url = tvdb_by_imdb % imdb

                result = client.request(url, timeout='10')

                try: tvdb = client.parseDOM(result, 'seriesid')[0]
                except: tvdb = '0'
                
                try: name = client.parseDOM(result, 'SeriesName')[0]
                except: name = '0'
                dupe = re.findall('[***]Duplicate (\d*)[***]', name)
                if dupe: tvdb = str(dupe[0])

                if tvdb == '' or tvdb == '0': raise Exception()
            
                fanart_tv_link = fanart_tv_art_link % ('tv', tvdb)
            else: fanart_tv_link = fanart_tv_art_link % ('movies', imdb)
            art = client.request(fanart_tv_link, headers=fanart_tv_headers, timeout='10', error=True)
            art = json.loads(art)
        except:
            art = False

        try:
            if 'showbackground' in art: fanart = art['showbackground']
            elif 'moviebackground' in art: fanart = art['moviebackground']
            else: fanart = art['moviethumb']
            fanart = [x for x in fanart if x.get('lang') == 'en'][::-1] + [x for x in fanart if x.get('lang') == '00'][::-1]
            fanart = fanart[0]['url'].encode('utf-8')
        except:
            fanart = '0'

        try:
            if 'tvbanner' in art: banner = art['tvbanner']
            else: banner = art['moviebanner']
            banner = [x for x in banner if x.get('lang') == 'en'][::-1] + [x for x in banner if x.get('lang') == '00'][::-1]
            banner = banner[0]['url'].encode('utf-8')
        except:
            banner = '0'

        try:
            if 'hdtvlogo' in art: clearlogo = art['hdtvlogo']
            elif 'hdmovielogo' in art: clearlogo = art['hdmovielogo']
            else: clearlogo = art['clearlogo']
            clearlogo = [x for x in clearlogo if x.get('lang') == 'en'][::-1] + [x for x in clearlogo if x.get('lang') == '00'][::-1]
            clearlogo = clearlogo[0]['url'].encode('utf-8')
        except:
            clearlogo = '0'

        try:
            if 'hdclearart' in art: clearart = art['hdclearart']
            elif 'hdmovieclearart' in art: clearart = art['hdmovieclearart']
            else: clearart = art['clearart']
            clearart = [x for x in clearart if x.get('lang') == 'en'][::-1] + [x for x in clearart if x.get('lang') == '00'][::-1]
            clearart = clearart[0]['url'].encode('utf-8')
        except:
            clearart = '0'

        meta.update({'trailer': '%s?mode=13&name=%s' % (sys.argv[0], title), 'fanart': fanart, 'banner': banner, 'clearlogo': clearlogo, 'clearart': clearart})

        return meta
    except:
        return meta
