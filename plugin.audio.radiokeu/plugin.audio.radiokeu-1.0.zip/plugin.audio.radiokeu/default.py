# -*- coding: utf-8 -*-

import xbmc,xbmcgui,urllib,re,xbmcplugin
from resources.lib import client, control


radiok_mainpage = 'http://radiok.eu'
download_page = 'http://www.radiok.ipdns.hu/letoltes/'


def folders():
    result = client.request(radiok_mainpage)
    
    result = client.parseDOM(result, 'ul', attrs={'class':'uk-nav uk-nav-parent-icon uk-nav-side'})[0]
    result = result.split('<li>')
    result = [i for i in result if 'felvetelek' in i]
    for item in result:
        try:
            i = re.compile('<a href="?\'?([^"\'>]*).+?/i>\s?(.+?)<').findall(item)[0]
            addDir3(i[1].encode('utf-8'), radiok_mainpage + i[0], 1, control.addonIcon(), '', '')
        except:
            pass


def get_episodes():
    try:
        result = client.request(url)
    
        result = client.parseDOM(result, 'iframe', ret='src')
        result = [i for i in result if '?dir=' in i][0]
        
        dir = client.request(result)
        dir = client.parseDOM(dir, 'a', ret='href')
        dir = [i for i in dir if '.mp3' in i]
        
        for item in dir:
            try:
                title = item.rsplit('/')[-1].replace('.mp3','').replace('-', ' ')
                addDir4(title.encode('utf-8'), download_page + item, 2, '', '', '')
            except:
                pass
    except:
        return


def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
show_title=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass


if mode==None or url==None or len(url)<1:
    folders()
elif mode==1:
    get_episodes()
elif mode==2:
    liz = xbmcgui.ListItem(name, thumbnailImage=iconimage)
    liz.setInfo(type='Audio', infoLabels={'Title': name})
    liz.setProperty('mimetype', 'audio/mpeg')
    xbmc.Player().play(url, liz)

xbmcplugin.endOfDirectory(int(sys.argv[1]))