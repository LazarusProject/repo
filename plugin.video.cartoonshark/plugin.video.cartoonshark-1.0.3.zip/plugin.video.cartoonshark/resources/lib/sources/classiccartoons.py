# -*- coding: utf-8 -*-
# modositotta /v1.0.3/: morefire

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urlparse,urllib,xbmcgui

from resources.lib.modules import client
from resources.lib.modules import control


msort = control.setting('cc_msort')
if msort == '0': order_cc = 'popular_up'
elif msort == '1': order_cc = 'abc_up'
else: order_cc = 'launch_down'


class source:
    def __init__(self):
        self.list = []
        self.main_url = 'https://rajzfilmek.online'
        self.site_name = 'Classic Cartoons'


    def categories(self, page):
        if page == '1':
            post_page = urllib.urlencode({'query': '', 'order': order_cc, 'scroll': '0'})
        elif page == 'search_cc':
            t = u'Keres\u00E9s'
            k = control.keyboard('', t)
            k.doModal()
            c = k.getText() if k.isConfirmed() else None
            if c == '':
                control.infoDialog(u'A keres\u00E9s nem hozott eredm\u00E9nyt')
                return self.list
            post_page = urllib.urlencode({'query': c, 'order': 'popular_up', 'scroll': '0'})
        else:
            post_page = urllib.urlencode({'query': '', 'order': order_cc, 'scroll': str(int(page) - 1), 'mud': 'scroll'})
        query = urlparse.urljoin(self.main_url, '/live-search.php?id=1')
        r = client.request(query, post=post_page)
        result = r.split('</a>')
        for i in result:
            try:
                title = client.parseDOM(i, 'div', attrs={'class': 'info'})[0]
                title = re.sub('<[\/\w\s]+>', '', title)
                title = client.replaceHTMLCodes(title)
                title = title.encode('utf-8')
                
                img = client.parseDOM(i, 'img', ret='src')[0].encode('utf-8')
                if not 'imgur' in img: img = urlparse.urljoin(self.main_url, img)
                
                url = client.parseDOM(i, 'a', ret='href')[0].encode('utf-8')

                self.list.append({'title': title, 'url': url, 'image': img})
            except:
                pass
        for i in self.list: i.update({'action': 'videos', 'page': ''})

        if not page == 'search_cc':
            try:
                self.list.append({'title': '[COLOR orange]Következő oldal >>[/COLOR]', 'url': '', 'page': str(int(page) + 1), 'image': '', 'action': 'folders', 'isFolder': True})
            except:
                pass

        return self.list


    def videos(self, url, page, source):
        r = client.request(url)
        result = r.split('<table ')
        result = [(re.search('\sid="(\d+)"', i).group(1), i) for i in result if 'watch' in i]
        result = [(i[0], client.parseDOM(i[1], 'tr')) for i in result]
        
        try:
            plot = client.parseDOM(r, 'div', attrs={'class': 'description'})[0]
            plot = re.sub('(<div class="note">[^<>]+<\/div>)', '', plot)
            plot = re.sub('(<div class="nodesc">[^<>]+<\/div>)', '', plot)
            plot = client.replaceHTMLCodes(plot)
            plot = plot.encode('utf-8')
        except:
            plot = ''
        
        try:
            img = client.parseDOM(r, 'main', attrs={'class': 'adatlap'})[0]
            img = client.parseDOM(img, 'div', ret='style')[1]
            img = re.search('url\(\'([^\']+)\'\)', img).group(1)
            img = img.encode('utf-8')
        except:
            img = ''

        for item in result:
            season = item[0]
            for x in item[1]:
                try:
                    #x = x.replace('\n', '')
                    episode = client.parseDOM(x, 'span', attrs={'class': 'middle'})[0].replace('\n', '').strip()
                    if len(episode) < 2: episode = episode.zfill(2)
                    episode = episode.encode('utf-8')
                    
                    title = client.parseDOM(x, 'td', attrs={'class': 'hu'})
                    title = client.parseDOM(title, 'span', attrs={'class': 'middle'})
                    title = [i.replace('\n', '') for i in title]
                    title = [i for i in title if not i.strip() == '']
                    title = '' if title == [] else title[0]
                    title = client.replaceHTMLCodes(title)
                    title = title.encode('utf-8')
                    
                    link = client.parseDOM(x.replace('\n', ''), 'a', ret='href')[0].encode('utf-8')

                    self.list.append({'title': '%sx%s  %s' % (season, episode, title), 'url': link, 'image': img})
                except:
                    pass

        for i in self.list: i.update({'action': 'resolve', 'source': source, 'page': '', 'plot': plot, 'isFolder': False, 'label': i['title']})

        return self.list


    def resolve(self, url):
        try:
            r = client.request(url)
            sources = re.findall('var _0x89e2=\s*\["(.+?","[^"]+)"', r)
            sources = [x.decode('unicode_escape').encode('utf-8') for x in sources]
            try: sources = list(set(sources))
            except: pass
            sources = sorted(sources, key=lambda x: re.findall('","(\w+)', x))
            autopick = control.setting('cc_autopick')
            control.idle()
            if len(sources) == 1:
                direct_link = sources[0].rsplit('","', 1)[0]
            elif len(sources) > 1:
                if autopick == '1':
                    direct_link = sources[0].rsplit('","', 1)[0]
                elif autopick == '2':
                    direct_link = sources[-1].rsplit('","', 1)[0]
                else:
                        result = xbmcgui.Dialog().select((u'Min\u0151s\u00E9g'), [source.rsplit('","', 1)[1] for source in sources])
                        if result == -1:
                            return
                        else:
                            direct_link = sources[result].rsplit('","', 1)[0]
            try:
                direct_link = client.request(direct_link, output='geturl', redirect=False)
            except:
                pass

            return direct_link
        except:
            return