# -*- coding: utf8 -*-
from resources.plugincontent import Main
Main().main()