# -*- coding: utf-8 -*-

import os,xbmc,xbmcaddon,xbmcgui,xbmcvfs


setting = xbmcaddon.Addon().getSetting

setSetting = xbmcaddon.Addon().setSetting

addonInfo = xbmcaddon.Addon().getAddonInfo

dialog = xbmcgui.Dialog()

execute = xbmc.executebuiltin

makeFile = xbmcvfs.mkdir

openFile = xbmcvfs.File

deleteFile = xbmcvfs.delete

dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')

cacheFile = os.path.join(dataPath, 'cache.db')

channelidFile = os.path.join(dataPath, 'channelid.db')


def addonIcon():
    try: return os.path.join(addonInfo('path'), 'icon.png')
    except: pass


def infoDialog(message, heading='', icon='', time=3000):
    if setting('view.info') == 'true':
        if heading == '': heading=addonInfo('name')
        if icon == '': icon = addonIcon()
        try: dialog.notification(heading, message, icon, time, sound=False)
        except: execute("Notification(%s,%s, %s, %s)" % (heading, message, time, icon))


def yesnoDialog(line1, line2, line3, heading=addonInfo('name'), nolabel='', yeslabel=''):
    return dialog.yesno(heading, line1, line2, line3, nolabel, yeslabel)


def openSettings(id=addonInfo('id')):
    try:
        idle()
        execute('Addon.OpenSettings(%s)' % id)
        if query == None: raise Exception()
    except:
        return


def idle():
    return execute('Dialog.Close(busydialog)')


def refresh():
    return execute('Container.Refresh')
