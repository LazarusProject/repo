try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

import json

from lib import control


def getChannelID():
    try:
        chlist = dict()
        dbcon = database.connect(control.channelidFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM channelid")
        items = dbcur.fetchall()
        for i in items:
            chlist[i[0].strip().encode('utf-8')] = {'id': i[1].strip().encode('utf-8'), 'country': i[2].strip().encode('utf-8')}
    except:
        chlist = {}

    return chlist


def addChannelID(channel, id, country):
    try:
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.channelidFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS channelid (""channel TEXT, ""id TEXT, ""country TEXT"");")
        dbcur.execute("DELETE FROM channelid WHERE channel = '%s' and country = '%s'" %  (channel, country))
        dbcur.execute("INSERT INTO channelid Values (?, ?, ?)", (channel, id, country))
        dbcon.commit()
    except:
        return


def deleteChannelID(id):
    try:
        try:
            dbcon = database.connect(control.playcountFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM channelid WHERE id = '%s'" % id)       
            dbcon.commit()
        except:
            pass

    except:
        return