# -*- coding: utf-8 -*-
import xbmc, urllib, re, urlparse, sys
from lib import client, control

cs_link = 'https://www.cardshare.cc'
savepath = control.setting('savefolder')
filename = control.setting('m3u.file')
pause = int(control.setting('upd_interval')) * 60
user = control.setting('cs.user')
password = control.setting('cs.password')
pincode = control.setting('cs.pin')

def getPlaylist():
    if user == '' or password == '' or pincode == '' or savepath == '' or filename == '':
            l = control.yesnoDialog('Kérlek végezd el a szükséges beállításokat!', '', '', control.addonInfo('name'), 'Mégsem', 'OK')
            if l == 1: control.openSettings()
            sys.exit()
    try:
        login = urlparse.urljoin(cs_link, '/auth/login')
        post = urllib.urlencode({'login': user, 'password': password, 'remember': '', 'security_pin': pincode})
        r = client.request(login, post=post, output='extended')
        headers = r[1]
        headers['Cookie'] = r[3]
        headers['Accept'] = 'application/json, text/javascript, */*; q=0.01'
        headers['Connection'] = 'keep-alive'
        headers['Content-Length'] = '6'
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        headers['Host'] = 'www.cardshare.cc'
        headers['Origin'] = cs_link
        headers['X-Requested-With'] = 'XMLHttpRequest'

        if not 'Logged in as' in r[0]:
            control.infoDialog('Bejelentkezés sikertelen!')
            raise Exception()

        query = urlparse.urljoin(cs_link, '/producttest/iptv')
        post = urllib.urlencode({'iptv': '1'})
        iptv = client.request(query, post=post, headers=headers)

        if not 'Congratulations!' in iptv:
            control.infoDialog('M3U letöltés sikertelen!')
            raise Exception()

        iptv = iptv.replace('\\','')
        m3u_link = re.findall('>(http[^<]+)', iptv)
        m3u_link = [i for i in m3u_link if 'get.php?auth' in i][0].strip()

        playlist = client.request(m3u_link)

        if not 'EXTINF' in playlist:
            control.infoDialog('M3U letöltés sikertelen!')
            raise Exception()

        saveList(playlist)
    except:
        return


def saveList(playlist):
    try:
        f = control.openFile(savepath + filename, 'w')
        f.write(playlist)
        f.close()
    except:
        control.infoDialog('M3U mentés sikertelen!')
        return


if __name__ == '__main__':
    getPlaylist()
    monitor = xbmc.Monitor()
    
    while not monitor.abortRequested():
        # Sleep/wait for abort
        if monitor.waitForAbort(pause):
            # Abort was requested while waiting. We should exit
            break
        getPlaylist()
