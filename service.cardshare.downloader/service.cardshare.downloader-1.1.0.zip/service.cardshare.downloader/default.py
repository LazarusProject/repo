# -*- coding: utf-8 -*-
import xbmc, urllib, re, urlparse, sys, xbmcaddon, time
from lib import client, control, chdb


try: params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
except: pass

try: action = params.get('action')
except: action = ''

cs_link = 'https://www.cardshare.cc'
savepath = control.setting('savefolder')
filename = control.setting('m3u.file')
tvgid_url = control.setting('tvgid.url')
user = control.setting('cs.user')
password = control.setting('cs.password')
pincode = control.setting('cs.pin')

last_check = int(control.setting('last_check'))
pause = int(control.setting('upd_interval'))
if pause > 24: control.setSetting('upd_interval', '18'); pause = 18


def getM3U():
    if user == '' or password == '' or pincode == '' or savepath == '' or filename == '':
            l = control.yesnoDialog(u'K\u00E9rlek v\u00E9gezd el a sz\u00FCks\u00E9ges be\u00E1ll\u00EDt\u00E1sokat!\nRegisztr\u00E1ci\u00F3: [B][COLOR blue]https://www.cardshare.cc/[/COLOR][/B]', '', '', control.addonInfo('name'), 'Mégsem', 'OK')
            if l == 1: control.openSettings()
            sys.exit()
    try:
        login = urlparse.urljoin(cs_link, '/auth/login')
        post = urllib.urlencode({'login': user, 'password': password, 'remember': '', 'security_pin': pincode})
        r = client.request(login, post=post, output='extended')
        headers = r[1]
        headers.update({'Cookie': r[3],
                        'Accept': 'application/json, text/javascript, */*; q=0.01',
                        'Connection': 'keep-alive',
                        'Content-Length': '6',
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'Host': 'www.cardshare.cc',
                        'Origin': cs_link,
                        'X-Requested-With': 'XMLHttpRequest' 
                        })

        if not '<em>%s</em>' % user.lower() in r[0].lower():
            control.infoDialog(u'Bejelentkez\u00E9s sikertelen!')
            raise Exception()

        query = urlparse.urljoin(cs_link, '/producttest/iptv')
        post = urllib.urlencode({'iptv': '1'})
        iptv = client.request(query, post=post, headers=headers)

        iptv = iptv.replace('\\','')
        m3u_link = re.findall('>(http[^<]+)', iptv)
        m3u_link = [i for i in m3u_link if 'get.php?auth' in i][0].strip()
        
        if not m3u_link:
            control.infoDialog(u'M3U let\u00F6lt\u00E9s sikertelen!')
            raise Exception()
                
        m3u = client.request(m3u_link)

        if not 'EXTINF' in m3u:
            control.infoDialog(u'M3U let\u00F6lt\u00E9s sikertelen!')
            raise Exception()

        saveList(m3u)
    except:
        return


def saveList(m3u):
    try: 
        M3U_EXT_LINE = '#EXTINF:-1 group-title="COUNTRY" tvg-id="TVG_ID", CHANNEL_NAME'
        channel_list = read_m3u(m3u)
        tvglist = chdb.getChannelID()
    
        with open(savepath + filename, 'w') as iptvsimple_m3u:
            iptvsimple_m3u.write('#EXTM3U' + '\n\n')

            for channel in channel_list:
                try:
                    ext_line = re.sub('CHANNEL_NAME', channel['name'], M3U_EXT_LINE)
                    if channel['name'] in tvglist and tvglist[channel['name']]['country'] == channel['country']:
                        ext_line = re.sub('TVG_ID', tvglist[channel['name']]['id'], ext_line)
                    else:
                        ext_line = re.sub(' tvg-id="TVG_ID"', '', ext_line)
                    ext_line = re.sub('COUNTRY', channel['country'], ext_line)
                    iptvsimple_m3u.write(ext_line + '\n')
                    iptvsimple_m3u.write(channel['url'] + '\n')
                except:
                    pass
        control.setSetting('force', 'false')
        control.infoDialog(u'M3U let\u00F6lt\u00E9s k\u00E9sz')
    except:
        control.infoDialog(u'M3U ment\u00E9s sikertelen!')
        return


def read_m3u(m3u):
    chlist = []
    channels = re.compile('^#EXTINF:\s*-?[0-9]+,\s*(.+?)\s*\(([A-Z0-9]+)\)\s*\n\s*(.+?)\s*$',re.I+re.M+re.U+re.S).findall(m3u)
    for name, country, url in channels:
        try: name = name.encode('utf-8')
        except: pass
        try: country = country.encode('utf-8')
        except: pass
        try: url = url.encode('utf-8')
        except: pass

        chlist.append({'name': name, 'country': country, 'url': url})
    return chlist


def downloadChannelID():
    try:
        list = client.request(tvgid_url)
        try: list = list.decode('base64')
        except: pass
        list = eval('[%s]' % list)
        for i in list:
            try:
                chdb.addChannelID(i[0].decode('utf-8'), i[1].decode('utf-8'), i[2].decode('utf-8'))
            except:
                pass
        control.setSetting('second', 'false')
        control.infoDialog(u'Csatorna ID let\u00F6lt\u00E9s k\u00E9sz')
    except:
        return


def addChannelID():
    try:
        channel_name = control.setting('channel_name')
        channel_id = control.setting('channel_id')
        country_code = control.setting('country_code')
        control.setSetting('channel_name', ''); control.setSetting('channel_id', ''); control.setSetting('country_code', '')
        if (channel_name == '' or channel_id == '' or country_code == ''): raise Exception()
        chdb.addChannelID(channel_name, channel_id, country_code)
        control.infoDialog("'%s' %s" % (channel_name, u'hozz\u00E1adva'))
    except:
        return

if control.setting('second') == 'true':
    downloadChannelID()

elif action == 'add_channelid':
    addChannelID()

elif action == 'download_cid':
    downloadChannelID()

elif action == 'getm3u':
    getM3U()

elif __name__ == '__main__':
    if control.setting('init.download') == 'true' or control.setting('force') == 'true':
        getM3U()
        control.setSetting('last_check', str(int(time.time())))

    monitor = xbmc.Monitor()

    while not monitor.abortRequested():
        now = int(time.time())
        last_check = int(control.setting('last_check'))
        if (last_check >= 0 and last_check < now - (pause * 60 * 60)):
            getM3U()
            control.setSetting('last_check', str(int(time.time())))

        xbmc.sleep(10000)
