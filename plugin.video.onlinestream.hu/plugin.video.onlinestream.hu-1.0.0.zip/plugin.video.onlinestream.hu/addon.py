# -*- coding: utf-8 -*-

'''
    Online Stream Addon for Kodi
    Copyright (C) 2017 aky01
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urlparse,sys

from resources.lib import onlinestream
from resources.lib import directory

tv_indexer = onlinestream.tv()
radio_indexer = onlinestream.radio()

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))

action = params.get('action')

channels = params.get('channels')

title = params.get('title')

image = params.get('image')

station_id = params.get('station_id')

search_text = params.get('search_text')


def root():        
    root_list = [ 
    {
    'title': 32001,
    'action': 'tv_list',
    'icon': 'tvs.png'
    },
    {
    'title': 32002,
    'action': 'radio_list',
    'icon': 'radios.png'
    },          
    {
    'title': 32004,
    'action': 'search',
    'icon': 'search.png'
    }
    ]

    directory.add(root_list)


if action == None:
    root()

elif action == 'tv_list':
   tv_indexer.tv_list(search_text)

elif action == 'radio_list':
    radio_indexer.radio_list(search_text)

elif action == 'tv_stream_list':
    tv_indexer.stream_list(station_id, image)

elif action == 'radio_stream_list':
    radio_indexer.stream_list(station_id, image)
    
elif action == 'tv_track_list':
    tv_indexer.track_list(station_id)
    
elif action == 'radio_track_list':
    radio_indexer.track_list(station_id)

elif action == 'search_tv':
    tv_indexer.search()

elif action == 'search_radio':
    radio_indexer.search()

elif action == 'search':
    lst = [
    {
    'title': 32014,
    'action': 'search_tv',
    'icon': 'search.png'
    },
    {
    'title': 32015,
    'action': 'search_radio',
    'icon': 'search.png'
    }
    ]

    directory.add(lst)
