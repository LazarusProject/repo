# -*- coding: utf-8 -*-

'''
    Online Stream Addon for Kodi
    Copyright (C) 2017 aky01
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,urllib,re,urlparse,xbmcaddon,xbmcgui,xbmc

from resources.lib import client
from resources.lib import cache
from resources.lib import directory

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonicon__ = __addon__.getAddonInfo('icon')
__lang__ = xbmcaddon.Addon().getLocalizedString
__dialog__ = xbmcgui.Dialog()
onlinestream_url = 'https://onlinestream.hu'
headers = {'User-Agent': 'Online Stream for Kodi/%s' % __addon__.getAddonInfo('version')}


def get_stations():
    try:
        query = urlparse.urljoin(onlinestream_url, '/list.xml')
        xml = client.request(query, headers=headers)
        try: xml = xml.decode('iso-8859-1').encode('utf8')
        except: pass
        stations = client.parseDOM(xml, 'station')
        if not stations: raise Exception()
        try: stations = [i.encode('iso-8859-1').decode('utf8') for i in stations]
        except: pass
        return stations
    except:
        __dialog__.notification(__addonname__, __lang__(32011).encode('utf-8'), __addonicon__, 3000, sound=False); cache.clear()


def resolve(url, image, title='', mediatype='Video', multi_res=False):
    yt_link = re.search("(?:youtube\.com\/\S*(?:(?:\/e(?:mbed))?\/|watch\?(?:\S*?&?v\=))|youtu\.be\/)([a-zA-Z0-9_-]{6,11})", url)
    if yt_link:
        url = 'plugin://plugin.video.youtube/play/?video_id=%s' % yt_link.group(1)

    if not yt_link and multi_res == True:
        r = client.request(url)
        query = re.search("(https?.+?m3u8)", r)
        if query:
            query = query.group(1)
            try:
                r = client.request(query)
                sources = re.findall('RESOLUTION\s*=\s*(\d+x\d+).+\n\s*(.*\.m3u8)', r)
                if len(sources) > 1:
                    q = __dialog__.select(__lang__(32013).encode('utf-8'), [i[0] for i in sources])
                    if q == -1: return
                else: q = 0
                url = query.rsplit('/', 1)[0] + '/' + sources[q][1]
            except:
                url = query

    item = xbmcgui.ListItem(path=url)
    item.setArt({'icon': image, 'thumb': image})
    item.setInfo(type=mediatype, infoLabels={'Title': title})
    xbmc.Player().play(url, item)


class radio:
    def __init__(self):
        self.list = []


    def radio_list(self, searchtext = None):
        self.list = self.get_radio_list()

        if self.list == None: return
        if not searchtext == None:
            self.list = [i for i in self.list if searchtext.lower() in i['title'].lower()]
            if not self.list:
                __dialog__.notification(__addonname__, __lang__(32012).encode('utf-8'), __addonicon__, 3000, sound=False)
                return

        for i in self.list: i.update({'action': 'radio_stream_list'})

        directory.add(self.list, infotype='Music', isFolder=False)


    def get_radio_list(self):
        stations = cache.get(get_stations, 1)

        stations = [i for i in stations if client.parseDOM(i, 'tv')[0] == '0']

        for item in stations:
            try:
                try: item = item.encode('iso-8859-1').decode('utf8')
                except: pass
                title = client.parseDOM(item, 'title')[0]
                title = client.replaceHTMLCodes(title).replace("&apos;", "'").strip().encode('utf-8')
                
                description = client.parseDOM(item, 'description')[0]
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").strip().encode('utf-8')

                station_id = client.parseDOM(item, 'station_id')[0].strip().encode('utf-8')
                
                listeners = client.parseDOM(item, 'listeners')[0].strip().encode('utf-8')
                listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else ''
                
                listeners_peak = client.parseDOM(item, 'listeners_peak')[0].strip().encode('utf-8')
                
                logo = client.parseDOM(item, 'logo')[0].strip().encode('utf-8')
                
                broadcast = client.parseDOM(item, 'broadcast')[0].strip().encode('utf-8')
                broadcast = 'DAB+/FM' if broadcast == '1' else ''
                
                station_title = '[COLOR white][B]%s[/B][/COLOR]' % title
                if not broadcast == '': station_title += '  [COLOR FF008000]%s[/COLOR]' % broadcast
                if not listeners == '': station_title += '  [%s/%s]' % (listeners, listeners_peak)
                
                cm = [{'title': __lang__(32009).encode('utf-8'), 'query': {'action': 'radio_track_list', 'station_id': station_id}}]

                self.list.append({'title': title, 'label': station_title, 'image': logo, 'station_id': station_id, 'cm': cm})
            except:
                pass

        return self.list


    def stream_list(self, station_id, image):
        self.list = self.get_stream_list(station_id)

        if self.list == None: return

        ch_list = [i['title'] for i in self.list]
        
        if len(self.list) > 1:
            q = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
            if q == -1: return
        else: q = 0
        
        station_title=self.list[q]['station_title']
        mediatype = self.list[q]['mediatype']
        url = self.list[q]['hls_url'] if mediatype == 'Video' and self.list[q]['hls_url'].strip() != '' else self.list[q]['stream_url']
        resolve(url, image, title=station_title, mediatype=mediatype)


    def track_list(self, station_id):
        try:
            self.list = self.get_stream_list(station_id)
    
            if self.list == None: return
    
            ch_list = [i['title'] for i in self.list]
            
            if len(self.list) > 1:
                ch_id = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
                if ch_id == -1: return
            else: ch_id = 0
            ch_id = str(ch_id + 1)
    
            query = urlparse.urljoin(onlinestream_url, '/tracklist-xml.cgi?id=%s&ch=%s' % (station_id, ch_id))
            r = client.request(query, headers=headers)
            try: r = r.decode('iso-8859-1').encode('utf8')
            except: pass
            
            result = client.parseDOM(r, 'onlinestream.hu')[0]

            title = client.parseDOM(result, 'title')[0]
            try: title = title.encode('iso-8859-1').decode('utf8')
            except: pass
            title = client.replaceHTMLCodes(title).encode('utf-8')

            tracklist = client.parseDOM(result, 'track')[:200]
            tr = []
            for track in tracklist:
                try:
                    time = client.parseDOM(track, 'time')[0].encode('utf-8')

                    song = client.parseDOM(track, 'song')[0].strip()
                    try: song = song.encode('iso-8859-1').decode('utf8')
                    except: pass
                    if (song == '' or song == '-' or song == '?'): raise Exception()
                    song = client.replaceHTMLCodes(song).replace("&apos;", "'").encode('utf-8')
                    
                    label = '[B][COLOR white]%s[/COLOR][/B]  %s' % (time, song)
                    tr.append(label)
                except:
                    pass

            if len(tr) == 0:
                __dialog__.notification(__addonname__, __lang__(32010).encode('utf-8'), __addonicon__, 3000, sound=False); raise Exception()

            __dialog__.select(title, tr)
            return
        except:
            return


    def get_stream_list(self, station_id):
        stations = cache.get(get_stations, 1)
        
        station = [i for i in stations if station_id == client.parseDOM(i, 'station_id')[0].encode('utf-8')]

        station_title = client.parseDOM(station[0], 'title')[0].encode('utf-8')
        channels = client.parseDOM(station, 'channel')

        for item in channels:
            try:
                format = client.parseDOM(item, 'format')[0].strip().encode('utf-8')
                mediatype = 'Music' if not format.lower() in ['flv', 'hls'] else 'Video'
                
                channel_id = client.parseDOM(item, 'channel_id')[0].strip().encode('utf-8')

                channel_title = client.parseDOM(item, 'title')[0].strip().encode('utf-8')

                description = client.parseDOM(item, 'description')[0]
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").strip().encode('utf-8')

                listeners = client.parseDOM(item, 'listeners')[0].strip().encode('utf-8')
                listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else '?'
                
                listeners_peak = client.parseDOM(item, 'listeners_peak')[0].strip().encode('utf-8')
                
                stream_url = client.parseDOM(item, 'stream_url')[0].strip().encode('utf-8')
                
                hls_url = client.parseDOM(item, 'hls_url')[0].strip().encode('utf-8')
                
                bitrate = client.parseDOM(item, 'bitrate')[0].strip().encode('utf-8')
                
                title = '%s: %s [%s/%s] [%s, %s kbps]' % (channel_id, channel_title, listeners, listeners_peak, format, bitrate)
                
                title = re.sub('\[\?\/.*\]\s', '', title)
                if re.search(',\s+\D', title):
                    title = re.sub('\s*kbps', '', title)
                litle = title.replace('[?, ', '[').replace('[, ', '[')
                title = re.sub(',\s*\?', '', title)
                title = re.sub('\[\s*\??\s*\]', '', title)

                self.list.append({'title': title, 'station_title': station_title, 'stream_url': stream_url, 'hls_url': hls_url, 'mediatype': mediatype})
            except:
                pass
        
        return self.list


    def search(self):
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')

            t = __lang__(32004).encode('utf-8')
            k = xbmc.Keyboard('', t) ; k.doModal()
            q = k.getText() if k.isConfirmed() else None

            if (q == None or q == '' or len(q) < 2): raise Exception()

            url = '%s?action=radio_list&search_text=%s' % (sys.argv[0], urllib.quote_plus(q))
            xbmc.executebuiltin('Container.Update(%s)' % url)
        except:
            return


class tv:
    def __init__(self):
        self.list = []


    def get_tv_seq(self):
        try:
            r = client.request(urlparse.urljoin(onlinestream_url, '/tv-seq.xml'), headers=headers)
            tv_seq = client.parseDOM(r, 'station_id')
            if not tv_seq: raise Exception
            return tv_seq
        except:
            cache.clear()
            return


    def tv_list(self, searchtext = None):
        self.list = self.get_tv_list()

        if self.list == None: return
        if not searchtext == None:
            self.list = [i for i in self.list if searchtext.lower() in i['title'].lower()]
            if not self.list:
                __dialog__.notification(__addonname__, __lang__(32012).encode('utf-8'), __addonicon__, 3000, sound=False)
                return

        for i in self.list: i.update({'action': 'tv_stream_list'})

        directory.add(self.list, infotype='Video', isFolder=False)


    def get_tv_list(self):
        stations = cache.get(get_stations, 1)
        tv_seq = cache.get(self.get_tv_seq, 1)

        stations = [i for i in stations if client.parseDOM(i, 'tv')[0] == '1']
        filter = []
        for i in tv_seq:
            for x in stations:
                if i == client.parseDOM(x, 'station_id')[0]:
                    filter.append(x)

        filter += [i for i in stations if not i in filter]
        stations = [i for i in filter if not all('' == s.strip() for s in client.parseDOM(i, 'stream_url')) or not all('' == x.strip() for x in client.parseDOM(i, 'hls_url'))]

        for item in stations:
            try:
                try: item = item.encode('iso-8859-1').decode('utf8')
                except: pass
                title = client.parseDOM(item, 'title')[0]
                title = client.replaceHTMLCodes(title).replace("&apos;", "'").strip().encode('utf-8')

                station_id = client.parseDOM(item, 'station_id')[0].strip().encode('utf-8')
                
                logo = client.parseDOM(item, 'logo')[0].strip().encode('utf-8')

                cm = [{'title': __lang__(32009).encode('utf-8'), 'query': {'action': 'tv_track_list', 'station_id': station_id}}]

                self.list.append({'title': title, 'label': title, 'image': logo, 'station_id': station_id, 'cm': cm})
            except:
                pass

        return self.list


    def stream_list(self, station_id, image):
        self.list = self.get_stream_list(station_id)

        if self.list == None: return

        ch_list = [i['title'] for i in self.list]

        if len(self.list) > 1:
            q = __dialog__.select(__lang__(32008).encode('utf-8'), ch_list)
            if q == -1: return
        else: q = 0

        stream_url = self.list[q]['hls_url'] if self.list[q]['hls_url'].strip() != '' else self.list[q]['stream_url']
        multi_res = True if u'T\xf6bbf\xe9le' in self.list[q]['video_resolution'] else False
        title = self.list[q]['station_title']
        resolve(stream_url, image, title=title, mediatype='Video', multi_res=multi_res)


    def track_list(self, station_id):
        try:
            self.list = self.get_stream_list(station_id)
    
            if self.list == None: return

            query = urlparse.urljoin(onlinestream_url, '/tracklist-xml.cgi?id=%s&ch=' % station_id)
            r = client.request(query, headers=headers)
            try: r = r.decode('iso-8859-1').encode('utf8')
            except: pass

            result = client.parseDOM(r, 'onlinestream.hu')[0]

            title = client.parseDOM(result, 'title')[0]
            try: title = title.encode('iso-8859-1').decode('utf8')
            except: pass
            title = client.replaceHTMLCodes(title).encode('utf-8')

            tracklist = client.parseDOM(result, 'track')[:200]
            tr = []
            for track in tracklist:
                try:
                    time = client.parseDOM(track, 'time')[0].encode('utf-8')

                    song = client.parseDOM(track, 'song')[0].strip()
                    try: song = song.encode('iso-8859-1').decode('utf8')
                    except: pass
                    if (song == '' or song == '-' or song == '?'): raise Exception()
                    song = client.replaceHTMLCodes(song).replace("&apos;", "'").encode('utf-8')
                    
                    label = '[B][COLOR white]%s[/COLOR][/B]  %s' % (time, song)
                    tr.append(label)
                except:
                    pass

            if len(tr) == 0:
                __dialog__.notification(__addonname__, __lang__(32010).encode('utf-8'), __addonicon__, 3000, sound=False); raise Exception()

            __dialog__.select(title, tr)
            return
        except:
            return


    def get_stream_list(self, station_id):
        stations = cache.get(get_stations, 1)

        station = [i for i in stations if station_id == client.parseDOM(i, 'station_id')[0].encode('utf-8')]
        station_title = client.parseDOM(station[0], 'title')[0].encode('utf-8')

        channels = client.parseDOM(station, 'channel')

        for item in channels:
            try:
                channel_id = client.parseDOM(item, 'channel_id')[0].strip().encode('utf-8')

                description = client.parseDOM(item, 'description')[0]
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").strip().encode('utf-8')

                resolution = client.parseDOM(item, 'video_resolution')[0]

                stream_url = client.parseDOM(item, 'stream_url')[0].strip().encode('utf-8')
                hls_url = client.parseDOM(item, 'hls_url')[0].strip().encode('utf-8')
                if stream_url == '' and hls_url == '': continue

                title = 'Stream %s - %s' % (channel_id, description) if not description == '' else 'Stream %s' % channel_id

                self.list.append({'station_title': station_title, 'title': title, 'stream_url': stream_url, 'hls_url': hls_url, 'video_resolution': resolution})
            except:
                pass

        return self.list


    def search(self):
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog)')

            t = __lang__(32004).encode('utf-8')
            k = xbmc.Keyboard('', t) ; k.doModal()
            q = k.getText() if k.isConfirmed() else None

            if (q == None or q == '' or len(q) < 2): raise Exception()

            url = '%s?action=tv_list&search_text=%s' % (sys.argv[0], urllib.quote_plus(q))
            xbmc.executebuiltin('Container.Update(%s)' % url)
        except:
            return
