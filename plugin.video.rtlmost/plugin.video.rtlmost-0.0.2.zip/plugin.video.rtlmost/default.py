# -*- coding: utf-8 -*-
import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin
from requests import session

def folders():

    rtl_home = requests.get("http://rtl.hu/most")

    rtl_csrf = re.compile('<input type="hidden" name="_csrf" value="(.+?)">').findall(rtl_home.content)[0]
    rtl_shows = re.compile('episode.+?<a href="/rtlklub/(.+?)".+?episode-thumb" src="(.+?)\?size=45.+?<a href=".+?".+?episode-title">(.+?)</div>').findall(rtl_home.content)
    for url, iconimage, name in rtl_shows:
        addDir3(name, url, 1, iconimage, iconimage, '', '')

    return

def getvideos(url):
        page = 0
        show_folders(url, page)        
        return

def get_Page(episodes, start):
    return episodes[start:start+12]

def show_folders(url, page):       
    show_home = requests.get('http://rtl.hu/rtlklub/' + url + '/videok').content
    episodes = re.compile('watch.+?/most/(.+?)".+?bottom">(.+?)<span', re.DOTALL).findall(show_home)
    if not episodes:
            show_home = requests.get('http://rtl.hu/rtlklub/' + url).content
            episodes = re.compile('watch.+?/most/(.+?)".+?bottom">(.+?)<span', re.DOTALL).findall(show_home)
    xbmc.log(str(page))
    for i, j in get_Page(episodes, page):
            addDir4(j.strip(), 'http://rtl.hu/most/' + i, 2, '', '', '')

    addDir3('[COLOR green]Következő oldal[/COLOR]', url, 5, '', '', str(page), '')
    return


def getvideo(url):

    video_home = requests.get(url)
    video_hash = re.compile('"video_hash":"(.+?)",').findall(video_home.content)[0]
    video_url_container = requests.get('http://sl.rtl.hu/api/rest.svc/MediaByPlatform/' + video_hash + '/Android')
    video_url = re.compile('<StreamUrl>(.+?)</StreamUrl>').findall(video_url_container.content)[0]

    videoitem = xbmcgui.ListItem(label=url, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(video_url, videoitem)
    return

def addDir3(name,url,mode,iconimage,fanart,description, ep_cache):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&ep_cache="+urllib.quote_plus(ep_cache)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
ep_cache=None
page = -10

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
    page = int(params["description"])
except:
        pass
try:        
    ep_cache = urllib.unquote_plus(params["ep_cache"])
except:
        pass

if mode==None or url==None or len(url)<1:
    folders()
elif mode==1:
    getvideos(url)
elif mode==2:
    getvideo(url)
elif mode==5:
    page+=12
    show_folders(url, page)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
