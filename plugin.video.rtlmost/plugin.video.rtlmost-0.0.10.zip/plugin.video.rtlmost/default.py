# -*- coding: utf-8 -*-
import xbmc,xbmcgui,urllib,re,xbmcplugin,sys,urlparse,json
from resources.lib import client, control, favorites, localplaycount, cache


indicators = localplaycount.getPlaycount()
sysaddon = sys.argv[0]
rtl_base_url = 'http://rtl.hu'


def root():
    addDir3('Minden műsor', '', 3, 'http://cdn.rtl.hu/site/most/logo-x2.png', 'http://cdn.rtl.hu/010/312/image_10312662_16-9', '-3', '')
    addDir3('Kedvencek', '', 6, 'http://cdn.rtl.hu/site/most/logo-x2.png', 'http://cdn.rtl.hu/010/312/image_10312662_16-9', '-3', '')
    addDir4('Lejátszási lista', '', 9, 'http://cdn.rtl.hu/site/most/logo-x2.png', 'http://cdn.rtl.hu/010/312/image_10312662_16-9', '-3')
    

def shows():
    rtl_shows = cache.get(getShows, 5, rtl_base_url + '/most')
    for item in rtl_shows:
        try:
            name = client.parseDOM(item, 'a', ret='title')[0]
            url = client.parseDOM(item, 'a', ret='href')[0]
            addDir3(name.encode('utf-8'), url.encode('utf-8'), 1, iconimage, fanart, '-1', '')
        except: pass
    return

def getShows(url):
    rtl_home = client.source(url)
    rtl_shows = client.parseDOM(rtl_home, 'div', attrs={'class': 'small-3 column no-padding-class-right'})
    return rtl_shows
    
def getvideos(url):
    page = 0
    show_folders(url, page)        
    return


def get_Page(episodes, start):
    return episodes[start:start+12]


def show_folders(url, page):
	src = client.source(rtl_base_url + url)
	if src != None:
		teljesAdasok = re.match(r'.*href="([^"]*)".*Teljes adások.*', src, re.S)
		if teljesAdasok:
			teljesAdasUrl=teljesAdasok.group(1).strip().replace(rtl_base_url, '').replace('/videok', '')
			if teljesAdasUrl != url:
				if client.source(rtl_base_url + teljesAdasUrl) != None:
					addDir3("Teljes adások", teljesAdasUrl.encode('utf-8'), 1, iconimage, fanart, '-1', '') 
	episodes = cache.get(getEpisodes, 10, url)
	try:
		for item in get_Page(episodes, page):
			url2 = client.parseDOM(item, 'a', ret='href')[0]
			imgs = client.parseDOM(item, 'img', ret='alt')
			if len(imgs)>0:
				name = imgs[0]
				img = client.parseDOM(item, 'img', ret='src')[0]
			else:
				titles = client.parseDOM(item, 'div', attrs={'class': 'rcmd-title titleHolderMost'})
				if (len(titles) > 0):
					name = titles[0].strip()
				else:
					name = client.parseDOM(item, 'h4', attrs={'class': 'slide-title short-title'}, ret='title')[0].strip()
				#name = client.parseDOM(item, 'div', attrs={'class': 'rcmd-title titleHolderMost'})[0].strip() + '(' + client.parseDOM(item, 'div', attrs={'class': 'dateMost'})[0] + ')'
				imgs = client.parseDOM(item, 'div', attrs={'class': 'rcmd-image small-12 large-6 column'}, ret='style')
				if (len(imgs) > 0):
					img = imgs[0]
				else:
					img = client.parseDOM(item, 'div', attrs={'class': 'slide seriesSlide'}, ret='style')[0]
				img = img[img.find("url('")+5:img.find("')", img.find("url('")+5)]
			addDir4(name.encode('utf-8'), rtl_base_url + url2.encode('utf-8'), 2, img.encode('utf-8'), fanart, '-1')
	except: pass

	addDir3('[COLOR green]Következő oldal[/COLOR]', url, 5, '', fanart, str(page), '')
	return

def getEpisodes(url):
    show_home = client.source(rtl_base_url + url + '/videok')
    if show_home == None:
    	show_home = client.source(rtl_base_url + url + '/video')
    	if show_home == None:
		show_home = client.source(rtl_base_url + url)
    episodes = client.parseDOM(show_home, 'div', attrs={'class': 'small-12 columns margin-class-bottom programmeListWidget'})
    episodes += client.parseDOM(show_home, 'div', attrs={'class': 'widget-news-konz'})
    episodes += client.parseDOM(show_home, 'div', attrs={'class': 'small-12 columns rcmd-column no-padding '})
    episodes += client.parseDOM(show_home, 'div', attrs={'class': 'small-12 column slide-wrap js-slide-wrap owl-item '})
    episodes += client.parseDOM(show_home, 'div', attrs={'class': 'small-12 medium-5 columns no-padding-class-right'})
    return episodes


def getvideo(url):    
    try:
        video_home = client.source(url)
        videoData = re.search('''videoData\s*=\s*(.+?);?</''', video_home).group(1)
        videoData = json.loads(videoData)
        video_hash = videoData.get('video_hash', '')
        video_id = videoData.get('id')
        headers = {'Referer': url}
        query = urlparse.urljoin(rtl_base_url, '/session/ajax/get-video?tzs=&videoHash=%s&videoId=%d' % (video_hash, video_id))
        video_url_container = client.source(query, headers=headers)

        try:
            sources = json.loads(video_url_container)
            sources = sources['result']['0']['urls']
            sources = [(name, dict_.get('http')) for name, dict_ in sources.items()]
            sources = [i for i in sources if i[0] != 'ABR']
            
            if len(sources) == 1:
                source = sources[0][1]
            elif len(sources) > 1:
                result = xbmcgui.Dialog().select((u'Min\u0151s\u00E9g'), [source[0] if source[0] else 'Uknown' for source in sources])
                if result == -1:
                    return
                else:
                    source = sources[result][1]
            sources = [source]
        except:
            sources = re.findall('''(https?:\/\/[^\/]+(?:\/[^\/]+)*?.mp4)''', video_url_container)
        
        if len(sources) == 0: raise Exception()
        pl=xbmc.PlayList(1)
        pl.clear()
        for item in sources:
            videoitem = xbmcgui.ListItem(label=title + '_' + str(sources.index(item)), thumbnailImage=iconimage)
            videoitem.setInfo(type='Video', infoLabels={'Title': title})
            pl.add(item, videoitem)
        xbmc.Player().play(pl)
    except:
        return


def pickSource(sources):
    if isinstance(sources, (list, tuple)):
        if len(sources) == 1:
            direct_link = sources[0][1]
        elif len(sources) > 1:
            result = xbmcgui.Dialog().select((u'Min\u0151s\u00E9g'), [source[0] if source[0] else 'Uknown' for source in sources])
            if result == -1:
                return
            else:
                direct_link = sources[result][1]
    
    

def handleFavorite():
    try:
        if not name == None and not url == None:
            favorites.addFavorite(name, url)
        elif name == None and not url == None:
            favorites.deleteFavorite(url)
    except:
        return


def getFavorites():
    try:
        items = favorites.getFavorites()
        for item in items:
            try:
                name = item[1]['name']
                url = item[1]['url']
                addDir3(name, url, 1, iconimage, fanart, '-2', '')
            except:
                pass
    except:
        return

  
def playCount():
    if description == '1':
        localplaycount.addPlaycount(name)
    elif description == '-1':
        localplaycount.deletePlaycount(name)


def queueItem():
    control.queueItem()


def openPlaylist():
    mode = None
    control.openPlaylist()

def clearCache():
    cache.clear()

def addDir3(name,url,mode,iconimage,fanart,description, ep_cache):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&ep_cache="+urllib.quote_plus(ep_cache)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        cm = []
        if description == '-1':
            cm.append((u'Hozz\u00E1ad\u00E1s a kedvencekhez', 'RunPlugin(%s?mode=4&name=%s&url=%s)' % (sysaddon, name, url)))
        elif description == '-2':
            cm.append((u'Elt\u00E1vol\u00EDt\u00E1s a kedvencekb\u0151l', 'RunPlugin(%s?mode=4&url=%s)' % (sysaddon, url)))
        elif description == '-3':
            cm.append((u'Gyors\u00EDt\u00F3t\u00E1r tiszt\u00EDt\u00E1sa', 'RunPlugin(%s?mode=10)' % sysaddon))
        liz.addContextMenuItems(cm, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addDir4(name,url,mode,iconimage,fanart,description):
        meta = {"Title": name, "Plot": description}
        try:
            for i in indicators:
                if i[0] == name:
                    meta.update({'playcount': 1, 'overlay': 7})
        except:
            pass
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels=meta)
        liz.setProperty("Fanart_Image", fanart)
        cm = []
        if description == '-1':
            cm.append((u'Lej\u00E1tsz\u00E1si list\u00E1hoz ad', 'RunPlugin(%s?mode=8)' % sysaddon))
            cm.append((u'Megn\u00E9zettk\u00E9nt megjel\u00F6l', 'RunPlugin(%s?mode=7&name=%s&description=%s)' % (sysaddon, name, '1')))
            cm.append((u'Nem l\u00E1tottk\u00E9nt megjel\u00F6l', 'RunPlugin(%s?mode=7&name=%s&description=%s)' % (sysaddon, name, '-1')))
            cm.append((u'Lej\u00E1tsz\u00E1si lista', 'RunPlugin(%s?mode=9)' % sysaddon))
        elif description == '-3':
            cm.append((u'Gyors\u00EDt\u00F3t\u00E1r tiszt\u00EDt\u00E1sa', 'RunPlugin(%s?mode=10)' % sysaddon))
        liz.addContextMenuItems(cm, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        control.content(int(sys.argv[1]), 'files')
        #control.directory(int(sys.argv[1]), cacheToDisc=True)
        return ok


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
ep_cache=None
page = -10

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
    page = int(params["description"])
except:
        pass
try:        
    ep_cache = urllib.unquote_plus(params["ep_cache"])
except:
        pass
try:
    title = name
except:
    pass

if mode==None:
    root()
elif mode==1:
    getvideos(url)
elif mode==2:
    getvideo(url)
elif mode==3:
    shows()
elif mode==4:
    handleFavorite()
elif mode==5:
    page+=12
    show_folders(url, page)
elif mode==6:
    getFavorites()
elif mode==7:
    playCount()
elif mode==8:
    queueItem()
elif mode==9:
    openPlaylist()
elif mode==10:
    clearCache()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
