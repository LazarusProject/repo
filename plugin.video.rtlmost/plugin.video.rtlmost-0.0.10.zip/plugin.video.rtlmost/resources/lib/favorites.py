from time import sleep
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

import json

from resources.lib import control


def getFavorites():
    try:
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM favorite")
        items = dbcur.fetchall()
        items = [(i[0].encode('utf-8'), eval(i[1].encode('utf-8'))) for i in items]
    except:
        items = []

    return items


def addFavorite(name, url):
    try:
        item = dict()
        id = url

        if name: item['name'] = name
        if url: item['url'] = url
        
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorite (""id TEXT, ""items TEXT, ""UNIQUE(id)"");")
        dbcur.execute("DELETE FROM favorite WHERE id = '%s'" %  id)
        dbcur.execute("INSERT INTO favorite Values (?, ?)", (id, repr(item)))
        dbcon.commit()

        control.refresh()
        control.infoDialog('Kedvencekhez adva', heading=name)
    except:
        return


def deleteFavorite(url):
    try:
        try:
            dbcon = database.connect(control.favoritesFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM favorite WHERE id = '%s'" % url)
            dbcon.commit()
        except:
            pass

        control.refresh()
    except:
        return