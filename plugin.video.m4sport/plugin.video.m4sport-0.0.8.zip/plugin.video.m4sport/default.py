# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin
from resources.lib import client, cache, control


m4_url = 'http://www.m4sport.hu'
load_more = 'http://www.m4sport.hu/wp-content/plugins/telesport.hu.widgets/widgets/newSubCategory/ajax_loadmore.php?'

def root():
    result = client.source(m4_url + '/videok/')  
    try:
        video = client.parseDOM(result, 'div', attrs = {'class': 'videoPlayer'})
        if len(video) == 0: raise Exception()
        title = client.parseDOM(video, 'h2')[0]
        token = client.parseDOM(video, 'script', ret='data-token')[0]
        img = client.parseDOM(video, 'script', ret='data-bgimage')[0]
        addDir4(title.encode('utf-8'), token, 3, img, control.addonFanart(), '')
    except:
        pass
    
    videos = client.parseDOM(result, 'div', attrs = {'class': 'moreVideos'})[0]
    category = client.parseDOM(videos, 'h2')
    category_url = client.parseDOM(videos, 'div', attrs={'class': 'newCategoryContainer'})
    category_url = client.parseDOM(category_url, 'a', ret='href')
    videos = zip(category, category_url)
    for item in videos:
        addDir3(item[0].encode('utf-8'), item[1], 2, control.addonIcon(), control.addonFanart(), 1, '1')
    
    try:
        r = client.source(m4_url)
        r = r.replace('\n','').replace('\r','').replace('\t','')
        result = client.parseDOM(r, 'div', attrs = {'class': 'bigBreaking'})
        if len(result) == 0:
            result = client.parseDOM(r, 'div', attrs = {'class': 'oneOtherCoverTopStory'})
        if len(result) == 0: raise Exception()
        for i in result:
            link = client.parseDOM(i, 'a', ret='href')[0]
            if 'script id="live-player"' in (client.source(link)):
                title = client.parseDOM(i, 'h4')[0]
                img = client.parseDOM(i, 'div', attrs = {'class': 'otherPicCoverTopStory'}, ret='style')[0]
                img = re.search("(https?://[^\)]+)", img).group(1)
                addDir4('[COLOR orange]''ÉLŐ ' + '(' + title.encode('utf-8') + ')''[/COLOR]', link, 4, img, control.addonFanart(), '')
    except:
        pass


def Episodes():
    if page == 1:
        m = cache.get(client.source, 5, url)
        m= m.replace('\n','')
        cat_id = re.compile('category_id.+?([0-9]+)').findall(m)[0]
    else:
        cat_id = category
    post ='cat_id=' + cat_id + '&post_type=video&blog_id=4&page_number=' + str(page)
    episodes = cache.get(getEpisodes, 5, load_more + post)
    for name, img, link in episodes:
        try:
            name = name.decode('unicode-escape').encode('utf-8')
        except: pass
        addDir4(name, link, 3, img, fanart, '')
    addDir3('[COLOR green]Következő oldal[/COLOR]', '', 2, '', fanart, page + 1, cat_id)

    
def getEpisodes(url):
    result = client.source(url)
    result = result.decode('iso-8859-1').encode('utf8')
    result = result.replace('\\/','/').replace('//', '/').replace(':/','://')
    episodes = re.compile('title":"(.+?)",.+?image":"(.+?)".+?link":"(.+?)"').findall(result)
    return episodes


def getLive():
    r = client.source(url)
    r = r.decode('iso-8859-1').encode('utf8')
    try:
        m = client.parseDOM(r, 'div', attrs = {'class': 'live-player-wrapper'})
        if len(m) == 0: m = client.parseDOM(r, 'div', attrs = {'class': 'live_player_wrapper'})
        if len(m) == 0: raise Exception()
        streamid = client.parseDOM(m, 'script', ret='data-streamid')[0]
        userid = client.parseDOM(m, 'script', ret='data-userid')[0] 
        r = client.source('http://player.mediaklikk.hu/player/player-inside-full3.php?userid=' + userid + '&streamid=' + streamid + '&flashmajor=21&flashminor=0')
        r = r.replace('\'','')
        direct_url = re.compile('file.+?"?\'?\s?(http.+?m3u8)').findall(r)[-1]
        result = client.request(direct_url)
        url_list = re.compile('([0-9]+)\r\n(.+?m3u8)').findall(result)
        url_list = sorted(url_list, key=lambda tup: tup[0], reverse=True)
        q_list = [(x + 'p') for x,y in url_list]
        dialog = xbmcgui.Dialog()
        q = dialog.select('Minőség', q_list)
        if q == -1: return
        direct_url = direct_url.split('index')[0] + url_list[q][1]
        if direct_url:
            play_url(direct_url, iconimage, name)
    except:
        return


def getvideo():
    try:
        xbmc.executebuiltin( "ActivateWindow(busydialog)" )
        if url.startswith('http'):
            r = client.source(url)
            r = r.decode('iso-8859-1').encode('utf8')
            token = client.parseDOM(r, 'div', attrs={'class': 'video'})
            token = client.parseDOM(token, 'script', ret='data-token')[0]
        else: token = url
        m = client.source('http://player.mediaklikk.hu/player/player-external-vod-full.php?token=' + token)
        direct_url = re.compile('file.+?"?\'?\s?(http.+?m3u8)').findall(m)[-1]
        chunk_list = client.source(direct_url)
        chunk_list = chunk_list.replace('\n', '')
        chunk_list = re.compile('BANDWIDTH=([0-9]+)(.+?m3u8)').findall(chunk_list)
        if len(chunk_list) == 0: direct_url = direct_url[0]
        else:
            chunk_list = [(int(i[0]), i[1]) for i in chunk_list]
            chunk_list = sorted(chunk_list, reverse=True)
            q_list = [str(i[0]) for i in chunk_list]
            q_list = [q.replace('3000000', '720p').replace('1600000', '480p').replace('1200000', '360p').replace('800000', '290p').replace('400000', '180p') for q in q_list]
            xbmc.executebuiltin( "Dialog.Close(busydialog)" )
            dialog = xbmcgui.Dialog()
            q = dialog.select('Minőség', q_list)
            if q == -1: return
            direct_url = direct_url.split('playlist')[0] + chunk_list[q][1]
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        if direct_url:
             play_url(direct_url, iconimage, name)
    except:
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        return


def play_url(url, iconimage, name):   
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)
 
    
def addDir3(name,url,mode,iconimage,fanart,page,category):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&page="+str(page)+"&category="+urllib.quote_plus(category)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        cm = []
        if category == '1':
            cm.append((u'Gyors\u00EDt\u00F3t\u00E1r tiszt\u00EDt\u00E1sa', 'RunPlugin(%s?mode=6)' % sys.argv[0]))
        liz.addContextMenuItems(cm, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
category=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
try:        
        category=urllib.unquote_plus(params["category"])
except:
        pass

if mode==None:
    root()
elif mode==2:
    Episodes()
elif mode==3:
    getvideo()
elif mode==4:
    getLive()
elif mode==6:
    cache.clear()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
