# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin
from resources.lib import client, cache, control

REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


m4_url = 'http://www.m4sport.hu'
load_more = 'http://www.m4sport.hu/wp-content/plugins/telesport.hu.widgets/widgets/newSubCategory/ajax_loadmore.php?'


def root():
    result = client.request(m4_url + '/videok/')

    videos = client.parseDOM(result, 'div', attrs = {'class': 'moreVideos'})[0]
    category = client.parseDOM(videos, 'h2')
    category_url = client.parseDOM(videos, 'div', attrs={'class': 'newCategoryContainer'})
    category_url = client.parseDOM(category_url, 'a', ret='href')
    videos = zip(category, category_url)
    for item in videos:
        addDir3(item[0].encode('utf-8'), "http:"+item[1], 2, control.addonIcon(), control.addonFanart(), 1, '1')
    
    try:
        r = client.request(m4_url+'/')

        result = client.parseDOM(r, 'div', attrs = {'class': 'listimagetagItemWrapper'})[0]
        result = client.parseDOM(result, 'div', attrs = {'class': 'cikk nagy  post'})
        if len(result) == 0: raise Exception()

        for i in result:
            try:
                link = "http:"+client.parseDOM(i, 'a', ret='href')[0].encode('utf-8')
                m = client.request(link)
                if not 'live-player-container' in m: raise Exception()
                title = client.parseDOM(i, 'h1', attrs = {'class': 'article-title'})[0]
                try: img = re.search('image-wrapper.+?[\'"](http[^\'"]+)', i).group(1)
                except: img = ''
                addDir4('[COLOR orange]''[B]ÉLŐ[/B]' + ' | ' + title.encode('utf-8') + '[/COLOR]', link, 4, img, control.addonFanart(), '')
            except:
                pass
    except:
        pass


def Episodes():
    if page == 1:
        m = cache.get(client.request, 5, url)
        m= m.replace('\n','')
        cat_id = re.compile('category_id.+?([0-9]+)').findall(m)[0]
    else:
        cat_id = category
    post ='cat_id=' + cat_id + '&post_type=video&blog_id=4&page_number=' + str(page)
    episodes = cache.get(getEpisodes, 5, load_more + post)
    for name, img, link in episodes:
        try:
            name = name.decode('unicode-escape').encode('utf-8')
        except: pass
        addDir4(name, link, 3, img, fanart, '')
    addDir3('[COLOR green]Következő oldal[/COLOR]', '', 2, '', fanart, page + 1, cat_id)

    
def getEpisodes(url):
    result = client.request(url)
    try: result = result.decode('iso-8859-1').encode('utf8')
    except: pass
    result = result.replace('\\/','/').replace('//', '/').replace(':/','://')
    episodes = re.compile('title":"(.+?)",.+?image":"(.+?)".+?link":"(.+?)"').findall(result)
    return episodes


def getLive():
    r = client.request(url)
    #try: r = r.decode('iso-8859-1').encode('utf8')
    #except: pass
    try:
        streamid = re.search('"streamId"\s*:\s*"([^"]+)', r).group(1)
        r = client.request('http://player.mediaklikk.hu/player/player-inside-full3.php?userid=mtva&streamid=%s&hls=2' % streamid)
        r = r.replace('\\', '').replace('\n', '')
        direct_url = re.search('"file"\s*:\s*"([^"]+)', r).group(1)
        result = client.request(direct_url)
        url_list = re.compile('([0-9]+)\r\n(.+?m3u8)').findall(result)
        url_list = sorted(url_list, key=lambda tup: tup[0], reverse=True)
        q_list = [(x + 'p') for x,y in url_list]
        dialog = xbmcgui.Dialog()
        q = dialog.select('Minőség', q_list)
        if q == -1: return
        direct_url = direct_url.split('index')[0] + url_list[q][1]
        if direct_url:
            play_url(direct_url, iconimage, name)
    except:
        return


def getvideo():
    try:
        xbmc.executebuiltin( "ActivateWindow(busydialog)" )
        if url.startswith('http'):
            r = client.request(url)
            token = re.search('[\'"]token[\'"]\s*:\s*[\'"]([^\'"]+)', r).group(1)
        else: token = url
        m = client.request('http://player.mediaklikk.hu/player/player-external-vod-full.php?token=' + token)
        direct_url = re.search('"file"\s*:\s*"([^"]+)', m).group(1)
        direct_url = direct_url.replace('\\', '')
        chunk_list = client.request(direct_url)
        chunk_list = chunk_list.replace('\n', '')
        chunk_list = re.compile('BANDWIDTH=([0-9]+)(.+?m3u8)').findall(chunk_list)

        chunk_list = [(int(i[0]), i[1]) for i in chunk_list]
        chunk_list = sorted(chunk_list, reverse=True)
        q_list = [str(i[0]) for i in chunk_list]
        q_list = [q.replace('3000000', '720p').replace('1600000', '480p').replace('1200000', '360p').replace('800000', '290p').replace('400000', '180p') for q in q_list]
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        dialog = xbmcgui.Dialog()
        q = dialog.select('Minőség', q_list)
        if q == -1: return
        direct_url = direct_url.split('playlist')[0] + chunk_list[q][1]
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        if direct_url:
            #control.resolve(direct_url)
            play_url(direct_url, iconimage, name)
    except:
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        return


def play_url(url, iconimage, name):   
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)
 
    
def addDir3(name,url,mode,iconimage,fanart,page,category):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&page="+str(page)+"&category="+urllib.quote_plus(category)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        cm = []
        if category == '1':
            cm.append((u'Gyors\u00EDt\u00F3t\u00E1r tiszt\u00EDt\u00E1sa', 'RunPlugin(%s?mode=6)' % sys.argv[0]))
        liz.addContextMenuItems(cm, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
category=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
try:        
        category=urllib.unquote_plus(params["category"])
except:
        pass

if mode==None:
    root()
elif mode==2:
    Episodes()
elif mode==3:
    getvideo()
elif mode==4:
    getLive()
elif mode==6:
    cache.clear()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
