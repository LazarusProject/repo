# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin
from resources.lib import client

thisAddon = xbmcaddon.Addon(id='plugin.video.m4sport')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')

m4_url = 'http://www.m4sport.hu'
load_more = 'http://www.m4sport.hu/wp-content/plugins/telesport.hu.widgets/widgets/newSubCategory/ajax_loadmore.php?'

def folders():
    m = client.source(m4_url + '/videok/')
    m= m.replace('\n','')
    result = re.compile('moreVideoTitle.+?h2>(.+?)<.+?newCategoryContainer.+?href="(.+?)"').findall(m)
    for name, url in result:
        addDir3(name, url, 2, thisAddonDir + '\\icon.png', thisAddonDir + '\\fanart.jpg', 1, '')
    r = client.source(m4_url)
    try:
        r = r.replace('\n','').replace('\r','').replace('\t','')
        result = client.parseDOM(r, 'div', attrs = {'class': 'bigBreaking'})
        for i in result:
            if u'Itt nézheti' in i or u'Ide kattintva nézheti' in i:
                a = re.compile('href="(.+?)".+?url\((.+?)\).+?h4>(.+?)<').findall(i)[0]
                addDir3('ÉLŐ ' + '(' + a[2].encode('utf-8') + ')', a[0], 4, a[1], thisAddonDir + '\\fanart.jpg', '', '')
    except:
        pass

def getEpisodes():
    if page == 1:
        m = client.source(url)
        m= m.replace('\n','')
        cat_id = re.compile('category_id.+?([0-9]+)').findall(m)[0]
    else:
        cat_id = category
    post ='cat_id=' + cat_id + '&post_type=video&blog_id=4&page_number=' + str(page)    
    result = client.source(load_more + post)
    result = result.replace('\\/','/').replace('//', '/').replace(':/','://')
    episodes = re.compile('title":"(.+?)",.+?image":"(.+?)".+?link":"(.+?)"').findall(result)
    for name, img, link in episodes:
        try:
            name = name.decode('unicode-escape').encode('utf-8')
        except: pass
        addDir4(name, link, 3, img, fanart, '')
    addDir3('[COLOR green]Következő oldal[/COLOR]', '', 2, '', fanart, page + 1, cat_id)

def getLive():
    q_list = [('720p', 'VID_1280x720_HUN'), ('480p', 'VID_854x480_HUN'), ('360p', 'VID_640x360_HUN'), ('270p', 'VID_480x270_HUN'), ('180p', 'VID_320x180_HUN')]
    #url_list=['VID_1280x720_HUN','VID_854x480_HUN','VID_640x360_HUN','VID_480x270_HUN','VID_320x180_HUN']
    r = client.source(url)
    try:
        m = client.parseDOM(r, 'div', attrs = {'class': 'live-player-wrapper'})[0]
        streamid = client.parseDOM(m, 'script', ret='data-streamid')[0]
        userid = client.parseDOM(m, 'script', ret='data-userid')[0] 
        r = client.source('http://player.mediaklikk.hu/player/player-inside-full3.php?userid=' + userid + '&streamid=' + streamid + '&flashmajor=21&flashminor=0')
        direct_url = re.compile('sources:.+?(http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+)index').findall(r)[0]
        for i in q_list:
            addDir4(i[0], direct_url + i[1] + '.m3u8', 5, iconimage, fanart, name)
        #dialog = xbmcgui.Dialog()
        #q = dialog.select('Minőség', q_list)
        #if q == -1: return
        #direct_url = direct_url[0] + url_list[q] + '.m3u8'
        #if direct_url:
        #    play_url(direct_url, iconimage, name)
    except:
        pass
    if m == []:
        try:
            m = client.parseDOM(r, 'div', attrs = {'class': 'articleContent'})[0]
            m = client.parseDOM(m, 'a', ret='href')
            for i in m:
                if 'itt-nezheti' in i or 'ide-kattintva-nezheti' in i:
                    title = i.rsplit('/')[-2].replace('-',' ')               
                    addDir4(title, i, 4, '', '', '')
        except:
            pass

def getvideo():
    try:
        xbmc.executebuiltin( "ActivateWindow(busydialog)" )      
        r = client.source(url)
        token = re.compile('token =.+?\'(.+?)\'').findall(r)[0]
        token = token.replace('\\','')
        m = client.source('http://player.mediaklikk.hu/player/player-external-vod-full.php?token=' + token)
        direct_url = re.compile("file: '(.+?)'").findall(m)
        chunk_list = client.source(direct_url[0])
        chunk_list = chunk_list.replace('\n', '')
        chunk_list = re.compile('BANDWIDTH=([0-9]+)(.+?m3u8)').findall(chunk_list)
        if len(chunk_list) == 0: direct_url = direct_url[0]
        else:
            chunk_list = [(int(i[0]), i[1]) for i in chunk_list]
            chunk_list = sorted(chunk_list, reverse=True)
            q_list = [str(i[0]) for i in chunk_list]
            q_list = [q.replace('3000000', '720p').replace('1600000', '480p').replace('1200000', '360p').replace('800000', '290p').replace('400000', '180p') for q in q_list]
            xbmc.executebuiltin( "Dialog.Close(busydialog)" )
            dialog = xbmcgui.Dialog()
            q = dialog.select('Minőség', q_list)
            if q == -1: return
            direct_url = direct_url[0].split('playlist')[0] + chunk_list[q][1]
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        if direct_url:
             play_url(direct_url, iconimage, name)
    except:
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        return

def play_url(url, iconimage, name):   
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)

def playLive():
    play_url(url, iconimage, description)
    return
    
def addDir3(name,url,mode,iconimage,fanart,page,category):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&page="+str(page)+"&category="+urllib.quote_plus(category)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
category=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=int(params["page"])
except:
        pass
try:        
        category=urllib.unquote_plus(params["category"])
except:
        pass

if mode==None:
    folders()
elif mode==2:
    getEpisodes()
elif mode==3:
    getvideo()
elif mode==4:
    getLive()
elif mode==5:
    playLive()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
