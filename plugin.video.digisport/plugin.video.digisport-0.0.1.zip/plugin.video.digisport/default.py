# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin

from resources.lib import client, control

digisport = 'http://www.digisport.hu'


def folders():
    result = client.request(digisport + '/video/p/' + page)
    episodes = client.parseDOM(result, 'div', attrs={'class': 'newsbox'})
    for item in episodes:
        try:
            link = client.parseDOM(item, 'a', ret='href')[0]
            plot = client.parseDOM(item, 'div', attrs={'class': 'nlead'})[0]
            plot = plot.replace('\n','').replace('\t','')
            plot = re.compile('(.+?)<br').findall(plot)[0]
            img = digisport + client.parseDOM(item, 'img', ret='src')[0]
            title = client.parseDOM(item, 'a', attrs={'class': 'ntitle'})[0]
            addFile(title.encode('utf-8'), link, 2, img, control.addonFanart(), plot.encode('utf-8'))
        except:
            pass
    try:
        next = client.parseDOM(result, 'div', attrs={'class': 'pagerright'})[0]
        if 'more' in next:
            next_page = str(int(page) + 1)
            addDir('[COLOR green]''Következő oldal''[/COLOR]', '', 1, control.addonIcon(), control.addonFanart(), '', next_page)
    except:
        pass


def getvideo():

    result = client.request(url)
    direct_url = client.parseDOM(result, 'div', attrs={'id': 'videourl'})[0]

    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(direct_url, videoitem)
    return

##########

def addDir(name, url, mode, iconimage, fanart, description, page):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+urllib.quote_plus(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = '1'

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    page = urllib.unquote_plus(params["page"])
except:
    pass

if mode==None or mode==1:
    folders()
elif mode==2:
    getvideo()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
