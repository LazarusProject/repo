# -*- coding: utf-8 -*-
#
#      Copyright (C) 2017 Mr Dini <mrdini@movieshark.hu>
#      https://movieshark.hu
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#Buggalo init
import buggalo
buggalo.SUBMIT_URL = 'https://bugs.movieshark.hu/buggalo/submit.php'


try:
    import xbmcplugin,xbmcaddon,xbmc,urllib2,urlparse,xbmcgui,re,json,os,time
except Exception:
    buggalo.onExceptionRaised()
    sys.exit(1)

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__userdatadir__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__icon__ = __addon__.getAddonInfo('icon')
__fanart__ = __addon__.getAddonInfo('fanart')
addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'movies')

#HTTPS / HTTP mode check
if __addon__.getSetting("conmode") == "false":
    conmode = 'http://'
else:
    conmode = 'https://'

thumbsize = __addon__.getSetting("thumbsize")
base_url = conmode+'dev.mytvback.com'

def getpage(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0')
    try:
        response = urllib2.urlopen(req)
    except urllib2.HTTPError as e:
        if e.code == 401:
            xbmcgui.Dialog().ok(__addonname__,'Rossz felhasználónév/jelszó![CR]Kérlek ellenőrizd, hogy az adataid helyesen adtad-e meg!','','[COLOR grey]Tipp:[/COLOR] A 06 prefix nem szükséges a felhasználónév esetében!')
        elif e.code != 200:
            select = xbmcgui.Dialog().yesno(__addonname__+' - Hiba','Ajjaj! A szerver [COLOR darkred][B]'+str(e.code)+'[/B][/COLOR]-es hibakóddal válaszolt...[CR]Elképzelhető, hogy éppen karbantartás alatt van. Amennyiben a hiba tartósan fenállna, jelentsd a hibát a \'Jelentem\' gombra kattintva!', None, None, 'Várok vele!', 'Jelentem!')
            if select == 1:
                buggalo.onExceptionRaised()
        sys.exit(1)

    except urllib2.URLError as e:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('[MyTV]','Hiba a csatornainfók letöltése során! Ellenőrizd az internetkapcsolatot!', 5000, __icon__))
        sys.stderr.write('[MyTV] Link get failed')
        sys.stderr.write(str(e))
        buggalo.onExceptionRaised()
        sys.exit(1)
    return(json.load(response))


def gettoken():
    global token
    """
    # Removed temporarily because of Windows incompatibility - TODO!
    lasttokenf = os.path.join(__userdatadir__, 'lasttoken.txt')
    if os.path.exists(lasttokenf):
        f = file(lasttokenf, "r+")
        content = str(f.read()).split("=sp=")
        if content[0] > time.time():
            token = content[1]
            return
    else:
        f = file(lasttokenf, "w")
    """
    username = __addon__.getSetting("username")
    password = __addon__.getSetting("password")
    if username and password:
        response = getpage('%s/api/19/default/hu-HU/accesstoken?login=%s&password=%s&rememberCredentials=true' % (base_url, username, password))
    else:
        xbmcgui.Dialog().ok(__addonname__, 'Kérlek add meg a bejelentkezési adataid!')
        __addon__.openSettings()
        sys.exit(1)
    token = str(response["Content"]["Token"])
    expirydate = str(response["Content"]["TokenExpiration"])
    """
    f.seek(0)
    f.write(expirydate+'=sp='+token)
    f.truncate()
    f.close()
    """

def getinfos():
    response = getpage('%s/backend/api/v2/default/hu-HU/proposers/PRO_59/items?imagesize=%s&offset=1&token=%s' % (base_url, thumbsize, token))
    items = response["Content"]["List"]
    global descriptions; global titles; global images; global spids; global durations
    descriptions = []; titles = []; images = []; spids = []; durations = []
    for item in items:
        spids.append(re.sub("CHA_",'',item["Action"]["SortPid"].encode("utf-8")))
        descriptions.append(item["Description"].encode("utf-8"))
        titles.append(item["Title"].encode("utf-8"))
        images.append(item["Images"][0]["Url"])
        durations.append(int(item["Duration"]))

def getstreams():
    global pid
    pid = ''
    response = getpage('%s/api/19/default/hu-HU/usercontents?pids=LCH%s&limit=100&token=%s' % (base_url, spid, token))
    plrights = response["Content"][0]["PlaybackRights"]
    qualities = []; pids = []
    for plright in plrights:
        if plright["StreamingType"] != 'SS':
            qualities.append(plright["Quality"]+' '+plright["StreamingType"])
            pids.append(plright["Pid"])
    select = xbmcgui.Dialog().select('Válassz felbontást!', qualities)
    pid = pids[select]


def getlinks():
    global streamlinks
    streamlink = ''
#    for pid in pids:
    response = getpage('%s/api/19/default/hu-HU/mediaurl/%s?limit=100&token=%s' % (base_url, pid, token))
    streamlink = response["Content"]["Url"].encode("utf-8")
    videoitem = xbmcgui.ListItem(label=title, thumbnailImage=videoicon)
    videoitem.setInfo(type='Video', infoLabels={'Title': title, "Plot": description, "duration": duration })
    xbmc.Player().play(streamlink, videoitem)

def buildfolder():
    for x in range(0,len(titles)):
        u=sys.argv[0]+"?mode="+str('1')+"&spid="+str(spids[x])+"&title="+urllib2.quote(titles[x])+"&videoicon="+urllib2.quote(images[x])+"&description="+urllib2.quote(descriptions[x])
        li = xbmcgui.ListItem(titles[x], iconImage=images[x], thumbnailImage=images[x])
        li.addContextMenuItems([ ('Frissítés', 'XBMC.Container.Refresh') ])
        li.setInfo( type="Video", infoLabels={ "Title": titles[x], "Plot": descriptions[x], "duration": durations[x] } )
        li.setProperty('fanart_image', __fanart__)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li)


params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = None
spid = None
title = None
description = None
videoicon = None
duration = None
token = None

try:
    mode = int(params["mode"])
    spid = int(params["spid"])
    title = params["title"]
    videoicon = params["videoicon"]
    description = params["description"]
    duration = params["duration"]
except:
    pass

try:
    if mode==None:
        gettoken()
        getinfos()
        buildfolder()
    elif mode==1:
        gettoken()
        getstreams()
        getlinks()
except Exception:
    buggalo.onExceptionRaised()

xbmcplugin.endOfDirectory(addon_handle)

#End!