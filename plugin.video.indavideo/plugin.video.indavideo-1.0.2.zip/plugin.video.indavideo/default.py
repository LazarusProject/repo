import os
import sys
import urllib
import urllib2
import re
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import time

thisAddon = xbmcaddon.Addon(id='plugin.video.indavideo')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
sys.path.append(os.path.join(thisAddonDir, 'resources', 'search'))

if sys.platform == 'win32':
    download_script = thisAddonDir + '\default.py'
    search_file = thisAddonDir + '\\resources\\search\\search.dat'
    search_tmp = thisAddonDir + '\\resources\\search\\search.tmp'
else:
    download_script = thisAddonDir + '/default.py'
    search_file = thisAddonDir + '/resources/search/search.dat'
    search_tmp = thisAddonDir + '/resources/search/search.tmp'

sbarat_abc = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

lang_flags = ['[COLOR green] SZINKRON[/COLOR]','[COLOR red] FELIRAT[/COLOR]','[COLOR yellow] NINCS FELIRAT[/COLOR]']

host_support = ['vidto.me','movshare.net','indavideo.hu','youtube.com','streamin.to']

def open_search_panel():
               
    search_text = ''
    keyb = xbmc.Keyboard('',u'Keres\u00E9s')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()

    return search_text

def find_read_error(top_url):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req)
        url_content = url_handler.read()
        url_handler.close()
    except:
        url_content = 'HIBA'
        addon = xbmcaddon.Addon()
        addonname = addon.getAddonInfo('name')
        line1 = u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!'
        xbmcgui.Dialog().ok(addonname, line1)
        return url_content
    return url_content

def find_read_error_params(top_url, params):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req, params)
        url_content = url_handler.read()
        url_handler.close()
    except:
        url_content = 'HIBA'
        addon = xbmcaddon.Addon()
        addonname = addon.getAddonInfo('name')
        line1 = u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!'
        xbmcgui.Dialog().ok(addonname, line1)
        return url_content
    return url_content

def just_beta(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = u'Ebben a verzi\xF3ban, ez a vide\xF3 kiszolg\xE1l\xF3 nem t\xE1mogatott!'
    xbmcgui.Dialog().ok(addonname, line1, u'Vide\xF3 kiszolg\xE1l\xF3: ' + file_host)  
    return

def just_removed(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = u'A keresett vide\xF3t elt\xE1vol\xEDtott\xE1k!'
    xbmcgui.Dialog().ok(addonname, line1, u'Vide\xF3 c\xEDme: ' + file_host)   
    return

def empty_search():
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = u'A keresett kifejez\xE9sre nincs tal\xE1lat!'
    xbmcgui.Dialog().ok(addonname, line1)   
    return

def viewmode(mview):

    return

def time_to_duration(strtime):

    strtime_a = strtime.split(':')
    duration = (int(strtime_a[0]) * 60) + int(strtime_a[1])

    return int(duration)

def build_main_directory():
    url = build_url({'mode': 'base_search', 'foldername': 'Kereses', 'pagenum': '0'})
    li = xbmcgui.ListItem(u'Keres\xE9s', iconImage=thisAddon.getAddonInfo('icon'))
    li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'inda_base', 'foldername': 'Ajanlott', 'pagenum': '0'})
    li = xbmcgui.ListItem(u'Aj\xE1nlott vide\u00F3k', iconImage=thisAddon.getAddonInfo('icon'))
    li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    viewmode(1)
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_search_directory():
    url = build_url({'mode': 'new_search', 'foldername': 'UjKereses', 'pagenum': '1', 'search_text': ' '})
    li = xbmcgui.ListItem(u'[B]\u00DAj Keres\xE9s[/B]', iconImage=thisAddon.getAddonInfo('icon'))
    li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'old_search', 'foldername': 'RegiKereses', 'pagenum': '1'})
    li = xbmcgui.ListItem(u'Keres\xE9si el\u0151zm\xE9nyek', iconImage=thisAddon.getAddonInfo('icon'))
    li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    viewmode(1)
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_indavideo_directory():
    top_url = 'http://indavideo.hu'

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    video_info = re.compile('class="item TYPE_5[^=]+="([^"]+)"[^:]+://([^"]+)"[^/]+//([^"]+)".*?"duration">(.*?)</div>.*?"description">(.*?)</div>').findall(url_content)    

    if video_info:
        for poz in range(len(video_info)):
            url = build_url({'mode': 'indavideo.hu', 'foldername': 'http://' + video_info[poz][1], 'title': video_info[poz][0], 'image': 'http://' + video_info[poz][2], 'isdownload' : ' '})
            li = xbmcgui.ListItem(video_info[poz][0].decode('utf-8'), iconImage='http://' + video_info[poz][2])
            li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
            li.setInfo(type='Video', infoLabels={'duration': time_to_duration(video_info[poz][3]), 'plot': video_info[poz][4].decode('utf-8')})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

    viewmode(1)
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_search_result(pagenum, search_text):
    if search_text == ' ':
        search_text = open_search_panel()
        work_text = ''.join(search_text.split())
        if work_text != '':
            build_search_file(urllib.quote(search_text, ''), 'ADD')
        else:
            empty_search()
            return

    top_url = 'http://indavideo.hu/search?p_uni=' + pagenum + '&action=search&search=' + urllib.quote(search_text, '') + '&view=detailed'

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    video_info = re.compile('class="item TYPE_8[^=]+="([^"]+)"[^:]+://([^"]+)"[^/]+//([^"]+)".*?"duration">(.*?)</div>.*?"description">(.*?)</div>').findall(url_content)    
    next_page = re.compile('="text">(utols)').findall(url_content)

    if video_info:
        for poz in range(len(video_info)):
            url = build_url({'mode': 'indavideo.hu', 'foldername': 'http://' + video_info[poz][1], 'title': video_info[poz][0], 'image': 'http://' + video_info[poz][2], 'isdownload' : ' '})
            li = xbmcgui.ListItem(video_info[poz][0].decode('utf-8'), iconImage='http://' + video_info[poz][2])
            li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
            li.setInfo(type='Video', infoLabels={'duration': time_to_duration(video_info[poz][3]), 'plot': video_info[poz][4].decode('utf-8')})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

        if pagenum != '1':
            url = build_url({'mode': 'back_one_folder'})
            li = xbmcgui.ListItem(u'[COLOR blue]<< El\u0151z\u0151 oldal <<[/COLOR]', iconImage=thisAddon.getAddonInfo('icon'))
            li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

        pagenum = int(pagenum)
        pagenum += 1
        pagenum = str(pagenum)

        if next_page:
            url = build_url({'mode': 'new_search', 'foldername': 'UjKereses', 'pagenum': pagenum, 'search_text': urllib.quote(search_text, '')})
            li = xbmcgui.ListItem(u'[COLOR green]>> K\xF6vetkez\u0151 oldal >>[/COLOR]', iconImage=thisAddon.getAddonInfo('icon'))
            li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)

    viewmode(1)
    xbmcplugin.endOfDirectory(addon_handle)

    return

def find_indavideo_videourl(foldername, foldertitle, folderimage, isdownload):
    top_url = foldername
            
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    embed_url_hash = re.compile('indavideo\.hu/player/video/([0-9a-f]+)').findall(url_content)
   
    if embed_url_hash:
        top_url = 'http://amfphp.indavideo.hu/SYm0json.php/player.playerHandler.getVideoData/' + embed_url_hash[0]

        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return

        direct_url = re.compile('video_file":"([^"]+)"').findall(url_content)

        if direct_url:
            if isdownload == 'DOWNLOAD':
                foldertitle = foldertitle[:41] + '.mp4'
                download_video(foldertitle, direct_url[0].replace('\\', ''))
            else:
                videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=folderimage)
                videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
                xbmc.Player().play(direct_url[0].replace('\\', ''), videoitem)
        else:
            just_removed(foldertitle)
    else:
        just_removed(foldertitle)
           
    return

def build_search_file(search_text, function):
    if function == 'ADD':
        file_data = search_text + '\n'
        the_file = open(search_file,'a')
        the_file.write(file_data)
        the_file.close()
        the_tmp = open(search_tmp,'a')
        the_tmp.write(file_data)
        the_tmp.close()
    
    elif function == 'REMOVE':
        file_data = search_text
        the_tmp = open(search_tmp,'r')
        the_file = open(search_file,'w')
        for line in the_tmp:
            if line != file_data:
                the_file.write(line)
        the_file.close()
        the_tmp.close()

        the_file = open(search_file,'r')
        the_tmp = open(search_tmp,'w')
        for line in the_file:
            the_tmp.write(line)
        the_tmp.close()
        the_file.close()
        xbmc.executebuiltin("Container.Refresh")
        
    return

def build_old_search_directory():
    try:
        the_file = open(search_file,'r')
        for line in the_file:
            url = build_url({'mode': 'new_search', 'foldername': 'UjKereses', 'pagenum': '1', 'search_text': urllib.unquote(line)})
            li = xbmcgui.ListItem(urllib.unquote(line), iconImage=thisAddon.getAddonInfo('icon'))
            li.setProperty('fanart_image', thisAddon.getAddonInfo('fanart'))
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)        
                
        the_file.close()
        viewmode(1)
        xbmcplugin.endOfDirectory(addon_handle)          
    except:
        viewmode(1)
        xbmcplugin.endOfDirectory(addon_handle)

    return

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

if mode is None:

    build_main_directory()

elif mode[0] == 'base_search':

    build_search_directory()

elif mode[0] == 'inda_base':

    build_indavideo_directory()

elif mode[0] == 'new_search':

    build_search_result(args['pagenum'][0], args['search_text'][0])

elif mode[0] == 'indavideo.hu':
    
    find_indavideo_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0])

elif mode[0] == 'old_search':
    
    build_old_search_directory()

elif mode[0] == 'back_one_folder':

    xbmc.executebuiltin('Action(ParentDir)')

