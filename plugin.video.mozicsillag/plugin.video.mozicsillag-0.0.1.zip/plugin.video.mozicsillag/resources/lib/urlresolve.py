# -*- coding: utf-8 -*-
import os
import sys
import urllib
import urllib2
import re
import urlparse
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
import time
import shutil
import json
import jsunpack
import requests
import simplejson

from openload import AADecoder

REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


def handle_wait(time_to_wait,title,text):
    mensagemprogresso = xbmcgui.DialogProgress()
    ret = mensagemprogresso.create(' '+title)
    secs=0
    percent=0
    increment = int(100 / time_to_wait)
    cancelled = False
    while secs < time_to_wait:
        secs += 1
        percent = increment*secs
        secs_left = str((time_to_wait - secs))
        remaining_display = "Még " + str(secs_left) + " másodperc van hátra..."
        mensagemprogresso.update(percent,text,remaining_display)
        xbmc.sleep(1000)
        if (mensagemprogresso.iscanceled()):
            cancelled = True
            break
    if cancelled == True:
        return False
    else:
        mensagemprogresso.close()
        return False

def find_read_error(top_url):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req)
        url_content = url_handler.read()
        url_handler.close()
    except:
        return('HIBA')
    return(url_content)

def find_read_error_params(top_url, params):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req, params)
        url_content = url_handler.read()
        url_handler.close()
    except:
        return('HIBA')
    return(url_content)

def exashare(top_url):

    r = requests.get(top_url)
    if r.status_code == 404:
        return('HIBA')
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers
    htopurl = urllib.quote_plus(top_url)
    
    embed_url1 = re.compile('src="([^"]+)').findall(rcontent)
    embed_url1 = embed_url1[0].replace('\n','')
    hembeded_url1 = urllib.quote_plus(embed_url1)
    header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                        'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : top_url}
    cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    r = requests.get(embed_url1, headers = header, cookies = cook)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers

    #embed_url2 = re.compile('src="([^"]+)').findall(rcontent)
    #embed_url2 = embed_url2[0].replace('\n','')
    #hembeded_url2 = urllib.quote_plus(embed_url2)
    #header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
    #                    'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : embed_url1}
    #cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    #r = requests.get(embed_url2, headers = header, cookies = cook)
    #rtext = r.text
    #lrtext = len(rtext)
    #rcontent = r.content
    #lrcontent = len(rcontent)
    #rhead = r.headers

    direct_url = re.compile('file:"(.+?mp4)"').findall(rcontent)

    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def vidtome(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')

    hidden_data = re.compile('type="(?:hidden|submit)?" name="(.+?)"\s* value="?(.+?)">').findall(url_content)

    if hidden_data:
        top_url = 'http://vidto.me/' + hidden_data[2][1] + '.html'
    else:
        return('HIBA')
    handle_wait(6, "Mozicsillag.cc", "Link feloldása")

    hidden_params = {
        'op': hidden_data[0][1],
        'usr_login': '',
        'id': hidden_data[2][1],
        'fname': hidden_data[3][1],
        'referer': '',
        'hash': hidden_data[5][1],
    }
    encoded_params = urllib.urlencode(hidden_params)

    url_content = find_read_error_params(top_url, encoded_params)
    if url_content == 'HIBA':
        return('HIBA')

    direct_url = re.compile('<a id="lnk_download" href="(.+?)"').findall(url_content)
    direct_url = direct_url[0]
    
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def cloudzilla(top_url):
    
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')

    direct_url = re.compile('vurl = "(.+?)"').findall(url_content)

    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def youwatch(top_url):
    
    r = requests.get(top_url)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers
    htopurl = urllib.quote_plus(top_url)
    
    embed_url1 = re.compile('iframe src="([^"]+)').findall(rcontent)
    embed_url1 = embed_url1[0].replace('\n','')
    hembeded_url1 = urllib.quote_plus(embed_url1)
    header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                        'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : top_url}
    cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    r = requests.get(embed_url1, headers = header, cookies = cook)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers

    #embed_url2 = re.compile('iframe src="([^"]+)').findall(rcontent)
    #embed_url2 = embed_url2[0].replace('\n','')
    #hembeded_url2 = urllib.quote_plus(embed_url2)
    #header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
    #                    'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : embed_url1}
    #cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    #r = requests.get(embed_url2, headers = header, cookies = cook)
    #rtext = r.text
    #lrtext = len(rtext)
    #rcontent = r.content
    #lrcontent = len(rcontent)
    #rhead = r.headers

    direct_url = re.compile('file:"(.+?mp4)"').findall(rcontent)

    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def flashx(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')

    hidden_data = re.compile('type="(?:hidden|submit)?" name="(.+?)"\s* value="?(.+?)">').findall(url_content)

    if hidden_data:
        top_url = 'http://flashx.tv/dl?' + hidden_data[2][1]    
    handle_wait(4, "Mozicsillag.cc", "Link feloldása")

    hidden_params = {
        'op': hidden_data[0][1],
        'usr_login': '',
        'id': hidden_data[2][1],
        'fname': hidden_data[3][1],
        'referer': '',
        'hash': hidden_data[5][1],
    }
    encoded_params = urllib.urlencode(hidden_params)

    url_content = find_read_error_params(top_url, encoded_params)
    if url_content == 'HIBA':
        return('HIBA')
    direct_url = re.compile('{file:"(.+?mp4)"').findall(url_content)
    if direct_url:
        return(direct_url)[0]
    else:
        packed_data = re.compile('(eval\(function\(p,a,c,k,e,d\).+\)\))').findall(url_content)
        unpacked_data = jsunpack.unpack(packed_data[0])
        direct_url = re.compile('{file:"(.+?mp4)"').findall(unpacked_data)
        if direct_url:
            return(direct_url)[0]
        else:
            return('HIBA')    

def openload(top_url):

    r = requests.get(top_url)
    data = r.content
    
    data = data.replace('\\/', '/') \
        .replace('&amp;', '&') \
        .replace('\xc9', 'E') \
        .replace('&#8211;', '-') \
        .replace('&#038;', '&') \
        .replace('&rsquo;', '\'') \
        .replace('\r', '') \
        .replace('\n', '') \
        .replace('\t', '') \
        .replace('&#039;', "'")

    content = ''

    patron = "<video(?:.|\s)*?<script\s[^>]*?>((?:.|\s)*?)<\/script"
    matches = re.compile(patron, re.IGNORECASE).findall(data)
    if len(matches) > 0:
        content = AADecoder(matches[0]).decode()

    if content:
        patron = r'window\.vr=\'(.*?)\?'
        matches = re.compile(patron, re.IGNORECASE).findall(content.replace('\\', ''))
        if len(matches) > 0:
            direct_url = matches[0]
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def streamin(top_url):

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')
    
    direct_url = re.compile('file:\'([^\']+)\'').findall(url_content)
    if direct_url:
        return(direct_url[0])
    else:
        return('HIBA')

def vodlocker(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')

    direct_url = re.compile('file[: ]*"(.+?)"').findall(url_content)
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')
    
def vidzi(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')
    
    packed_data = re.compile('(eval\(function\(p,a,c,k,e,d\).+\)\))').findall(url_content)
        
    unpacked_data = jsunpack.unpack(packed_data[0])

    direct_url = re.compile('file:"(.+?mp4)"').findall(unpacked_data)
    if direct_url:
        return(direct_url[0])
    else:
        return('HIBA')

def indavideo(top_url):

    top_url = 'http://amfphp.indavideo.hu/SYm0json.php/player.playerHandler.getVideoData/' + top_url

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return('HIBA')

    direct_url = re.compile('video_file":"([^"]+)"').findall(url_content)    
    if direct_url:
        return direct_url[0].replace('\\', '')
    else:
        return('HIBA')
    
def videa(top_url):

    match = re.compile('<link rel="image_src" href="(.+?)"', re.DOTALL).findall(top_url)
    if not match:
        return('HIBA')
    top_url = match[0].split('.')
    top_url = 'http://videa.hu/static/video/'+top_url[3]+'.'+top_url[4]+'.'+top_url[5]
    direct_url = top_url    
    
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')
