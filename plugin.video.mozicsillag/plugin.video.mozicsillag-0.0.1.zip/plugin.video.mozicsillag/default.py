# -*- coding: utf-8 -*-
import requests, xbmc, xbmcgui, urllib, re, xbmcplugin, time, xbmcaddon, os, base64, datetime

thisAddon = xbmcaddon.Addon(id='plugin.video.mozicsillag')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')
SettingsDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources')).decode('utf-8')
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ).decode('utf-8')

from BeautifulSoup import BeautifulStoneSoup
import urlresolve

current_year = datetime.datetime.now().strftime("%Y")

csillag_url = 'http://mozicsillag.cc/'
supported = ["vidto", "exashare", "flashx", "openload.co", "streamin", "indavideo", "vidzi", "vodlocker", "videa"]
lang_flags = ['[COLOR green] SZINKRON[/COLOR]','[COLOR red] FELIRAT[/COLOR]','[COLOR yellow] NINCS FELIRAT[/COLOR]']
addon_handle = int(sys.argv[1])

def just_removed(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = 'A keresett linket eltávolították!'
    xbmcgui.Dialog().ok(addonname, line1, 'Video kiszolgáló: ' + file_host)   
    return

def setviewmode(mode):
    addon_settings = xbmcaddon.Addon(id='plugin.video.mozicsillag')
    mainview = int(addon_settings.getSetting('mainview'))
    streamview = int(addon_settings.getSetting('streamview'))

    if mode == 'main_folder':
        if mainview == 1:
            mainview = 502
        elif mainview == 2:
            mainview = 51
        elif mainview == 3:
            mainview = 500
        elif mainview == 4:
            mainview = 501
        elif mainview == 5:
            mainview = 508
        elif mainview == 6:
            mainview = 504
        elif mainview == 7:
            mainview = 503
        elif mainview == 8:
            mainview = 515    
        else:
            mainview = 0
        return(mainview)
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %mainview)
    elif mode == 'movie_folder':
        if streamview == 1:
            streamview = 502
        elif streamview == 2:
            streamview = 51
        elif streamview == 3:
            streamview = 500
        elif streamview == 4:
            streamview = 501
        elif streamview == 5:
            streamview = 508
        elif streamview == 6:
            streamview = 504
        elif streamview == 7:
            streamview = 503
        elif streamview == 8:
            streamview = 515
        else:
            streamview = 0
        return(streamview)            
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %streamview)
 
    return

def home():
    addDir('Filmek',                     'filmek-online', 1, '', '', 'film', 1, '', '', '','','')
    addDir('Sorozatok',                  'sorozatok-online', 1, '', '', 'sorozat', 1, '', '', '','','')
    addDir('Keresés',                    '', 5, '', '', '', 1, '', '', '','','')
    return

def filmek():
    #addDir('Keresés',                   '', 5, '', '', '', 1, '')
    addDir('Legfrissebb',                url, 2, '', '', description, 1, '/legfrissebb', '', 'not', '','')
    addDir('Legnézettebb',               url, 2, '', '', description, 1, '/legnezettebb', '', 'not', '','')
    addDir('Legjobbra értékelt',         url, 2, '', '', description, 1, '/legjobbra-ertekelt', '', 'not', '','')
    addDir('Kategóriák',                 url, 12, '', '', description, 1, '', '', '', '','')
    return

def listak():     
    i = requests.get(csillag_url + url + category + '?page=' + str(page))
    if description == 'film':
        for a, b, c in getMovies(i.content, description):
            c = BeautifulStoneSoup(c, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
            c = (c.text).encode("UTF-8")
            addDir(c, a, 3, csillag_url + b, csillag_url + b, '', 1, '', '', '', '','')    
    else:
        for a, b, c, d in getMovies(i.content, description): 
            c = BeautifulStoneSoup(c, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
            c = (c.text).encode("UTF-8")
            d = BeautifulStoneSoup(d, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
            d = (d.text).encode("UTF-8")
            addDir(c + ' ' + ': ' + '[COLOR yellow]' + d + '[/COLOR]', a, 9, csillag_url + b, csillag_url + b, '', 1, '', '', '', c,'')          
    
    if not "(0)'>&raquo;<" in i.content:
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 2, '', '', description, page + 1, category, '', '', '','')
   
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def kategoriak():
    if description == 'film':
        url2 = 'filmek-online/'
    else:
        url2 = 'sorozatok-online/'
    i = requests.get(csillag_url)
    i = re.compile(csillag_url +  url2 + '(.+?)"><strong>(.+?)<').findall(i.content)
    for a, b in i:
        b = BeautifulStoneSoup(b, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
        b = (b.text).encode("UTF-8")
        addDir(b, url2 + a, 2, '', '', description, 1, '', '', '', '', '')
    return
    

def kereses(search_text, page):
    search_url = 'search_term=' + search_text + '&search_type=0&search_where=0&search_rating_start=1&search_rating_end=10&search_year_from=1900&search_year_to=' + current_year
    search_url = base64.b64encode(search_url)
    i = requests.get(csillag_url + '/kereses/' + search_url + '?page=' + str(page))
    m = re.compile('<li>\n.+?href="http://mozicsillag.cc/(.+?)">\n.+?\n.+?\n.+?\n.+?original="/(.+?)" title="(.+?)".+?\n.+?\n.+?>(.+?)<').findall(i.content)
    for a, b, c, d in m:
        d = BeautifulStoneSoup(d, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
        d = (d.text).encode("UTF-8")
        if 'évad' in d:
            addDir(d, a, 9, csillag_url + b, csillag_url + b, '', 1, '', '', '', c,'')
        else:
            addDir(d, a, 3, csillag_url + b, csillag_url + b, '', 1, '', '', '', c,'')   
    if not "(0)'>&raquo;<" in i.content:
        addDir('[COLOR green]Következő oldal[/COLOR]', '', 6, '', '', '', page + 1, search_text, '', '', '','')
    
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def forrasok_Film():
    i =  requests.get(csillag_url + url)
    if 'youtube.com/embed' in i.content:
        youtube_id = re.compile('src=".+?youtube.com/v|embed/(.+?(?=\?|"))').findall(i.content)[0]
    else:
        youtube_id = ''
    plot_info = re.compile('div>\n.+?<p>\n.+?[\s]+(.+?)\n').findall(i.content)[0]
    plot_info = BeautifulStoneSoup(plot_info, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
    plot_info = (plot_info.text).encode("UTF-8")
    
    hosts_url = re.compile('mozicsillag.net/(.+?)"').findall(i.content)[0]
    hosts = requests.get('http://mozicsillag.net/' + hosts_url)
    url_info = re.compile('href="watch-.+?-(.+?)"').findall(hosts.content)
    hosts = re.compile('\(0\);" title="(.+?) - (.+?)".+?\n.+?\n.+?flags/(.+?)\..+?\n.+?\n.+?like(.+?)-').findall(hosts.content)
    if youtube_id != '':
        addFile('[COLOR orange]' + name + ' - ' + 'ELŐZETES''[/COLOR]', name, youtube_id, 13, iconimage, fanart, plot_info, '', '', '', '', '') 
    for a, b, c, d in hosts:
        if b == 'HD':
                b = 'HDRip'
        if a.lower().strip() in supported:            
            if c == 'HU_HU' or c == 'HU':
                c = lang_flags[0] 
                addFile('[COLOR blue]' + b + '[/COLOR]' + ' ' + c + ' ' + a.upper(), name, 'watch' + d + '-' + url_info[0], 4, iconimage, fanart, plot_info, a.lower(), '', '', '', '')
    for a, b, c, d in hosts:
        if a.lower().strip() in supported:             
            if c == 'EN_HU' or c =='SUB_HU':
                c = lang_flags[1]  
                addFile('[COLOR blue]' + b + '[/COLOR]' + ' ' + c + ' ' + a.upper(), name, 'watch' + d + '-' + url_info[0], 4, iconimage, fanart, plot_info, a.lower(), '', '', '', '')
    for a, b, c, d in hosts:
        if a.lower().strip() in supported:            
            if c == 'EN_EN' or c == 'EN':
                c = lang_flags[2]
                addFile('[COLOR blue]' + b + '[/COLOR]' + ' ' + c + ' ' + a.upper(), name, 'watch' + d + '-' + url_info[0], 4, iconimage, fanart, plot_info, a.lower(), '', '', '', '')
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def forrasok_Sorozat():    
    episode = re.compile('Epizód ([0-9]+)').findall(name)
    season = re.compile('([0-9]+). évad').findall(name)
    n_episode = int(episode[0]) + 1
    n_episode = str(n_episode)
    i =  requests.get('http://mozicsillag.net/' + url)
    if 'Epizód ' + n_episode in i.content:
        n = 'Epizód ' + n_episode + '<'
    else:
        n = '</html>'

    i = re.compile('Epizód ' + episode[0] + '([\w\W]+)' + n).findall(i.content)
    m = re.compile("title='(.+?) -.+?\n.+?flags/(.+?)\..+?\n.+?\n.+?like-(.+?)-").findall(i[0])
    url_info = re.compile("href='watch-.+?-(.+?)'").findall(i[0])
    for a, b, c in m:
        if a.lower().strip() in supported:    
            if b == 'HU_HU' or b == 'HU':
                b = lang_flags[0]
                addFile(name + ' ' + b + ' ' + a.upper(), title, 'watch-' + c + '-' + url_info[0], 4, iconimage, fanart, description, a.lower(), '', '', season[0], '')            
    for a, b, c in m:
        if a.lower().strip() in supported:    
            if b == 'EN_HU' or b =='SUB_HU':
                b = lang_flags[1]
                addFile(name + ' ' + b + ' ' + a.upper(), title, 'watch-' + c + '-' + url_info[0], 4, iconimage, fanart, description, a.lower(), '', '', season[0], '')
    for a, b, c in m:
        if a.lower().strip() in supported:    
            if b == 'EN_EN' or b == 'EN':
                b = lang_flags[2]
                addFile(name + ' ' + b + ' ' + a.upper(), title, 'watch-' + c + '-' + url_info[0], 4, iconimage, fanart, description, a.lower(), '', '', season[0], '')
                    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return
 
def getvideo():
    videoitem = xbmcgui.ListItem(label=title, thumbnailImage=iconimage)
    if season != '':
        episode = re.compile('Epizód ([0-9]+)').findall(name)
        videoitem.setInfo(type='Video', infoLabels={'TVshowtitle': title, 'Season': season, 'Episode': episode[0]})
    else:
        videoitem.setInfo(type='Video', infoLabels={'OriginalTitle': orig_title})
    xbmc.Player().play(getMovieSource(url, host), videoitem)
    return

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('' , 'Keresés')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()
        kereses(search_text, 1)
        return
    
##########

def getMovies(url, description):
    if description == 'film':
        return re.compile('<li>\n.+?href="http://mozicsillag.cc/(.+?)">\n.+?\n.+?\n.+?\n.+?original="/(.+?)" title="(.+?)"').findall(url)
    else:
        return re.compile('<li>\n.+?href="http://mozicsillag.cc/(.+?)">\n.+?\n.+?\n.+?\n.+?original="/(.+?)".+?\n.+?\n.+?>(.+?)\(.+?:(.+?)<').findall(url)

def getEpisodes():
    season = re.compile('([0-9]*. évad)').findall(name)
    i =  requests.get(csillag_url + url)
    youtube_id = re.compile('src=".+?youtube.com/v|embed/(.+?(?=\?|"))').findall(i.content)[0]
    
    plot_info = re.compile('div>\n.+?<p>\n.+?[\s]+(.+?)\n').findall(i.content)[0]
    if plot_info:
        plot_info = BeautifulStoneSoup(plot_info, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
        plot_info = (plot_info.text).encode("UTF-8")
    else:
        plot_info = ''
    
    hosts_url = re.compile('mozicsillag.net/(.+?)"').findall(i.content)[0]
    hosts = requests.get('http://mozicsillag.net/' + hosts_url)
   
    episode = re.compile('>(Epizód [0-9]+)').findall(hosts.content)
    if youtube_id:
        addFile('[COLOR orange]' + name + ' - ' + 'ELŐZETES''[/COLOR]', name, youtube_id, 13, iconimage, fanart, plot_info, '', '', '', '', '') 
    for a in episode:
        addDir(season[0] + ' ' + a, hosts_url, 10, iconimage, fanart, plot_info, '', '', '', '', title, '')
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def youtube_trailer():
    
    direct_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url
    videoitem = xbmcgui.ListItem(label=title, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': title})
    xbmc.Player().play(direct_url, videoitem)   
    return

##########
def getMovieSource(url, type):

    i = requests.get('http://mozicsillag.net/' + url)
    type = type.lower().strip()

    if (type=="vidto"):
        url = "http://vidto.me/" + re.compile('vidto.me/embed-(.+?)-').findall(i.content)[0] + ".html"
        direct_url = urlresolve.vidtome(url)
        if direct_url != "HIBA":
            return direct_url
        else:
           just_removed('Vidto.me')
    
    elif (type=="exashare"):
        url = "http://exashare.com/" + re.compile('exashare.com/(.+?).html').findall(i.content)[0] + ".html"
        direct_url = urlresolve.exashare(url)
        if direct_url != "HIBA":
            return direct_url[0]
        else:
           just_removed('Exashare.com')
    
    elif (type=="youwatch"):
        url = "http://youwatch.org/" + re.compile('youwatch.org/(.+?).html').findall(i.content)[0] + ".html"
        direct_url = urlresolve.youwatch(url)
        if direct_url != "HIBA":
            return direct_url[0]
        else:
           just_removed('Youwatch.org')
    
    elif (type=="flashx"):
       url =  "http://flashx.tv/" + re.compile('flashx.tv/(.+?).html').findall(i.content)[0] + ".html"
       direct_url = urlresolve.flashx(url)
       if direct_url != "HIBA":
            return direct_url
       else:
           just_removed('Flasx.tv')
           
    elif (type=="openload.co"):
       url = "https://openload.co/f/" + re.compile('openload.co/f/(.+?)"').findall(i.content)[0]
       direct_url = urlresolve.openload(url)
       if direct_url != "HIBA":
            return direct_url
       else:
           just_removed('Openload.co')
    
    elif (type == "streamin"):
       url = "http://streamin.to/" + re.compile('streamin.to/(.+?).html').findall(i.content)[0] + ".html"  
       direct_url = urlresolve.streamin(url)
       if direct_url != "HIBA":
            return direct_url           
       else:
           just_removed('Streamin.to')

    elif (type == "vodlocker"):
        url = "http://vodlocker.com/embed-" + re.compile('id" value="(.+?)"').findall(i.content)[0] + ".html"
        direct_url = urlresolve.vodlocker(url)
        if direct_url != "HIBA":
            return direct_url[0]            
        else:
           just_removed('Vodlocker.com')
           
    elif (type == "vidzi"):
        url = re.compile('(http://vidzi\.tv/embed[^"]+)').findall(i.content)[0]
        direct_url = urlresolve.vidzi(url)
        if direct_url != "HIBA":
            return direct_url           
        else:
           just_removed('Vidzi.tv')

    elif (type == "indavideo"):
        url = re.compile('indavideo\.hu/player/video/([0-9a-f]+)').findall(i.content)[0]
        direct_url = urlresolve.indavideo(url)        
        if direct_url != "HIBA":
            return direct_url          
        else:
           just_removed('Indavideo.hu')
    
    elif (type == "videa"):
        direct_url = urlresolve.videa(i.content)     
        if direct_url != "HIBA":
            return direct_url          
        else:
           just_removed('Videa.hu')
##########


def addDir(name, url, mode, iconimage, fanart, description, page, category, year, genre, title, orig_title):
    addon_settings = xbmcaddon.Addon()
    
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&category="+str(category)+"&page="+str(page)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&year="+urllib.quote_plus(year)+"&genre="+urllib.quote_plus(genre)+"&title="+urllib.quote_plus(title)+"&orig_title="+urllib.quote_plus(orig_title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description, "Year": year, "Genre": genre } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    return ok

def addFile(name, title, url, mode, iconimage, fanart, description, host, year, genre, season, orig_title):
    addon_settings = xbmcaddon.Addon()
    
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&title="+urllib.quote_plus(title)+"&host="+urllib.quote_plus(host)+"&year="+urllib.quote_plus(year)+"&genre="+urllib.quote_plus(genre)+"&season="+urllib.quote_plus(season)+"&orig_title="+urllib.quote_plus(orig_title)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Year": year, "Genre": genre, "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    xbmcplugin.setContent(addon_handle, 'movies')    
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = 0
category = ''
search_text = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    title = urllib.unquote_plus(params["title"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    category = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    search_text = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    host = urllib.unquote_plus(params["host"])
except:
    pass
try:        
    year = urllib.unquote_plus(params["year"])
except:
    pass
try:        
    genre = urllib.unquote_plus(params["genre"])
except:
    pass
try:        
    season = urllib.unquote_plus(params["season"])
except:
    pass
try:        
    orig_title = urllib.unquote_plus(params["orig_title"])
except:
    pass

if mode == None:
    home()
elif mode == 1:
    filmek()
elif mode == 2:
    listak()
elif mode == 3:
    forrasok_Film()
elif mode == 4:
    getvideo()
elif mode == 5:
    open_search_panel()
elif mode == 6:
    kereses(search_text, page)
elif mode == 9:
    getEpisodes()
elif mode == 10:
    forrasok_Sorozat()
elif mode == 12:
    kategoriak()
elif mode == 13:
    youtube_trailer()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
