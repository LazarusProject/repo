# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, datetime, random, os, json, urlparse
from resources.lib import client, control


REMOTE_DBG = False


# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


current_date = datetime.datetime.now().strftime("%Y-%m-%d")
artPath = control.artPath()

def main_folders():
    addDir('TV2', 'http://tv2.hu', 1, os.path.join(artPath, 'tv2.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '1', '')
    addDir('TV2 Klasszikusok', 'http://tv2.hu/tv2klasszikusok/', 2, os.path.join(artPath, 'tv2class.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '1', '')
    addDir('SuperTV2', 'http://supertv2.hu', 1, os.path.join(artPath, 'supertv2.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('FEM3', 'http://fem3.hu', 1, os.path.join(artPath, 'fem3.png'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Mozi+', 'http://moziplusztv.hu/', 4, os.path.join(artPath, 'moziplusz.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Izaura TV', 'http://izauratv.hu', 5, os.path.join(artPath, 'izauratv.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Prime', 'http://tv2csoport.hu/prime/videok/oldal', 13, os.path.join(artPath, 'prime.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '1')
    addDir('Chili TV', 'http://chilitv.tv/videok/oldal', 14, os.path.join(artPath, 'chilitv.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '1')
    addDir('Kiwi TV', 'http://kiwitv.hu', 15, os.path.join(artPath, 'kiwitv.png'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Zenebutik', 'http://zenebutik.tv/videok/oldal', 17, os.path.join(artPath, 'zenebutik.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '1')
    addDir('Humor+', 'http://humorplusz.hu/videok/oldal', 18, os.path.join(artPath, 'humorplusz.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '1')
    addDir('Tények', 'http://tenyek.hu/', 22, os.path.join(artPath, 'tenyek.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '1')
    return


def musor_listaTV2():  #TV2, Super TV2, FEM3
    r = client.request(url + '/videok/')
    m = re.compile('value="([0-9]+)" > (.+?) </').findall(r)
    for musor_id, musor_cim in m:
        try: name = client.replaceHTMLCodes(musor_cim.decode('utf-8'))
        except: name = musor_cim
        if 'fem3' in url: mode = 10
        elif 'supertv2' in url: mode = 9
        else: mode = 7
        addDir(name.encode('utf-8'), url, mode, iconimage, fanart, musor_id, '1')
    

def musor_lista_TV2_class(): #TV2 Klasszikusok
    r = client.request(url)
    m = client.parseDOM(r, 'div', attrs={'id': 'musorokdropdown'})
    m = client.parseDOM(m, 'a'),client.parseDOM(m, 'a', ret='href')
    m = zip(m[0],m[1])
    for name, link in m:
        try: name = client.replaceHTMLCodes(name)
        except: pass
        addDir(name.encode('utf-8'), link, 8, iconimage, fanart, '', '1')


def musor_lista_mplus(): #Mozi+
    addDir('Teljes filmek', url + 'teljes_filmek/oldal', 11, iconimage, fanart, '', '1')
    addDir('Videók', url + 'videok/oldal', 11, iconimage, fanart, '', '1')


def musor_lista_izaura(): #Izaura TV
    r = client.request(url)
    m = client.parseDOM(r, 'div', attrs={'id': 'dropdown_sorozataink'})
    m = client.parseDOM(m, 'a'),client.parseDOM(m, 'a', ret='href')
    m = zip(m[0],m[1])
    for name, link in m:
        try: name = client.replaceHTMLCodes(name)
        except: pass
        addDir(name.encode('utf-8'),url + link + '/oldal', 12, iconimage, fanart, '', '1')


def musor_lista_kiwitv(): #Kiwi TV
    r = client.request(url)
    m = client.parseDOM(r, 'div', attrs={'id': 'dropdown_musorok'})
    m = client.parseDOM(m, 'a'),client.parseDOM(m, 'a', ret='href')
    m = zip(m[0],m[1])
    for name, link in m:
        try:
            try: name = client.replaceHTMLCodes(name)
            except: pass
            addDir(name.encode('utf-8'),url + link + '/oldal', 16, iconimage, fanart, '', '1')
        except:
            pass
##################################################################

def epizod_lista_TV2():
    r = client.request(url + '/videok/oldal' + page + '?keyword=&datumtol=2000-01-01&datumig=' + current_date + '&musorid=' + description)
    result = client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*balra\s*'})
    result += client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*balra\s*margin10b\s*'})

    for i in result:
        try:
            img = client.parseDOM(i, 'img', ret='src')[0]
            cim = client.parseDOM(i, 'div', attrs={'class': 'cim'})[0]
            name = client.parseDOM(cim, 'a')[0]
            link = client.parseDOM(cim, 'a', ret='href')[0]
            addFile(name.encode('utf-8'), 'http://tv2.hu' + link, 20, 'http://tv2.hu' + img, '', '')
        except:
            pass
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 7, '', '', description, str(int(page) + 1))


def epizod_lista_TV2_class():
    r = client.request('http://tv2.hu' + url + '/oldal' + page)
    result = client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*'})
    result += client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*margin10b\s*'})
    
    for i in result:
        try:
            name = client.parseDOM(i, 'span')
            name = client.parseDOM(name, 'a')
            img = client.parseDOM(i, 'img', ret='src')[0]
            link = client.parseDOM(i, 'a', ret='href')[0]
            addFile(name[0].encode('utf-8') + ' - ' + name[1].encode('utf-8'), 'http://tv2.hu' + link, 20, 'http://tv2.hu' + img, '', '')
        except:
            pass
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 8, '', '', '', str(int(page) + 1))
            
            
def epizod_lista_sTV2():
    r = client.request(url + '/videok/oldal' + page + '?keyword=&datumtol=2000-01-01&datumig=' + current_date + '&musorid=' + description)
    result = client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*'})
    result += client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*margin10b\s*'})
 
    for i in result:
        try:
            img = client.parseDOM(i, 'img', ret='src')[0]
            cim = client.parseDOM(i, 'div', attrs={'class': 'cim'})[0]
            name = client.parseDOM(cim, 'a')[0]
            link = client.parseDOM(cim, 'a', ret='href')[0]
            addFile(name.encode('utf-8'), url + link, 20, url + img, '', '')
        except:
            pass
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 9, '', '', description, str(int(page) + 1))


def epizod_lista_fem3():
    r = client.request(url + '/videok/oldal' + page + '?keyword=&datumtol=2000-01-01&datumig=' + current_date + '&musorid=' + description)
    result = client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*'})
    result += client.parseDOM(r, 'div', attrs={'class': 'listaelem_kicsi\s*margin10b\s*'})

    for i in result:
        try:
            name = client.parseDOM(i, 'div')
            img = client.parseDOM(i, 'img', ret='src')[0]
            link = client.parseDOM(i, 'a', ret='href')[0]
            addFile(name[0].encode('utf-8') + ' - ' + name[1].encode('utf-8'), url + link, 20, url + img, '', '')
        except:
            pass
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 10, '', '', description, str(int(page) + 1))


def epizod_lista_mplus():
    r = client.request(url + page)
    r = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    r = r[0].replace('\n','')
    result = zip(client.parseDOM(r, 'a', ret='href'),client.parseDOM(r, 'a'))
    
    for i in result:
        try:
            name = client.parseDOM(i[1], 'div', attrs={'class': 'cim'})[0]
            if 'teljes_filmek' in url: name = name.rsplit('-', 1)[0].strip()
            name = client.replaceHTMLCodes(name)
            img = client.parseDOM(i[1], 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://moziplusztv.hu' + i[0], 20, img, '', '')
        except:
            pass
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 11, '', '', '', str(int(page) + 1))


def epizod_lista_izaura():
    r = client.request(url + page)
    r = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    r = r[0].replace('\n','')
    result = client.parseDOM(r, 'div', attrs={'class': 'cikk_listaelem'})

    for i in result:
        try:
            name = client.parseDOM(i, 'a', attrs={'class': 'cim'})[0]
            name = client.replaceHTMLCodes(name)
            link = client.parseDOM(i, 'a', ret='href')[0]
            img = client.parseDOM(i, 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://izauratv.hu' + link, 20, 'http://izauratv.hu' + img, '', '')
        except:
            pass
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 12, '', '', '', str(int(page) + 1))
    return
 

def epizod_lista_prime():
    r = client.request(url + page)
    result = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    result = client.parseDOM(result, 'div', attrs={'class': 'cikk_listaelem'})

    for i in result:
        try:
            name = client.parseDOM(i, 'a', attrs={'class': 'cim'})[0]
            name = client.replaceHTMLCodes(name)
            link = client.parseDOM(i, 'a', ret='href')[0]
            img = client.parseDOM(i, 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://tv2csoport.hu' + link, 20, 'http://tv2csoport.hu' + img, '', '')
        except:
            pass
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 13, '', '', '', str(int(page) + 1))
    return


def epizod_lista_chili():
    r = client.request(url + page)
    result = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    result = client.parseDOM(result, 'div', attrs={'class': 'cikk_listaelem'})

    for i in result:
        try:
            name = client.parseDOM(i, 'div', attrs={'class': 'cim'})[0]
            name = re.search('>([^<]+)', name).group(1)
            name = client.replaceHTMLCodes(name)
            link = client.parseDOM(i, 'a', ret='href')[0]
            img = client.parseDOM(i, 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://chilitv.tv' + link, 20, 'http://chilitv.tv' + img, '', '')
        except:
            pass
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 14, '', '', '', str(int(page) + 1))
    return


def epizod_lista_kiwitv():
    r = client.request(url + page)
    result = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})[0]
    result = result.split('clear="all"')

    for i in result:
        try:
            name = client.parseDOM(i, 'div', attrs={'class': 'cim'})[0]
            name = client.replaceHTMLCodes(name)
            link = client.parseDOM(i, 'a', ret='href')[0]
            img = client.parseDOM(i, 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://kiwitv.hu' + link, 20, img, '', '')
        except:
            pass
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 16, '', '', '', str(int(page) + 1))
    return


def epizod_lista_zenebutik():
    r = client.request(url + page)
    result = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    result = client.parseDOM(result, 'div', attrs={'class': 'cikk_listaelem'})

    for i in result:
        try:
            name = client.parseDOM(i, 'a', attrs={'class': 'cim'})[0]
            name = client.replaceHTMLCodes(name)
            link = client.parseDOM(i, 'a', ret='href')[0]
            img = client.parseDOM(i, 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://zenebutik.tv' + link, 20, 'http://zenebutik.tv' + img, '', '')
        except:
            pass
    if '/assets/next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 17, '', '', '', str(int(page) + 1))
    return


def epizod_lista_humorplusz():
    r = client.request(url + page)
    result = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    result = client.parseDOM(result, 'div', attrs={'class': 'cikk_listaelem_nagy'})

    for i in result:
        try:
            name = client.parseDOM(i, 'a', attrs={'class': 'cim'})[0]
            name = client.replaceHTMLCodes(name)
            link = client.parseDOM(i, 'a', ret='href')[0]
            img = client.parseDOM(i, 'img', ret='src')[0]
            addFile(name.encode('utf-8'), 'http://humorplusz.hu' + link, 20, 'http://humorplusz.hu' + img, '', '')
        except:
            pass
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 18, '', '', '', str(int(page) + 1))
    return


def tenyek_adasok():
    r = client.request(url + 'osszes_videok/oldal' + page + '&datumig=' + current_date)
    m = re.compile('datum">(.+?)<.+?\n.+?\n.+?<a href="(.+?)".+?src="(http.+?)".+?\n.+? />(.+?)<').findall(r)
    for date, url2, img, name in m:
        try: name = client.replaceHTMLCodes(name.decode('utf-8'))
        except: pass
        addFile(date + ' ' + '-' + ' ' + name.encode('utf-8'), url + url2, 20, img, os.path.join(artPath, 'tenyek_b.jpg'), '')
    if 'class="next"' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 22, '', '', '', str(int(page) + 1))
    return


def getVideo():
    control.busy()
    r = client.request(url)
    try:
        json_url = re.search('jsonUrl\s*=\s*[\'"]([^\'"]+)', r).group(1)

        json_url = re.sub('^//', 'http://', json_url)
        r = client.request(json_url)
        json_data = json.loads(r)
        sources = zip(json_data['mp4Labels'], json_data['backupBitrates']['mp4'])
        sources = [(i[0].encode('utf-8'), i[1].encode('utf-8')) for i in sources if i[0].lower().strip() != 'auto']
        sources = sorted(sources, key=lambda x: x[0])[::-1]
        servers = json_data['servers']

        autopick = control.setting('autopick')
        control.idle()

        if len(sources) == 1:
            direct_link = sources[0][1]
        elif len(sources) > 1:
            if autopick == '1':
                direct_link = sources[0][1]
            else:
                result = xbmcgui.Dialog().select((u'Min\u0151s\u00E9g'), [source[0] if source[0] else 'Uknown' for source in sources])
                if result == -1:
                    return
                else:
                    direct_link = sources[result][1]

        direct_link = 'http://' + random.choice(servers).encode('utf-8') + urlparse.urlparse(direct_link).path

        videoitem = xbmcgui.ListItem(name, thumbnailImage=iconimage)   
        videoitem.setInfo(type='Video', infoLabels={'Title': name})
        xbmc.Player().play(direct_link, videoitem)
    except:
        return


def addDir(name, url, mode, iconimage, fanart, description, page):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+urllib.quote_plus(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = None
maxbitrate=0
simpleDownloader=False

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:
    page = urllib.unquote_plus(params["page"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass


if mode==None:
    main_folders()
elif mode==1:
    musor_listaTV2()
elif mode==2:
    musor_lista_TV2_class()
elif mode==3:
    musor_lista_sTV2()
elif mode==4:
    musor_lista_mplus()
elif mode==5:
    musor_lista_izaura()
elif mode==6:
    musor_lista_prime()
elif mode==22:
    tenyek_adasok()
elif mode==7:
    epizod_lista_TV2()
elif mode==8:
    epizod_lista_TV2_class()
elif mode==9:
    epizod_lista_sTV2()
elif mode==10:
    epizod_lista_fem3()
elif mode==11:
    epizod_lista_mplus()
elif mode==12:
    epizod_lista_izaura()
elif mode==13:
    epizod_lista_prime()
elif mode==14:
    epizod_lista_chili()
elif mode==15:
    musor_lista_kiwitv()
elif mode==16:
    epizod_lista_kiwitv()
elif mode==17:
    epizod_lista_zenebutik()
elif mode==18:
    epizod_lista_humorplusz()
elif mode==20:
    getVideo()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
