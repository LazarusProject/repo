# -*- coding: utf-8 -*-
import requests, xbmc, xbmcgui, urllib, re, xbmcplugin, datetime, random, os
from resources.lib import client, control

current_date = datetime.datetime.now().strftime("%Y-%m-%d")
artPath = control.artPath()

def main_folders():  
    addDir('TV2', 'http://tv2.hu', 1, os.path.join(artPath, 'tv2.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '1', '')
    addDir('TV2 Klasszikusok', 'http://tv2.hu/tv2klasszikusok/', 2, os.path.join(artPath, 'tv2class.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '1', '')
    addDir('SuperTV2', 'http://supertv2.hu', 1, os.path.join(artPath, 'supertv2.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('FEM3', 'http://fem3.hu', 1, os.path.join(artPath, 'fem3.png'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Mozi+', 'http://moziplusztv.hu/', 4, os.path.join(artPath, 'moziplusz.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Izaura TV', 'http://izauratv.hu', 5, os.path.join(artPath, 'izauratv.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '')
    addDir('Tények', 'http://tenyek.hu/', 6, os.path.join(artPath, 'tenyek.jpg'), os.path.join(artPath, 'tv2csop.jpg'), '', '1')
    return


def musor_listaTV2():  #TV2, Super TV2, FEM3
    r = client.request(url + '/videok/')
    m = re.compile('value="([0-9]+)" > (.+?) </').findall(r)
    for musor_id, musor_cim in m:
        try: name = client.replaceHTMLCodes(musor_cim.decode('utf-8'))
        except: name = musor_cim
        if 'fem3' in url: mode = 10
        elif 'supertv2' in url: mode = 9
        else: mode = 7
        addDir(name.encode('utf-8'), url, mode, iconimage, fanart, musor_id, '1')
    

def musor_lista_TV2_class(): #TV2 Klasszikusok
    r = client.request(url)
    m = client.parseDOM(r, 'div', attrs={'id': 'musorokdropdown'})
    m = client.parseDOM(m, 'a'),client.parseDOM(m, 'a', ret='href')
    m = zip(m[0],m[1])
    for name, link in m:
        try: name = client.replaceHTMLCodes(name)
        except: pass
        addDir(name.encode('utf-8'), link, 8, iconimage, fanart, '', '1')


def musor_lista_mplus(): #Mozi+
    addDir('Teljes filmek', url + 'teljes_filmek/oldal', 11, iconimage, fanart, '', '1')
    addDir('Videók', url + 'videok/oldal', 11, iconimage, fanart, '', '1')


def musor_lista_izaura(): #Izaura TV
    r = client.request(url)
    m = client.parseDOM(r, 'div', attrs={'id': 'dropdown_sorozataink'})
    m = client.parseDOM(m, 'a'),client.parseDOM(m, 'a', ret='href')
    m = zip(m[0],m[1])
    for name, link in m:
        try: name = client.replaceHTMLCodes(name)
        except: pass
        addDir(name.encode('utf-8'),url + link, 12, iconimage, fanart, '', '1')

##################################################################

def epizod_lista_TV2():
    r = client.request(url + '/videok/oldal' + page + '?keyword=&datumtol=2000-01-01&datumig=' + current_date + '&musorid=' + description)
    m = re.compile('img src="(.+?.jpg|\?).+?\n.+?href="(.+?.html).+?>(.+?)<.+?\n.+?html">(.+?)</').findall(r)
    for img, url2, date, name in m:
        try: name = client.replaceHTMLCodes(name.decode('utf-8'))
        except: pass
        addFile(date + ' ' + '-' + ' ' + name.encode('utf-8'), 'http://tv2.hu' + url2, 20, 'http://tv2.hu' + img, '', '')
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 7, '', '', description, str(int(page) + 1))


def epizod_lista_TV2_class():
    r = client.request('http://tv2.hu' + url + '/oldal' + page)
    m = re.compile('img src="(.+?.jpg|\?).+?\n.+?href="(.+?.html).+?>(.+?)<.+?\n.+?html">(.+?)</').findall(r)
    for img, url2, date, name in m:
        try: name = client.replaceHTMLCodes(name.decode('utf-8'))
        except: pass
        addFile(date + ' ' + '-' + ' ' + name.encode('utf-8'), 'http://tv2.hu' + url2, 20, 'http://tv2.hu' + img, '', '')
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 8, '', '', '', str(int(page) + 1))
            
            
def epizod_lista_sTV2():
    r = client.request(url + '/videok/oldal' + page + '?keyword=&datumtol=2000-01-01&datumig=' + current_date + '&musorid=' + description)
    m = re.compile('img src="(.+?.jpg|\?).+?\n.+?href="(.+?.html).+?>(.+?)<.+?\n.+?html">(.+?)</').findall(r)
    for img, url2, date, name in m:
        try: name = client.replaceHTMLCodes(name.decode('utf-8'))
        except: pass
        addFile(date + ' ' + '-' + ' ' + name.encode('utf-8'), url + url2, 20, url + img, '', '')
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 9, '', '', description, str(int(page) + 1))


def epizod_lista_fem3():
    r = client.request(url + '/videok/oldal' + page + '?keyword=&datumtol=2000-01-01&datumig=' + current_date + '&musorid=' + description)
    m = re.compile('href="(.+?.html).+?src="(.+?)".+?\n.+?>(.+?)<.+?\n.+?>(.+?)<').findall(r)
    for url2, img, date, name in m:
        try: name = client.replaceHTMLCodes(name.decode('utf-8'))
        except: pass
        addFile(date + ' ' + '-' + ' ' + name.encode('utf-8'), url + url2, 20, url + img, '', '')
    if 'következő oldal' in r or 'következő  &raquo;' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 10, '', '', description, str(int(page) + 1))


def epizod_lista_mplus():
    r = client.request(url + page)
    r = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    r = r[0].replace('\n','')
    result = re.compile('<a href="?\'?([^"\']*).+?img src="(.+?)".+?"cim">(.+?)<').findall(r)
    for link, img, name in result:
        if 'teljes_filmek' in url: name = name.replace(' - Teljes film','')
        try: name = client.replaceHTMLCodes(name)
        except: pass
        addFile(name.encode('utf-8'), 'http://moziplusztv.hu' + link, 20, img, '', '')
    if '/pager_next' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 11, '', '', '', str(int(page) + 1))


def epizod_lista_izaura():
    r = client.request(url)
    r = client.parseDOM(r, 'div', attrs={'class': 'leftblock'})
    r = r[0].replace('\n','')
    result = re.compile('<a href="?\'?([^"\']*).+?img src="(.+?)".+?"cim">(.+?)<').findall(r)
    for link, img, name in result:
        try: name = client.replaceHTMLCodes(name)
        except: pass
        addFile(name.encode('utf-8'), 'http://izauratv.hu' + link, 20, 'http://izauratv.hu' + img, '', '')
    return
 

def tenyek_adasok():
    r = client.request(url + 'osszes_videok/oldal' + page + '&datumig=' + current_date)
    m = re.compile('datum">(.+?)<.+?\n.+?\n.+?<a href="(.+?)".+?src="(http.+?)".+?\n.+? />(.+?)<').findall(r)
    for date, url2, img, name in m:
        try: name = client.replaceHTMLCodes(name.decode('utf-8'))
        except: pass
        addFile(date + ' ' + '-' + ' ' + name.encode('utf-8'), url + url2, 20, img, os.path.join(artPath, 'tenyek_b.jpg'), '')
    if 'class="next"' in r:
        addDir('[COLOR green]''Következő oldal''[/COLOR]', url, 6, '', '', '', str(int(page) + 1))
    return


def getVideo():
    r = client.request(url)
    try:
        r = re.compile('jsonUrl\s?=\s?[\'|"](.+?)[\'|"]').findall(r)[0]
        if '.mp4?' in r: direct_link = r
        else:
            r = client.request(r)
            r = r.replace('\\','')
            result = re.compile('tv2\.hu([^:]+\.mp4)"').findall(r)
            direct_link = []
            [direct_link.append(x) for x in result if x not in direct_link]
            servers = re.compile('servers\s?"\s?:(.*)').findall(r)[0]
            servers = re.compile('"(.+?)"').findall(servers)
            quality = control.setting('quality')
            try:
                if quality == '0': raise Exception()
                q_list = [('',''), ('720p','br1'), ('576p','br2'), ('360p','400k'), ('180p','')]
                q = q_list[int(quality)]
                try: direct_link = 'http://' + random.choice(servers) + ([i for i in direct_link if (q[0]+'.mp4') in i][0])
                except: direct_link = 'http://' + random.choice(servers) + ([i for i in direct_link if (q[1]+'.mp4') in i][0])
            except:
                q_list = [(re.compile('([0-9a-z]+)\.mp4').findall(i)[0]) for i in direct_link]
                dre = re.compile(r'(\d+)')
                q_list.sort(key=lambda l: [int(s) if s.isdigit() else s.lower() for s in re.split(dre, l)], reverse=True)
                dialog = control.dialog
                q = dialog.select('Minőség', q_list)
                if q == -1: return
                direct_link = 'http://' + random.choice(servers) + ([i for i in direct_link if (q_list[q]+'.mp4') in i][0])
        videoitem = xbmcgui.ListItem(name, thumbnailImage=iconimage)   
        videoitem.setInfo(type='Video', infoLabels={'Title': name})
        xbmc.Player().play(direct_link, videoitem)
    except:
        pass
    
    
    try:
        if control.setting('html5_url') == 'false' and not 'tv2klasszikusok' in url:
            r = r.replace('\n','')
            m = re.compile('playlist:\[\{.+?url:\s"?\'?([^"\'>]*)').findall(r)[0]
            f4mlink = client.request(m)
            f4mlink = client.parseDOM(f4mlink, 'url')
            f4mlink = random.choice(f4mlink)
            direct_link = client.request(f4mlink)
            direct_link = re.compile('media href="?\'?([^"\'>]*)').findall(direct_link)
            quality = control.setting('quality')
            try:
                if quality == '0': raise Exception()
                q_list = [('',''), ('720p','br1'), ('576p','br2'), ('360p','400k')]
                q = q_list[int(quality)]
                try: direct_link = [i for i in direct_link if (q[0]+'.mp4') in i][0]
                except: direct_link = [i for i in direct_link if (q[1]+'.mp4') in i][0]
            except:
                q_list = [(re.compile('([0-9a-z]+)\.mp4').findall(i)[0]) for i in direct_link]
                dialog = control.dialog
                q = dialog.select('Minőség', q_list)
                if q == -1: return
                direct_link = [i for i in direct_link if (q_list[q]+'.mp4') in i][0]
            playF4mLink(direct_link, name, 0)
        else:
            direct_link = re.compile('html5url\s?=\s?"(http.+?)"').findall(r)[0]
            videoitem = xbmcgui.ListItem(name, thumbnailImage=iconimage)   
            videoitem.setInfo(type='Video', infoLabels={'Title': name})
            xbmc.Player().play(direct_link, videoitem)
    except:
        return


def playF4mLink(url,name,maxbitrate,proxy=None,use_proxy_for_chunks=False,auth_string=None,streamtype='HDS',setResolved=False,swf=""):
    from F4mProxy import f4mProxyHelper
    player=f4mProxyHelper()
    player.playF4mLink(url, name, proxy, use_proxy_for_chunks,maxbitrate,simpleDownloader,auth_string,streamtype,setResolved,swf)   
    return  


def addDir(name, url, mode, iconimage, fanart, description, page):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+urllib.quote_plus(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = None
maxbitrate=0
simpleDownloader=False

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:
    page = urllib.unquote_plus(params["page"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass


if mode==None:
    main_folders()
elif mode==1:
    musor_listaTV2()
elif mode==2:
    musor_lista_TV2_class()
elif mode==3:
    musor_lista_sTV2()
elif mode==4:
    musor_lista_mplus()
elif mode==5:
    musor_lista_izaura()
elif mode==6:
    tenyek_adasok()
elif mode==7:
    epizod_lista_TV2()
elif mode==8:
    epizod_lista_TV2_class()
elif mode==9:
    epizod_lista_sTV2()
elif mode==10:
    epizod_lista_fem3()
elif mode==11:
    epizod_lista_mplus()
elif mode==12:
    epizod_lista_izaura()
elif mode==20:
    getVideo()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
