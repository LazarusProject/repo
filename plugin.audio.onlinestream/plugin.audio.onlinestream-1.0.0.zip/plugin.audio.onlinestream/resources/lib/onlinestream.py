# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys,urllib,re,urlparse,json

from resources.lib import client
from resources.lib import control
from resources.lib import cache
from resources.lib import directory


class indexer:
    def __init__(self):
        self.list = []
        self.streamstat_url = 'https://onlinestream.hu'
        self.headers = {'User-Agent': 'Online Stream for Kodi/%s' % control.addonInfo('version')}


    def root(self):        
        self.list = [

        {
        'title': 32002,
        'action': 'radio_list',
        'icon': 'radios.png'
        },
                     
        {
        'title': 32004,
        'action': 'search',
        'icon': 'search.png'
        }
        ]

        directory.add(self.list)
        return self.list

    
    def radio_list(self, searchtext = None):
        self.list = self.get_radio_list()

        if self.list == None: return
        if not searchtext == None:
            self.list = [i for i in self.list if searchtext.lower() in i['title'].lower()]
            if not self.list:
                control.infoDialog(control.lang(32012).encode('utf-8'))
                return

        for i in self.list: i.update({'action': 'stream_list'})

        directory.add(self.list)


    def get_radio_list(self):
        stations = cache.get(self.get_stations, 1)

        stations = [i for i in stations if client.parseDOM(i, 'tv')[0] == '0']

        for item in stations:
            try:
                try: item = item.encode('iso-8859-1').decode('utf8')
                except: pass
                title = client.parseDOM(item, 'title')[0]
                title = client.replaceHTMLCodes(title).replace("&apos;", "'").strip().encode('utf-8')
                
                description = client.parseDOM(item, 'description')[0]
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").strip().encode('utf-8')

                station_id = client.parseDOM(item, 'station_id')[0].strip().encode('utf-8')
                
                listeners = client.parseDOM(item, 'listeners')[0].strip().encode('utf-8')
                listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else ''
                
                listeners_peak = client.parseDOM(item, 'listeners_peak')[0].strip().encode('utf-8')
                
                logo = client.parseDOM(item, 'logo')[0].strip().encode('utf-8')
                
                broadcast = client.parseDOM(item, 'broadcast')[0].strip().encode('utf-8')
                broadcast = 'DAB+/FM' if broadcast == '1' else ''
                
                station_title = '[COLOR white][B]%s[/B][/COLOR]' % title
                if not broadcast == '': station_title += '  [COLOR FF008000]%s[/COLOR]' % broadcast
                if not listeners == '': station_title += '  [%s/%s]' % (listeners, listeners_peak)
                
                cm = [{'title': control.lang(32009).encode('utf-8'), 'query': {'action': 'track_list', 'station_id': station_id}}]

                self.list.append({'title': title, 'label': station_title, 'image': logo, 'station_id': station_id, 'cm': cm})
            except:
                pass

        return self.list


    def stream_list(self, station_id, image):
        self.list = self.get_stream_list(station_id)

        if self.list == None: return

        ch_list = [i['title'] for i in self.list]
        
        if len(self.list) > 1:
            q = control.selectDialog(ch_list, control.lang(32008).encode('utf-8'))
            if q == -1: return
        else: q = 0

        stream_url = self.list[q]['stream_url']
        self.play(stream_url, image)


    def track_list(self, station_id):
        try:
            self.list = self.get_stream_list(station_id)
    
            if self.list == None: return
    
            ch_list = [i['title'] for i in self.list]
            
            if len(self.list) > 1:
                ch_id = control.selectDialog(ch_list, control.lang(32008).encode('utf-8'))
                if ch_id == -1: return
            else: ch_id = 0
            ch_id = str(ch_id + 1)
    
            query = urlparse.urljoin(self.streamstat_url, '/tracklist-xml.cgi?id=%s&ch=%s' % (station_id, ch_id))
            r = client.request(query, headers=self.headers)
            try: r = r.decode('iso-8859-1').encode('utf8')
            except: pass
            
            result = client.parseDOM(r, 'onlinestream.hu')[0]

            title = client.parseDOM(result, 'title')[0]
            try: title = title.encode('iso-8859-1').decode('utf8')
            except: pass
            title = client.replaceHTMLCodes(title).encode('utf-8')

            tracklist = client.parseDOM(result, 'track')[:200]
            tr = []
            for track in tracklist:
                try:
                    time = client.parseDOM(track, 'time')[0].encode('utf-8')

                    song = client.parseDOM(track, 'song')[0].strip()
                    try: song = song.encode('iso-8859-1').decode('utf8')
                    except: pass
                    if (song == '' or song == '-' or song == '?'): raise Exception()
                    song = client.replaceHTMLCodes(song).replace("&apos;", "'").encode('utf-8')
                    
                    label = '[B][COLOR white]%s[/COLOR][/B]  %s' % (time, song)
                    tr.append(label)
                except:
                    pass

            if len(tr) == 0:
                control.infoDialog(control.lang(32010).encode('utf-8')); raise Exception()

            control.selectDialog(tr, title)
            return
        except:
            return


    def get_stream_list(self, station_id):
        stations = cache.get(self.get_stations, 1)
        
        station = [i for i in stations if station_id == client.parseDOM(i, 'station_id')[0].encode('utf-8')]

        channels = client.parseDOM(station, 'channel')

        for item in channels:
            try:
                format = client.parseDOM(item, 'format')[0].strip().encode('utf-8')
                if format.lower() in ['flv', 'mpegts']: continue
                
                channel_id = client.parseDOM(item, 'channel_id')[0].strip().encode('utf-8')

                channel_title = client.parseDOM(item, 'title')[0].strip().encode('utf-8')

                description = client.parseDOM(item, 'description')[0]
                description = client.replaceHTMLCodes(description).replace("&apos;", "'").strip().encode('utf-8')

                #channel_title = '%s - %s' % (title, description) if (title != description and description != '' and title != '') else title

                listeners = client.parseDOM(item, 'listeners')[0].strip().encode('utf-8')
                listeners = listeners if listeners.isdigit() and int(listeners) >= 0 else '?'
                
                listeners_peak = client.parseDOM(item, 'listeners_peak')[0].strip().encode('utf-8')
                
                stream_url = client.parseDOM(item, 'stream_url')[0].strip().encode('utf-8')
                
                bitrate = client.parseDOM(item, 'bitrate')[0].strip().encode('utf-8')
                
                title = '%s: %s [%s/%s] [%s, %s kbps]' % (channel_id, channel_title, listeners, listeners_peak, format, bitrate)
                
                title = re.sub('\[\?\/.*\]\s', '', title)
                if re.search(',\s+\D', title):
                    title = re.sub('\s*kbps', '', title)
                litle = title.replace('[?, ', '[').replace('[, ', '[')
                title = re.sub(',\s*\?', '', title)
                title = re.sub('\[\s*\??\s*\]', '', title)

                self.list.append({'title': title, 'stream_url': stream_url})
            except:
                pass
        
        return self.list


    def search(self):
        try:
            control.idle()

            t = control.lang(32004).encode('utf-8')
            k = control.keyboard('', t) ; k.doModal()
            q = k.getText() if k.isConfirmed() else None

            if (q == None or q == '' or len(q) < 2): raise Exception()

            url = '%s?action=radio_list&search_text=%s' % (sys.argv[0], urllib.quote_plus(q))
            control.execute('Container.Update(%s)' % url)
        except:
            return


    def play(self, url, image):
        liz=control.item(iconImage=image, thumbnailImage=image)
        liz.setInfo(type="Audio", infoLabels={})
        liz.setProperty('mimetype', 'audio/mpeg')
        control.player.play(url, liz)


    def get_stations(self):
        try:
            query = urlparse.urljoin(self.streamstat_url, '/list.xml')
            xml = client.request(query, headers=self.headers)
            try: xml = xml.decode('iso-8859-1').encode('utf8')
            except: pass
            if not '<station>' in xml: raise Exception()
            stations = client.parseDOM(xml, 'station')
            try: stations = [i.encode('iso-8859-1').decode('utf8') for i in stations]
            except: pass
            return stations
        except:
            control.infoDialog(control.lang(32011).encode('utf-8')); cache.clear()
