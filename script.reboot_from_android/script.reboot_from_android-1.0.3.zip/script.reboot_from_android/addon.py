import xbmcaddon
import xbmcgui
import xbmc
import time
 
addon = xbmcaddon.Addon()
addonname = addon.getLocalizedString(32000)
text = addon.getLocalizedString(32001)
button = addon.getLocalizedString(32002)
msg_yes = addon.getLocalizedString(32003)
msg_no = addon.getLocalizedString(32004)

yesnowindow = xbmcgui.Dialog().yesno(addonname, text, "",  "", button, "Ok" )

if yesnowindow:
    xbmc.executebuiltin("Notification(LE Info, " + msg_yes.encode('utf-8') + ")")
    time.sleep(2)
    xbmc.executebuiltin('System.Exec(rebootfromnand)')
else:
    xbmc.executebuiltin("Notification(LE Info, " + msg_no.encode('utf-8') + ")")




