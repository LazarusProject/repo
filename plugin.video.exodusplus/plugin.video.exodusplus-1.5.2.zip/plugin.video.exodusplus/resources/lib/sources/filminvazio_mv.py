# -*- coding: utf-8 -*-

import re,urllib,urllib2,urlparse

from resources.lib.modules import client


class source:
    def __init__(self):
        self.domains = ['filminvazio.com']
        self.base_link = 'http://filminvazio.com/'
        self.search_link = 'http://filminvazio.com/filmkereso/?'
        self.host_link = 'http://filmbirodalmak.com/'

    def movie(self, imdb, title, year):
        try:
            years = [str(int(year)-1), str(int(year)+1)] 
            
            t = 'http://www.imdb.com/title/%s' % imdb
            t = client.request(t, headers={'Accept-Language':'hu-HU'})
            t = client.parseDOM(t, 'title')[0]
            originaltitle = re.sub('(?:\(|\s)\d{4}.+', '', t).strip()
            originaltitle = originaltitle.replace(' ','+')

            try:
                if originaltitle == None: raise Exception()
                search_url = 'search_query=' + originaltitle.encode('utf-8') + '&orderby=&order=&tax_fecha-estreno%5B%5D=' + years[0] + '&tax_fecha-estreno%5B%5D=' + year + '&tax_fecha-estreno%5B%5D=' + years[1] + '&wpas=1'
                query = self.search_link + search_url
                result = client.request(query)
                if 'Nem tal\xc3\xa1ltam' in result: result = None
            except:
                pass

            result = client.parseDOM(result, 'span', attrs={'class': 'titulo'})
            result = client.parseDOM(result, 'a', ret='href')
            for a in result:
                query = client.replaceHTMLCodes(a)
                page_src = client.request(query)
                page_src = page_src.replace('\n','')
                if 'imdb.com/title/tt' in page_src:                                                 
                    imdb_id = re.compile('imdb.com/title/(tt[0-9]+)').findall(page_src)[0]
                    if imdb_id == imdb:
                        url = client.parseDOM(page_src, 'li', attrs={'class': 'elemento'})
                        url = client.parseDOM(url, 'a', ret='href')[0]
                        url = client.replaceHTMLCodes(url)
                        url = url.encode('utf-8') 
                        return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            
            result = client.request(url)
            #result = result.decode('iso-8859-1').encode('utf-8')
            result = client.parseDOM(result, 'div', attrs={'class': 'enlaces_box'})[0]
            result = result.replace('\n','')
            result = re.compile('a href="(.+?)".+?"c">(.+?)<.+?"d">(.+?)<').findall(result)
                               
            for i in result:
                try:     
                    if 'TS' in i[2] or 'CAM' in i[2]: quality = 'CAM'
                    elif 'DVD' in i[2] or 'TV' in i[2]: quality = 'SD'                    
                    else: quality = 'SD'
                    if i[1] == 'Magyar' or 'Szinkron' in i[1]: lang = 'szinkron'
                    else: lang = ''
                    url = client.replaceHTMLCodes(i[0])
                    url = url.encode('utf-8') 
                    host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                    if not host in hostDict: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')  
                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Filminvazio', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        return url


