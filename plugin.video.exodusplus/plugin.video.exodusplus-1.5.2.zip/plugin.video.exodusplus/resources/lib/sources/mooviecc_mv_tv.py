# -*- coding: utf-8 -*-

import re,urllib,urllib2,urlparse,json
from resources.lib.modules import client
from resources.lib.modules import cleantitle


class source:
    def __init__(self):
        self.domains = ['moovie.cc']
        self.base_link = 'http://www.moovie.cc/'
        self.host_link = 'http://filmbazis.org/'
        self.search_link = 'http://www.moovie.cc/core/ajax/movies.php'

    def movie(self, imdb, title, year):
        try:
            years = [str(int(year)-1), str(int(year)+1)]
            result = None
            
            query = urlparse.urljoin(self.base_link, '/core/search.json')
            r = client.request(query)
            
            result = json.loads(r)
            result = [i for i in result if year == i['year']]
            t = cleantitle.get(title)
            result2 = [i for i in result if t == cleantitle.get(i['title_eng'])]
            if len(result2) == 0:
                result2 = [i for i in result if t == cleantitle.get(i['title_hun'])]
            if len(result2) == 0 or len(result2) > 10: raise Exception()
            
            for i in result2:
                query = urlparse.urljoin(self.base_link, '/online-filmek/' + i['title_url'])
                r = client.request(query)
                if 'imdb.com/title/tt' in r:
                    imdb_id = re.search('imdb.com/title/(tt[0-9]+)/', r).group(1)
                    if imdb_id == imdb:
                        movie_id = re.search('movie_id\s*:([0-9]+)', r).group(1)
                        post = urllib.urlencode({'type': 'get_movie_links', 'query': 'movie_id:' + movie_id + '|season:0'})
                        query = urlparse.urljoin(self.host_link, '/movies.php')
                        r = client.request(query, post = post)
                        result = client.parseDOM(r, 'tr', attrs={'class': 'movie-link'})
                        return result
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, year):        
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return
 
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            if 'year' in data: year = data['year']

            query = urlparse.urljoin(self.base_link, '/core/search.json')
            r = client.request(query)
            
            result = json.loads(r)
            t = cleantitle.get(title)
            result2 = [i for i in result if t == cleantitle.get(i['title_eng'])]
            if len(result2) == 0:
                result2 = [i for i in result if t == cleantitle.get(i['title_hun'])]
            if len(result2) == 0 or len(result2) > 10: raise Exception()

            for i in result2:
                query = urlparse.urljoin(self.base_link, '/online-filmek/' + i['title_url'])
                r = client.request(query)
                if 'imdb.com/title/tt' in r:
                    imdb_id = re.search('imdb.com/title/(tt[0-9]+)/', r).group(1)
                    if imdb_id == imdb:
                        movie_id = re.search('movie_id\s*:([0-9]+)', r).group(1)
                        query = urlparse.urljoin(self.host_link, '/movies.php')
                        post = urllib.urlencode({'type': 'get_movie_links', 'query': 'movie_id:' + movie_id + '|season:' + season})
                        r = client.request(query, post = post)
                        result = client.parseDOM(r, 'tr', attrs = {'class': 'movie-episode-link movie-episode-' + episode})
                        return result
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources

            locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]

            for i in url:
                try:
                    host = client.parseDOM(i, 'span')[0]
                    host = host.rsplit('.', 1)[0].strip().lower()
                    host = [x[1] for x in locDict if host == x[0]][0]
                    if not host in hostDict: raise Exception()

                    q = client.parseDOM(i, 'span')[1]
                    if 'Mozis' in q: quality = 'CAM'
                    elif 'DVD' in i or 'TV' in i: quality = 'SD'                    
                    else: quality = 'SD'
                    
                    l = client.parseDOM(i, 'img', ret='src')[0]
                    l = l.split('/')[-1].rsplit('.', 1)[0]
                    if l == 'hu' or l == 'hu-hu': lang = 'szinkron'
                    else: lang = ''
                    
                    url = client.parseDOM(i, 'a', ret='href')[0]
                    url = client.replaceHTMLCodes(url)
                    url = urlparse.urljoin(self.host_link, url)
                    url = url.encode('utf-8')

                    sources.append({'source': host, 'quality': quality, 'lang': lang, 'provider': 'Mooviecc', 'url': url, 'direct': False, 'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources


    def resolve(self, url):
        try:
            result = client.request(url)
            result = client.parseDOM(result, 'table', attrs={'class':'links'})[0]
            url = client.parseDOM(result, 'a', attrs={'target':'_blank'}, ret='href')[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except:
            return
