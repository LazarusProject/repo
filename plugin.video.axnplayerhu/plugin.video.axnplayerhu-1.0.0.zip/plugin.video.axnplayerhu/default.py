# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,requests,json,urlparse

from resources.lib import client, control


REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


axnplay_url = 'http://hu.axn.com'

def shows():
    query = urlparse.urljoin(axnplay_url, '/axn-player/minden-video')
    shows = getShows(query)
    for item in shows:
        try:
            addDir3(item[0].encode('utf-8'), item[1], 1, control.addonIcon(), control.addonFanart(), '0')
        except:
            pass


def getShows(url):
    try:
        result = requests.get(url).content
        shows = client.parseDOM(result, 'form', attrs={'action': '/axn-player/minden-video'})
        shows = client.parseDOM(shows, 'option'),client.parseDOM(shows, 'option', ret='value')
        shows = zip(shows[0], shows[1])
        shows = [i for i in shows if not i[1] == '']
        shows = list(set(shows))
        shows = sorted(shows, key=lambda tup:tup[0])
        return shows
    except:
        return


def episodes():
    query = urlparse.urljoin(axnplay_url, url + '?page=' + page)
    videos = getEpisodes(query)
    syshandle = int(sys.argv[1])
    for item in videos[0]:
        try:
            art = {}
            meta = {}
            
            title = client.parseDOM(item, 'h2', attrs={'class': 'title'})[0]
            title = title.encode('utf-8')
            meta.update({'title': title})
            liz = control.item(label=title)

            link = client.parseDOM(item, 'a', ret='href')[0]
            link = link.encode('utf-8')
            meta.update({'url': link})
            
            try:
                sep = client.parseDOM(item, 'div', attrs={'class': 'watch-message'})
                season, episode = re.findall('(\d+)', sep[0])
            except:
                season = episode = ''
            if not season == '': meta.update({'season': season.encode('utf-8'), 'episode': episode.encode('utf-8')})
                
            try:
                img = client.parseDOM(item, 'img', attrs={'typeof': 'foaf:Image'}, ret='src')[0]
                img = img.encode('utf-8')
            except:
                img = '0'
            if not img == '0': meta.update({'poster': img, 'thumb': img, 'banner': img, 'icon': img})

            try:
                duration = client.parseDOM(item, 'span', attrs={'class': 'hossz'})[0]
                duration = re.search('/span>\s*(\d.*)', duration).group(1)
                duration = duration.split(':')
                if len(duration) == 2: duration = (int(duration[0]) * 60) + int(duration[1])
                elif len(duration) == 3: duration = (int(duration[0]) * 3600) + (int(duration[1]) * 60) + int(duration[2])
            except:
                duration = '0'
            if not duration == '0': meta.update({'duration': str(duration)})

            try:
                plot = client.parseDOM(item, 'div', attrs={'class': 'synopsis'})[0]
                plot = plot.replace('\n','').replace('\r', '').strip()
                if plot == '': raise Exception()
                plot = client.replaceHTMLCodes(plot)
                plot = plot.encode('utf-8')
            except:
                plot = '0'
            if not plot == '0': meta.update({'plot': plot})

            meta.update({'fanart': fanart})

            systitle = urllib.quote_plus(title)
            sysmeta = urllib.quote_plus(json.dumps(meta))
            
            sysurl = '%s?name=%s&url=%s&mode=2&iconimage=%s&fanart=%s&meta=%s' % (sys.argv[0], systitle,  urllib.quote_plus(link), urllib.quote_plus(img), urllib.quote_plus(fanart), sysmeta)

            if 'poster' in meta: art.update({'poster': img, 'thumb': img, 'fanart': img, 'banner': img, 'icon': img})

            liz.setArt(art)
            liz.setProperty('Fanart_Image', fanart)
            liz.setInfo(type='Video', infoLabels = meta)

            control.addItem(handle=syshandle, url=sysurl, listitem=liz, isFolder=False)
        except:
            pass

    try:
        if not videos[1] =='0':
            addDir3('[COLOR green]''Következő oldal''[/COLOR]', url, 1, '', fanart, videos[1])
    except:
        pass

    if 'episode' in meta:
        control.content(syshandle, 'episodes')
        control.execute('Container.SetViewMode(504)')
    else:
        control.content(syshandle, 'movies')


def getEpisodes(url):
    result = requests.get(url).content
    videos = client.parseDOM(result, 'div', attrs={'class': 'card video'})
    try:
        page = client.parseDOM(result, 'li', attrs={'class': 'pager-next first last'})[0]
        page = re.compile('page=([0-9]+)').findall(page)[0]
    except: page = ''
    if page == '': page = '0'
    
    return videos, page


def getvideo():
    try:
        #headers = {'User-Agent': 'Apple-iPhone/701.341'}
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36'}
        xbmc.executebuiltin('ActivateWindow(busydialog)')

        query = urlparse.urljoin(axnplay_url, url)
        result = requests.get(query, headers=headers).content

        try: embed_url = client.parseDOM(result, 'iframe', ret='src')
        except: embed_url = client.parseDOM(result, 'meta', attrs={'name': 'twitter:player'}, ret='content')
        
        embed_url = [i for i in embed_url if 'player.theplatform.com' in i][0]
        
        result = requests.get(embed_url, headers=headers).content
        
        source_url = client.parseDOM(result, 'link', attrs={'rel': 'alternate'}, ret='href')[0]
        result = requests.get(source_url, headers=headers).content
        sources = client.parseDOM(result, 'media:content', ret='url'), client.parseDOM(result, 'media:content', ret='height')
        sources = zip(sources[0],sources[1])
        sources = sorted(sources, key=lambda x: x[1])[::-1]
        
        source = pick_source(sources, auto_pick='true')
        if not source: raise Exception()
        
        source = client.replaceHTMLCodes(source)
        #source = source + '&switch=http&formats=mpeg4&format=SMIL&embedded=true&tracking=true'

        result = requests.get(source, headers=headers).content
            
        direct_url = re.findall('video src\s*=\s*["\']([^"\']+)', result)[0]

        control.idle()

        videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels=meta)
        xbmc.Player().play(direct_url, videoitem)
    except: 
        control.idle()
        return


def pick_source(sources, auto_pick=None):
    if auto_pick is None:
        auto_pick = control.setting('auto_pick') == '0'

    if len(sources) == 1:
        return sources[0][0]
    elif len(sources) > 1:
        if auto_pick:
            return sources[0][0]
        else:
            result = xbmcgui.Dialog().select('Minőség', [source[1] if source[1] else 'Uknown' for source in sources])
            if result == -1:
                return
            else:
                return sources[result][0]


def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        #liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
page=None
meta = {}

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        page=urllib.unquote_plus(params["description"])
except:
        pass
try:
        meta = json.loads(urllib.unquote_plus(params["meta"]))
except:
        pass
    

if mode==None or url==None or len(url)<1:
    shows()
elif mode==1:
    episodes()
elif mode==2:
    getvideo()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
