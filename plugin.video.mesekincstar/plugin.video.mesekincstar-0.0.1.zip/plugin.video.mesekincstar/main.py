# -*- coding: utf-8 -*-
# Author: vargalex <vargagab@gmail.com>
# Created on: 22.04.2017
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, xbmcaddon, xbmcgui, xbmcplugin, os, re, urlresolver
from urllib import urlencode
from urlparse import parse_qs, urlparse
from resources.lib import client, cache, control
from urlresolver.plugins.lib import jsunpack

thisAddon = xbmcaddon.Addon(id='plugin.video.mesekincstar')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')
BASE_URL = "http://mesekincstar.tv/"

mesekincstar_cookie = cache.get(client.request(BASE_URL, output = 'cookie'), 12, BASE_URL, 'cookie')

def build_url(query):
	return base_url + '?' + urlencode(query)

def setViewMode(mode):
	viewMode = 0
	mainView = int(control.setting('mainView'))
	streamView = int(control.setting('streamView'))
	viewModes = [0, 502, 51, 500, 501, 508, 504, 503, 515]

	if mode == 'browse_folder':
		viewMode = viewModes[mainView]
	elif mode == 'movie_folder':
		viewMode = viewModes[streamView]
	if viewMode != 0:
        	xbmc.executebuiltin('Container.SetViewMode(%s)' %viewMode)
	return

def getMainDirectory():

	url = build_url({'mode': 'search', })
	li = xbmcgui.ListItem(u'Keresés', iconImage=MediaDir + '\\search.png')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
		                listitem=li, isFolder=True)

	url = build_url({'mode': 'categories'})
	li = xbmcgui.ListItem(u'Kategóriák')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
		                listitem=li, isFolder=True)

	url = build_url({'mode': 'browse', 'url': BASE_URL})
	li = xbmcgui.ListItem(u'Összes')
	xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
		                listitem=li, isFolder=True)
	setViewMode("browse_folder")
	xbmcplugin.endOfDirectory(addon_handle)
	return

def getCategories():
	url_content = client.request(BASE_URL, cookie=mesekincstar_cookie)
	result = client.parseDOM(url_content, 'div', attrs={'id': 'categories-2'})
	items = client.parseDOM(result, 'li')
	for item in items:
		link = client.parseDOM(item, 'a', ret='href')[0]
		caption = client.parseDOM(item, 'a')[0];
                url = build_url({'mode': 'browse', 'url': link})
                li = xbmcgui.ListItem(caption)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
	result = client.parseDOM(url_content, 'ul', attrs={'class': 'sub-menu'})
	items = client.parseDOM(result, 'li', attrs={'class': 'menu-item menu-item-type-custom menu-item-object-custom menu-item.*?'})
	for item in items:
		link = client.parseDOM(item, 'a', ret='href')[0]
		caption = client.parseDOM(item, 'a')[0];
                url = build_url({'mode': 'browse', 'url': link})
                li = xbmcgui.ListItem(caption)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
	setViewMode("browse_folder")	
	xbmcplugin.endOfDirectory(addon_handle)
	return

def doSearch():
    try:
        control.idle()

        k = control.keyboard('', 'Keresés')
	k.doModal()
        q = k.getText() if k.isConfirmed() else None

        if (q == None or q == ''): return

	getMovies(BASE_URL + "?s=" + q)
	return

    except:
        return

def getMovies(url):
	url_content = client.request(url, cookie=mesekincstar_cookie)
	result = client.parseDOM(url_content, 'div', attrs={'id': 'content_box'})
	items = client.parseDOM(result, 'article')
	for item in items:
		img = client.parseDOM(item, 'img', ret='src')[0]
		h2 = client.parseDOM(item, 'h2')[0];
		
		link = client.parseDOM(h2, 'a', ret='href')[0]
		caption = client.parseDOM(h2, 'a')[0];
		caption = client.replaceHTMLCodes(caption).encode('utf-8')
		span = client.parseDOM(item, 'span', attrs={'class': 'thetime date updated'})[0]
		uploadDate = client.parseDOM(span, 'span')[0]
		uploadDate = client.replaceHTMLCodes(uploadDate).encode('utf-8')
		url2 = build_url({'mode': 'movieinfo', 'url': link})
                li = xbmcgui.ListItem(caption+' - [COLOR blue]' + uploadDate + '[/COLOR]', iconImage=img)
		li.setArt({'icon': img, 'thumb': img, 'poster': img})
		li.setProperty( "Fanart_Image", img )
		li.setInfo( type="Video", infoLabels={ "genre": "mese"} )
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url2,
                                        listitem=li, isFolder=True)
	nextLinkPos = url_content.find('nextLink');
	if nextLinkPos>0:
		nextLink = url_content[nextLinkPos+10:url_content.find(',', nextLinkPos+10)]
		if not nextLink == 'null':
			url2 = build_url({'mode': 'browse', 'url': nextLink[1:-1].replace('\\', '')})
	        	li = xbmcgui.ListItem(u'[COLOR green]>> Következő oldal >>[/COLOR]')
        		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url2,
        	                listitem=li, isFolder=True)
	setViewMode("browse_folder")
	xbmcplugin.endOfDirectory(addon_handle)
	return

def getMovie(url):
	url_content = client.request(url, cookie=mesekincstar_cookie)
	title = client.parseDOM(url_content, 'h1', attrs={'class': 'title single-title entry-title'})[0]
	title = client.replaceHTMLCodes(title)
	div_content = client.parseDOM(url_content, 'div', attrs={'class': 'thecontent clearfix'})[0]
	paragraphs = client.parseDOM(div_content, 'p')
	TAG_RE = re.compile(r'<[^>]+>')
	if len(paragraphs)>1:
		description = TAG_RE.sub('', paragraphs[1])
	else:
		description = TAG_RE.sub('', re.sub('<a.*/a>', '', paragraphs[0]))
	for paragraph in paragraphs:
		imgs = client.parseDOM(paragraph, 'a', ret='href')
		img = ''
		if len(imgs) > 0: 
			img = imgs[0]
			break
	items = client.parseDOM(div_content, 'iframe', ret='src')
	for item in items:
		new_item = re.sub('/preview$', '', item)
		url2 = build_url({'mode': 'play', 'url': new_item})
                li = xbmcgui.ListItem(title + '[COLOR blue] - ' + urlparse(item).netloc + '[/COLOR]')
		if img:
			li.setArt({'icon': img, 'thumb': img, 'poster': img})
		li.setInfo( type="Video", infoLabels={ "title": title, "genre": "mese", "plot": description} )
		if img:
			li.setProperty( "Fanart_Image", img )
		li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url2,
                                        listitem=li, isFolder=False)
	setViewMode("movie_folder")		
	xbmcplugin.endOfDirectory(addon_handle)
	return

def getLejatszoProVideoURL(url):
	#page_content = client.request(url, lejatszopro_cookie)
	page_content = client.request(url)
	js_data = jsunpack.unpack(page_content)
	js_data = js_data[js_data.find('"src":"')+7:js_data.find('"', js_data.find('"src":"')+7)]
	js_data = js_data.replace("\\\\/", "/")
	return js_data

def playVideo(url):
	url = client.replaceHTMLCodes(url).encode('utf-8')
        direct_url = None
	if "http://lejatszo.pro" in url:
		direct_url = getLejatszoProVideoURL(url)
	else:
		direct_url = urlresolver.resolve(url)
	if direct_url == False or direct_url == None: 
		direct_url = url

	#videoitem = xbmcgui.ListItem(label=direct_url, path=direct_url)   
	#videoitem.setInfo(type='Video', infoLabels={'OriginalTitle': url})
	#xbmc.Player().play(direct_url, videoitem)
	play_item = xbmcgui.ListItem(path=direct_url)
	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
	return
                                                           
# Get the plugin url in plugin:// notation.
base_url = sys.argv[0]
# Get the plugin handle as an integer number.
addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'movies')
args = parse_qs(sys.argv[2][1:])

mode = args.get('mode', None)

if mode is None:
	getMainDirectory()
elif mode[0] == 'categories':
	getCategories()
elif mode[0] == 'browse': 
	getMovies(args['url'][0])
elif mode[0] == 'search':
	doSearch()
elif mode[0] == 'movieinfo':
	getMovie(args['url'][0])
elif mode[0] == 'play':
	playVideo(args['url'][0])
