# -*- coding: utf-8 -*-
#
#      Copyright (C) 2017 Mr Dini <mrdini@movieshark.hu>
#      https://movieshark.hu
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import xbmcplugin,xbmcaddon,xbmc,xbmcgui,random

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__userdatadir__ = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__icon__ = __addon__.getAddonInfo('icon')
addon_handle = int(sys.argv[1])

def __main__():
    fireplacevid = __addon__.getSetting("fireplacevid").encode("utf-8")
    vidid = ''
    vids = ['RDfjXj5EGqI', '0fYL_qiDYf0', 'L_LUpnjgPso', 'geDhhWvl1II']
    if __addon__.getSetting("israndom") == 'true':
        vidid = random.choice(vids)
    else:
        if fireplacevid == 'Burning Fireplace with Crackling Fire Sounds (Full HD)':
            vidid = vids[1]
        elif fireplacevid == 'Fireplace 10 hours full HD':
            vidid = vids[2]
        elif fireplacevid == 'Christmas Fireplace Scene with Crackling Fire Sounds (6 hours)':
            vidid = vids[3]
        else:
            vidid = vids[0]

    videoitem = xbmcgui.ListItem(label=fireplacevid)
    xbmc.Player().play('plugin://plugin.video.youtube/?action=play_video&videoid=%s'%(vidid), videoitem)

__main__()

#End! :)