# -*- coding: utf-8 -*-
#
#      Copyright (C) 2017 Mr Dini <mrdini@movieshark.hu>
#      https://movieshark.hu
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

#Buggalo init
import buggalo
buggalo.SUBMIT_URL = 'https://bugs.movieshark.hu/buggalo/submit.php'

try:
    import xbmcplugin,xbmcaddon,xbmc,urllib2,urlparse,xbmcgui,re,json
except Exception:
    buggalo.onExceptionRaised()
    sys.exit(1)
    
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__userdatadir__ = xbmc.translatePath(__addon__.getAddonInfo('profile')).encode("utf-8")
__icon__ = __addon__.getAddonInfo('icon').encode("utf-8")
__fanart__ = __addon__.getAddonInfo('fanart').encode("utf-8")
base_url = 'http://api.mindigtv.appsters.me'

def getpage(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Dalvik/2.1.0 (Linux; U; Android 7.0; Nexus 6P Build/NRD90U)')
    try:
        response = urllib2.urlopen(req)
    except urllib2.HTTPError as e:        
        if e.code != 200:
            select = xbmcgui.Dialog().yesno(__addonname__+' - Hiba','Ajjaj! A szerver [COLOR darkred][B]'+str(e.code)+'[/B][/COLOR]-es hibakóddal válaszolt...[CR]Elképzelhető, hogy éppen karbantartás alatt van. Amennyiben a hiba tartósan fenállna, jelentsd a hibát a \'Jelentem\' gombra kattintva!', None, None, 'Várok vele!', 'Jelentem!')
            if select == 1:
                buggalo.onExceptionRaised()
        sys.exit(1)

    except urllib2.URLError as e:
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%('[MinDigTV]','Hiba az információk letöltése során! Ellenőrizd az internetkapcsolatot!', 5000, __icon__))
        sys.stderr.write('[MinDigTV] Link get failed')
        sys.stderr.write(str(e))
        xbmcgui.Dialog().ok(__addonname__+' - Hiba', 'Hiba történt az információk szerverről való lekérdezése során.[CR]Ezt a hibát legtöbbször a nem stabil vagy hiányzó internetkapcsolat okozza...[CR]További részletek a logban!')
        sys.exit(1)
    
    return(response)

def mainWindow():
    addDirectory('Csatornák', 1, 'https://repo.movieshark.xyz/shared/icons/MinDigTV/tv.png', '', 'MinDigTV ingyenes csatornák', '')
    addDirectory('Rádiók', 2, 'https://repo.movieshark.xyz/shared/icons/MinDigTV/radio.png', '', 'MinDigTV ingyenes rádiók', '')
    addDirectory('Videotéka', 7, 'https://repo.movieshark.xyz/shared/icons/MinDigTV/videoteca.png', '', 'Lemaradtál a kedvenc műsorodról?\nNem probléma! Nézd vissza bármikor a MinDigTV segítségével!', '')
    return

def videotWindow():
    addDirectory('MinDigTV ajánlata', 5, '', '', '', '')
    addDirectory('Csatornák szerinti téka', 8, '', '', '', '')
    return

def streamlinkTransformer(link):
    """
    For older Kodies (<17) we have to manually 'redirect' (correct) the links for the channels
    example: http://redir.cdn.connectmedia.hu/chkhu.connectmedia.hu/6090/4fb3d9a79724924d1cf2e1b476668c73/590352c8/index.m3u8
    """
    if __addon__.getSetting("manredir") == 'true' and bool(re.match('http:\/\/redir\.cdn\.connectmedia\.hu\/chkhu\.connectmedia\.hu\/', link)) is True:
        link = re.sub('http:\/\/redir\.cdn\.connectmedia\.hu\/chkhu', 'http://cdn', link)
    return link

def getChannels():
    items = json.load(getpage('%s/v1/1/hu/content/by_content/Channel.json'%(base_url)))
    titles = []; icons = []; streams = []
    for item in items:
        if item["is_radio"] != True and item["title"] != 'Figyelem' and item["premium"] != True and len(item["streams"]) != 0 and item["has_live"] != False:
            if __addon__.getSetting("showgeoblock") == 'true':
                if item["is_geo_blocked"] == True:
                    titles.append(item["title"].encode("utf-8")+' [COLOR red]Csak belföldi![/COLOR]')
                else:
                    titles.append(item["title"].encode("utf-8"))
            else:
                titles.append(item["title"].encode("utf-8"))
            icons.append(item["header"].encode("utf-8"))
            for stream in item["streams"]:
                if stream["platform"] == 'hls':
                    streams.append(streamlinkTransformer(stream["url"]))
    for x in range(0, len(titles)):
            if streams[x]:
                addFile(titles[x], 3, icons[x], '', '', str(streams[x]).encode("utf-8"))
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    return

def getRadios():
    items = json.load(getpage('%s/v1/1/hu/content/by_content/Channel.json'%(base_url)))
    titles = []; icons = []; streams = []
    for item in items:
        if item["is_radio"] == True and item["title"] != 'Figyelem' and item["premium"] != True and len(item["streams"]) != 0:
            if __addon__.getSetting("showgeoblock") == 'true':
                if item["is_geo_blocked"] == True:
                    titles.append(item["title"].encode("utf-8")+' [COLOR red]Csak belföldi![/COLOR]')
                else:
                    titles.append(item["title"].encode("utf-8"))
            else:
                titles.append(item["title"].encode("utf-8"))
            icons.append(item["header"].encode("utf-8"))
            for stream in item["streams"]:
                if stream["platform"] == 'hls':
                    streams.append(stream["url"])
    for x in range(0,len(titles)):
        addFile(titles[x], 4, icons[x], '', '', str(streams[x]).encode("utf-8"))
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    return

def getVOfferMain():
    jsonobject = json.load(getpage('%s/v1/1/hu/content/by_feature_extended/google.json'%(base_url)))
    titles = []; icons = []; streams = []
    for channel in jsonobject:
        if channel["type"] == 'Package':
            continue
        titles.append(channel["name"].encode("utf-8"))
        icons.append(channel["image"].encode("utf-8"))
    for x in range(0,len(titles)):
        addDirectory(titles[x], 6, icons[x], '', '', x)
    return

def getVOfferElements():
    jsonobject = json.load(getpage('%s/v1/1/hu/content/by_feature_extended/google.json'%(base_url)))[num]["items"]
    titles = []; icons = []; streams = []; descriptions = []
    for channel in jsonobject:
        try:
            if channel["genre"].encode("utf-8") != '':
                titles.append(channel["title"].encode("utf-8")+' [COLOR green]'+channel["genre"].encode("utf-8")+'[/COLOR]')
            else:
                titles.append(channel["title"].encode("utf-8"))
        except KeyError:
            titles.append(channel["title"].encode("utf-8"))
        try:
            descriptions.append(channel["short_lead"].encode("utf-8"))
        except KeyError:
            descriptions.append('')
        icons.append(channel["header"].encode("utf-8"))
        if len(channel["streams"]) is not 0:
            for stream in channel["streams"]:
                if stream["platform"] == 'hls':
                    streams.append(stream["url"])
        else:
            streams.append('http://no-link')
    for x in range(0, len(titles)):
        if streams[x] == 'http://no-link':
            titles[x] += ' - [COLOR red]Nem lejátszható forrás![/COLOR]'
        addFile(titles[x], 3, icons[x], '', descriptions[x], streams[x])
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    return

def getVideotecaMain():
    items = json.load(getpage('%s/v1/1/hu/content/by_content/Channel.json'%(base_url)))
    titles = []; icons = []; ids = []
    for item in items:
        if item["is_radio"] != True and item["title"] != 'Figyelem' and item["premium"] != True and item["has_vods"] != False:
            titles.append(item["title"].encode("utf-8"))
            icons.append(item["header"].encode("utf-8"))
            ids.append(str(item["id"]))
    for x in range(0,len(titles)):
        addDirectory(titles[x], 9, icons[x], '', '', ids[x])
    return

def getVideotecaElements():
    items = json.load(getpage('%s/v1/1/hu/content/vods_by_channel/%s.json'%(base_url, num)))["data"]["vods"][str(num)]
    titles = []; icons = []; descriptions = []; streams = []
    for item in items:
        if len(item["streams"]) != 0:
            try:
                if item["genre"].encode("utf-8") != '':
                    titles.append(item["title"].encode("utf-8")+' [COLOR green]'+item["genre"].encode("utf-8")+'[/COLOR]')
                else:
                    titles.append(item["title"].encode("utf-8"))
            except KeyError:
                titles.append(item["title"].encode("utf-8"))
            if item["header"] == "":
                icons.append(__icon__)
            else:
                icons.append(item["header"].encode("utf-8"))
            try:
                descriptions.append(item["short_lead"].encode("utf-8"))
            except:
                pass
            for stream in item["streams"]:
                if stream["platform"] == 'hls':
                    streams.append(stream["url"])
    for x in range(0,len(titles)):
        addFile(titles[x], 3, icons[x], '', descriptions[x], streams[x])
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    return

def playVideo():
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimg)
    videoitem.setInfo(type='Video', infoLabels={'Title': name, "Plot": description })
    xbmc.Player().play(url+'|User-Agent='+urllib2.quote('Dalvik/2.1.0 (Linux; U; Android 7.0; Nexus 6P Build/NRD90U)'), videoitem)
    return

def playRadio():
    links = getpage(url).read().split('\n')
    mp = ''
    for link in links:
        if len(link.split('.mp3')) == 2:
            mp = re.sub("\s",'',link)
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimg)
    videoitem.setInfo('songs', infoLabels={'Title': name })
    xbmc.Player().play(mp, videoitem)
    return

def addDirectory(name, mode, iconimg, fanart, description, num):
    url = sys.argv[0]+"?mode="+str(mode)+"&name="+urllib2.quote(name)+"&iconimg="+"&description="+urllib2.quote(description)
    if num is not None:
        url += "&num="+urllib2.quote(str(num))
    li = xbmcgui.ListItem(name, iconImage=iconimg, thumbnailImage=iconimg)
    li.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    li.setProperty( "Fanart_Image", __fanart__ )
    try:
        li.setContentLookup(False)
    except:
        pass
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
    return

def addFile(name, mode, iconimg, fanart, description, url):
    ur = sys.argv[0]+"?url="+urllib2.quote(url)+"&mode="+str(mode)+"&name="+urllib2.quote(name)+"&iconimg="+urllib2.quote(iconimg)+"&description="+urllib2.quote(description)
    li = xbmcgui.ListItem(name, iconImage=iconimg, thumbnailImage=iconimg)
    li.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    try:
        li.setProperty('IsPlayable', 'false')
        li.setContentLookup(False)
    except:
        pass
    cms = []
    cms.append(('Frissítés', 'XBMC.Container.Refresh()' ))
    li.addContextMenuItems(cms)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=ur, listitem=li, isFolder=False)
    return

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
mode = None
iconimg = None
fanart = None
name = None
description = None
url = None
num = None

try:
    mode = int(params["mode"])
except:
    pass
try:
    iconimg = params["iconimg"]
except:
    pass
try:
    name = params["name"]
except:
    pass
try:
    fanart = params["fanart"]
except:
    pass
try:
    description = params["description"]
except:
    pass
try:
    url = params["url"]
except:
    pass
try:
    num = int(params["num"])
except:
    pass
try:
    if mode == None:
        mainWindow()
    elif mode == 1:
        getChannels()
    elif mode == 2:
        getRadios()
    elif mode == 3:
        playVideo()
    elif mode == 4:
        playRadio()
    elif mode == 5:
        getVOfferMain()
    elif mode == 6:
        getVOfferElements()
    elif mode == 7:
        videotWindow()
    elif mode == 8:
        getVideotecaMain()
    elif mode == 9:
        getVideotecaElements()
except Exception:
    buggalo.onExceptionRaised()
    sys.exit(1)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
# End! :)
