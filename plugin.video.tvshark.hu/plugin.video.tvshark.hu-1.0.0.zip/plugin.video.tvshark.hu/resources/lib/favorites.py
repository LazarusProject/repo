try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

from resources.lib import control
import json

def getFavorites():
    try:
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM favorite")
        items = dbcur.fetchall()
        items = [eval(i[1]) for i in items]
    except:
        items = []

    return items


def addFavorite(item):
    try:
        item = json.loads(item)
        id = item['data_id']
        title = item['title']

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorite (""id TEXT, ""items TEXT, ""UNIQUE(id)"");")
        dbcur.execute("DELETE FROM favorite WHERE id = '%s'" %  id)
        dbcur.execute("INSERT INTO favorite Values (?, ?)", (id, repr(item).decode('utf-8')))
        dbcon.commit()

        control.infoDialog('Kedvencekhez adva', heading=title)
    except:
        return


def deleteFavorite(item):
    try:
        item = json.loads(item)
        id = item['data_id']
        try:
            dbcon = database.connect(control.favoritesFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM favorite WHERE id = '%s'" % id)
            dbcon.commit()
        except:
            pass

        control.refresh()
    except:
        return