# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys

from resources.lib import control
from resources.lib import directory


class navigator:
    def root(self):    
        self.list = [
        {
        'title': 'Kiemelt',
        'action': '=featured',
        'icon': 'featured.png'
        },
                     
        {
        'title': 'Legfrissebb',
        'action': '=new',
        'icon': 'new.png'
        },
        {
        'title': 'ABC Sorrendben',
        'action': 'cat_abc',
        'icon': 'abc.png'
        },
        {
        'title': u'Legn\u00E9zettebb',
        'action': '=view',
        'icon': 'watching.png'
        },
        {
        'title': 'Felkapott',
        'action': '=view_weekly',
        'icon': 'popular.png'
        },
        {'title': 'Kedvencek',
        'action': 'get_favorites',
        'icon': 'favourites.png'
        },
        {
        'title': u'Keres\u00E9s',
        'action': 'search',
        'icon': 'search.png'
        },
        {
        'title': u'Eszk\u00F6z\u00F6k',
        'action': 'toolNavigator',
        'icon': 'tools.png'
        }
        ]

        directory.add(self.list, content='addons')


    def cat_ABC(self):
        import string
        self.list = [{'title': '0-9'}] + [{'title': i} for i in list(string.uppercase)]
        for i in self.list: i.update({'action': 'ABC', 'icon': 'abc.png'})

        directory.add(self.list, content='addons')


    def tools(self):
        self.list = [
        {
        'title': u'N\u00E9zet',
        'action': 'viewsNavigator',
        'icon': 'tools.png'
        },
        {
        'title': u'Be\u00E1ll\u00EDt\u00E1sok',
        'action': 'openSettings',
        'icon': 'tools.png'
        },
        {
        'title': u'Gyors\u00EDt\u00F3t\u00E1r megtiszt\u00EDt\u00E1sa...',
        'action': 'clearCache',
        'icon': 'tools.png'
        }
        ]

        directory.add(self.list, content='addons')


    def views(self):
        try:
            control.idle()

            items = [ ('Sorozatok', 'tvshows'), (u'\u00C9vadok', 'seasons'), (u'Epiz\u00F3dok', 'episodes') ]

            select = control.selectDialog([i[0] for i in items], u'[B]TV Shark[/B] : N\u00E9zet')

            if select == -1: return

            content = items[select][1]

            title = u'A N\u00C9ZET MENT\u00C9S\u00C9HEZ KATTINTS IDE'
            url = '%s?action=addView&content=%s' % (sys.argv[0], content)

            poster, fanart = control.addonIcon(), control.addonFanart()

            item = control.item(label=title)
            item.setInfo(type='Video', infoLabels = {'title': title})
            item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': poster})
            item.setProperty('Fanart_Image', fanart)

            control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)
            control.content(int(sys.argv[1]), content)
            control.directory(int(sys.argv[1]), cacheToDisc=True)

            from resources.lib import views
            views.setView(content, {})
        except:
            return


    def clearCache(self):
        control.idle()
        yes = control.yesnoDialog('Biztos benne?', '', '')
        if not yes: return
        from resources.lib import cache
        cache.clear()
        control.infoDialog(u'Folyamat befejez\u0151d\u00F6tt', sound=True, icon='INFO')

