try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

from resources.lib import control


def getFavorites():
    try:
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM favorite")
        items = dbcur.fetchall()
        items = [eval(i[1])['data_id'] for i in items]
    except:
        items = []

    return items


def addFavorite(title, data_id):
    try:
        item = {'title': title, 'data_id': data_id}

        control.makeFile(control.dataPath)
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorite (""id TEXT, ""items TEXT, ""UNIQUE(id)"");")
        dbcur.execute("DELETE FROM favorite WHERE id = '%s'" %  data_id)
        dbcur.execute("INSERT INTO favorite Values (?, ?)", (data_id, repr(item).decode('utf-8')))
        dbcon.commit()

        control.infoDialog('Kedvencekhez adva', heading=title)
        control.refresh()
    except:
        return


def deleteFavorite(data_id):
    try:
        try:
            dbcon = database.connect(control.favoritesFile)
            dbcur = dbcon.cursor()
            dbcur.execute("DELETE FROM favorite WHERE id = '%s'" % data_id)
            dbcon.commit()
        except:
            pass

        control.refresh()
    except:
        return