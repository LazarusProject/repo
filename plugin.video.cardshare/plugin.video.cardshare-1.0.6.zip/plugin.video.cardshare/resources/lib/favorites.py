from time import sleep
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

import json

from resources.lib import control


def getFavorites():
    try:
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM favorite")
        items = dbcur.fetchall()
        items = [(i[0].encode('utf-8'), eval(i[1].encode('utf-8'))) for i in items]
    except:
        items = []

    return items


def addFavorite(channel, country):
    try:
        item = dict()
        id = (channel + country).encode('base64')

        if channel: item['channel'] = channel
        if country: item['country'] = country
        
        control.makeFile(control.dataPath)
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("CREATE TABLE IF NOT EXISTS favorite (""id TEXT, ""items TEXT, ""UNIQUE(id)"");")
        dbcur.execute("DELETE FROM favorite WHERE id = '%s'" %  id)
        dbcur.execute("INSERT INTO favorite Values (?, ?)", (id, repr(item)))
        dbcon.commit()

        control.infoDialog(u'Hozz\u00E1adva a kedvencekhez', heading=channel + ' ' + country)
    except:
        return


def deleteFavorite(id):
    try:
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM favorite WHERE id = '%s'" % id)
        dbcon.commit()

        control.refresh()
    except:
        return


def clearFavorites():
    try:
        dbcon = database.connect(control.favoritesFile)
        dbcur = dbcon.cursor()
    
        dbcur.execute("DROP TABLE IF EXISTS favorite")
        dbcur.execute("VACUUM")
        dbcon.commit()
    except:
        pass