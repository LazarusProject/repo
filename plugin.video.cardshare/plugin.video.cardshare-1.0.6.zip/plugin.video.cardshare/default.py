# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, sys, os
from resources.lib import control
from resources.lib import favorites


REMOTE_DBG = False


# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


m3u_file = control.setting('m3u.file')

if m3u_file == '':
    control.okDialog(u'Add meg a csatornalista el\u00E9r\u00E9si \u00FAtvonal\u00E1t!', '', '')
    control.openSettings()
    sys.exit()


def getFolders():  
    try:
        artPath = control.artPath()

        addDir('Csatornalista', '', 6, os.path.join(artPath, 'channels.png'), '', '')
        addDir('Kedvencek', '', 3, os.path.join(artPath, 'favorite.png'), '', '')
        addDir('Keresés', '', 5, os.path.join(artPath, 'search.png'), '', '')
    except:
        return


def getChannels():
    try:
        list = m3u2list('1')

        if len(list) == 0: raise Exception()
        for country in list:
            try:
                addDir(country, country, 1, '', '', '')
            except:
                pass
    except:
        control.infoDialog(u'Csatornalista nem el\u00E9rhet\u0151!')
        return


def getPlaylist():
    try:
        list = m3u2list('2', name)
        
        if len(list) == 0: raise Exception()
        for channel, url, country in list:
            try:
                addFile(channel, url, 2, '', '', country + '+')
            except:
                pass
    except:
        control.infoDialog(u'Csatornalista nem el\u00E9rhet\u0151!')
        return


def search():
    try:
        search_text = ''
        keyb = xbmc.Keyboard('',u'Keres\u00E9s')
        keyb.doModal()
 
        if (keyb.isConfirmed()):
            search_text = keyb.getText()

        if search_text == '': raise Exception()
        list = m3u2list('4', search_text)
        
        if len(list) == 0:
            control.infoDialog(u'Nincs tal\u00E1lat'); raise Exception

        for channel, url, country in list:
            try:
                addFile(channel, url, 2, '', '', country + '+')
            except:
                pass
    except:
        return


def getFav():
    try:
        channels = favorites.getFavorites()
        
        if len(channels) == 0: raise Exception()
        for i in channels:
            try:
                url = m3u2list('3', i[1]['country'], i[1]['channel'])
                addFile('%s %s' % (i[1]['channel'], i[1]['country']), url[0], 2, '', '', i[0])
            except:
                pass
    except:
        return


def handleFav():
    try:
        if description.endswith('+'):
            favorites.addFavorite(name, description.replace('+', ''))
        
        else:
            favorites.deleteFavorite(description)
    except:
        return


def m3u2list(action, loc='', chan=''):
    try:
        list = []

        f = control.openFile(m3u_file)
        m3u = f.read()
        f.close()
        if not 'EXTINF' in m3u: raise Exception()
        li = []

        matches = m3u.split('#EXTINF')
        for i in matches:
            try:
                i = i.replace('\r', '').replace('\n', '')
                country, display_name, url = re.findall('group-title="([^"]+).+?,(.+?)\s*(http.*)', i)[0]
                try: display_name = display_name.encode('utf-8')
                except: pass
                try: country = country.encode('utf-8')
                except: pass
                    
                item_data = {"display_name": display_name.strip(), "country": country.strip(), "url": url}
                li.append(item_data)
            except:
                pass

        if action == '1':
            list += [i['country'] for i in li]
            filter = []
            [filter.append(x) for x in list if x not in filter]
            list = filter
        
        elif action == '2':
            list += [(i['display_name'], i['url'], i['country']) for i in li if loc == i['country']]
        
        elif action == '3':
            list = [i['url'] for i in li if loc == i['country'] and chan == i['display_name']]
        
        elif action == '4':
            list += [(i['display_name'], i['url'], i['country']) for i in li if loc.lower() in i['display_name'].lower()]
        return list
    except:
        return list


def getVideo():
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)   
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)


def addDir(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    if 'mode' in params and params['mode'] == '5':
        title = '%s %s' % (name, description.replace('+', ''))
    else:
        title = name
    liz=xbmcgui.ListItem(title, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": title, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    cm = []
    if description.endswith('+'):
        cm.append((u'Hozz\u00E1ad\u00E1s CS kedvencekhez', 'RunPlugin(%s?mode=4&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))
    elif description.endswith('\n'):
        cm.append((u'Elt\u00E1vol\u00EDt\u00E1s CS kedvencekb\u0151l', 'RunPlugin(%s?mode=4&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))
    if not len(cm) == 0:
        liz.addContextMenuItems(cm, replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass


if mode==None:
    getFolders()
elif mode==1:
    getPlaylist()
elif mode==2:
    getVideo()
elif mode==3:
    getFav()
elif mode==4:
    handleFav()
elif mode==5:
    search()
elif mode==6:
    getChannels()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
