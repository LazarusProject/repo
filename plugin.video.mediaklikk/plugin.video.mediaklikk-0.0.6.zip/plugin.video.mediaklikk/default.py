# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, xbmcaddon, os, time

thisAddon = xbmcaddon.Addon(id='plugin.video.mediaklikk')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media'))
from resources.lib import client

mklikk_url = 'http://www.mediaklikk.hu/'
ajax_url = 'http://nava.hu/wp-admin/admin-ajax.php'

def main_folders():    
    addDir('ÉLŐ', '', 5, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', '', '')
    addDir('TV műsorok A-Z', mklikk_url + 'musor-a-z/', 1, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', 'Tv', '')
    addDir('Rádió műsorok A-Z', mklikk_url + 'musor-a-z/', 1, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', 'Rádió', '')
    addDir('NAVA', '', 15, MediaDir + '\\nava_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', '', '')
    return

def nava_folders():
    addDir('NAVA Kereső', '', 12, iconimage, fanart, '', '')
    addDir('Műsorok Csatorna szerint', '', 16, iconimage, fanart, '', '')
    addDir('Műsorok Műfaj szerint', '', 17, iconimage, fanart, '', '')

def nava_csat():
    addDir('M1', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:101)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('M2', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:102)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('DUNA TV', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:105)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('M3 Anno', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:142)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('Kossuth Rádió', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:120)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('Bartók Rádió', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:118)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)

def nava_mufaj():
    addDir('Mese, Animáció', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:mese%20OR%20genre:anim%C3%A1ci%C3%B3%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Tudományos, Ismeretterjesztő', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:tudom%C3%A1nyos%20OR%20genre:ismeretterjeszt%C5%91%20OR%20genre:%22ismeretterjeszt%C5%91/oktat%C3%B3%22%20OR%20genre:port%C3%A9%20OR%20genre:dokumentum%20OR%20genre:%22kultur%C3%A1lis/m%C5%B1v%C3%A9szeti%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Sport', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:sportmagazin%20OR%20sportk%C3%B6zvet%C3%ADt%C3%A9s%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Kultúra, Szórakozás', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:sz%C3%ADnh%C3%A1z%20OR%20genre:t%C3%A1nc%20OR%20genre:bulv%C3%A1r%20OR%20genre:variet%C3%A9%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Hírműsor', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:h%C3%ADrm%C5%B1sor%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Film, Tévésorozat', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A142+OR+collection%3A101+OR+collection%3A105+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:film%20OR%20genre:%22tv-sorozat%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Közszolgálati, Háttérműsor', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:besz%C3%A9lget%C3%A9s%20OR%20genre:interj%C3%BA%20OR%20genre:vita%20OR%20genre:%22inform%C3%A1ci%C3%B3s%20magazin%22%20OR%20genre:%22h%C3%A1tt%C3%A9r-%20%C3%A9s%20k%C3%B6z%C3%A9leti%20m%C5%B1sor%22%20OR%20genre:%22heti%20h%C3%ADr%C3%B6sszefoglal%C3%B3%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Vallási, Esélyegyenlőségi', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:%22vall%C3%A1si%20m%C5%B1sor%22%20OR%20genre:es%C3%A9lyegyenl%C5%91s%C3%A9gi%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Szabadidő, Életmód', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:%22szabadid%C5%91/%C3%A9letm%C3%B3d%22%20OR%20genre:%22szolg%C3%A1ltat%C3%B3%20m%C5%B1sor%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Regionális, Nemzetiségi', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28*%29+AND+%28genre%3A%22nemzetis%C3%A9gi+%2F+kisebbs%C3%A9gi+m%C5%B1sor%22+OR+genre%3A%22hat%C3%A1ront%C3%BAli+m%C5%B1sor%22+OR+genre%3A%22region%C3%A1lis+m%C5%B1sor%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)

def live_folders():
    addDir('TV', '', 6, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', 'Tv', '')
    addDir('Rádió', '', 8, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', 'Rádió', '')

def musor_lista():
    r = client.source(url)
    m = re.compile(mklikk_url + 'musor/(.+?)" class="' + description + '".+?li>(.+?)<').findall(r)
    for musor_link, musor_cim in m:
        addDir(musor_cim, mklikk_url + 'musor/' + musor_link, 2, iconimage, fanart, description, '')
    return

def epizod_lista():
    mediatar = client.source(mklikk_url + 'mediatar/')
    m = re.compile('Program\(([0-9]+),([0-9]+)\)">' + name).findall(mediatar)
    for prog, pr_id in m:
        post = {'prog': prog, 'chr': '', 'pr_id' : pr_id, 'content_type' : '-1', 'category' : '', 'age' : '', 'dateFilter' : '', 'listType' : '0'}
        post = urllib.urlencode(post)
        r = client.source(mklikk_url + 'mediatar/', post = post)

    if description == 'Tv':
        m = re.compile(mklikk_url + 'video/(.+?)".+?\n.+?\n.+?\n.+?src="(.+?)".+?\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?\n.+?[\s]+(.+?)\s\s').findall(r)
        for url2, img, date in m:
            addFile(name + ' - ' + date, mklikk_url + 'video/' + url2, 3, img, fanart, description)
        nava = re.compile('http://nava.hu/(.+?)&sort').findall(r)
        if nava:
            addDir('[COLOR green]' + name + ' - ' + 'Korábbi adások itt: www.nava.hu' '[/COLOR]', 'http://nava.hu/' + nava[0] + '%20AND%20freeToAccess_technical:true&sort=datem&simple=&start=', 10, iconimage, fanart, name, 0)   
    elif description == 'Rádió':
        m = re.compile('date="(.+?)".+?from=(.+?)&').findall(r)    
        for date, url2 in m:
            addFile(name + ' ' + '-' + ' ' + date, 'http://stream001.radio.hu:443/stream/' + url2, 14, iconimage, fanart, description)
        nava = re.compile('http://nava.hu/(.+?)&sort').findall(r)
        if nava:
            addDir('[COLOR green]' + name + ' - ' + 'Korábbi adások itt: www.nava.hu' '[/COLOR]', 'http://nava.hu/' + nava[0] + '%20AND%20freeToAccess_technical:true&sort=datem&simple=&start=', 10, iconimage, fanart, name, 0)
    return
 
def nava_list():
    r = client.source(url + '&start=' + str(page))
    r = r.replace('</b>', '')
    i = re.compile('facet-text.+?; (.+?)<a href="(.+?)"').findall(r)
    for a, b in i:
        addDir(a, b, 19, iconimage, fanart, '', '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 18, iconimage, fanart, '', page + 32)

def nava_musor():
    r = client.source(url + '&simple=&sort=datem&start=' + str(page))
    m = re.compile('/id/(.+?)/.+?strong>(.+?)<.+?tion">(.+?)<.+?date">(.+?)<').findall(r)
    for nava_id, title, ch, date in m:
        addFile(title + ' - ' + ch + ' ' + date, nava_id, 11, iconimage, fanart, '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 19, iconimage, fanart, '', page + 24)
    
def nava_episodes():
    r = client.source(url + str(page))
    m = re.compile('nava.hu/id/(.+?)/.+?date">(.+?)<').findall(r)
    for nava_id, title in m:
        addFile(description + ' ' + '-' + ' ' + title, nava_id, 11, iconimage, fanart, '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 10, iconimage, fanart, description, page + 24)
    return

def nava_search(search_text, page):
    search_url = 'http://nava.hu/kereses-eredmenye/?sc2=1&sc4=1&search=' + search_text + '&simple&start=' + str(page)
    r = client.source(search_url)
    m = re.compile('/id/(.+?)/.+?strong>(.+?)<.+?tion">(.+?)<.+?date">(.+?)<').findall(r)
    for nava_id, title, ch, date in m:
        addFile(title + ' - ' + ch + ' ' + date, nava_id, 11, iconimage, fanart, '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', '', 13, iconimage, fanart, search_text, page + 24)
    return

def live_tv():
    r = client.source(mklikk_url)
    m = re.compile('"><a href.+?([a-z0-9-]+-elo)').findall(r)
    for url2 in m:
        title = url2.replace('-elo','').replace('-',' ')
        addFile(title.upper(), url2, 7, MediaDir + '\\' + title.upper() + '.png', fanart, '')
    return

def live_radio():
    addFile('Kossuth Rádió', 'kossuth-radio-elo/', 9, MediaDir + '\\Kossuth.png', fanart, '')
    addFile('Petőfi Rádió', 'petofi-radio-elo', 9, MediaDir + '\\Petofi.png', fanart, '')
    addFile('Bartók Rádió', 'bartok-radio-elo/', 9, MediaDir + '\\Bartok.png', fanart, '')
    addFile('Dankó Rádió', 'danko-radio-elo', 9, MediaDir + '\\Danko.png', fanart, '')
    addFile('Nemzetiségi Rádió', 'nemzetisegi-adasok-elo/', 9, MediaDir + '\\Nemzetisegi.png', fanart, '')
    addFile('Parlamenti Rádió', 'parlamenti-adasok-elo', 9, MediaDir + '\\Parlamenti.png', fanart, '')
    addFile('Duna World Rádió', 'duna-world-radio-elo/', 9, MediaDir + '\\DUNA WORLD.png', fanart, '')

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('' , 'Keresés')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()
        nava_search(search_text, 0)
        return

########## 

def play_url(url, iconimage, name):
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)
    
def get_Tv():
    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    r = client.source(url)
    token = re.compile('token="(.+?)"').findall(r)
    m = client.source('http://player.mediaklikk.hu/player/player-external-vod-full.php?token=' + token[0])
    direct_url = re.compile("file: '(.+?)'").findall(m)
    chunk_list = client.source(direct_url[0])
    chunk_list = chunk_list.replace('\n', '')
    chunk_list = re.compile('BANDWIDTH=([0-9]+)(.+?m3u8)').findall(chunk_list)
    if len(chunk_list) == 0: direct_url = direct_url[0]
    else:
        chunk_list = [(int(i[0]), i[1]) for i in chunk_list]
        chunk_list = sorted(chunk_list, reverse=True)
        q_list = [str(i[0]) for i in chunk_list]
        q_list = [q.replace('3000000', '720p').replace('1600000', '480p').replace('1200000', '360p').replace('800000', '290p').replace('400000', '180p') for q in q_list]
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        dialog = xbmcgui.Dialog()
        q = dialog.select('Minőség', q_list)
        if q == -1: return
        direct_url = direct_url[0].split('playlist')[0] + chunk_list[q][1]
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    if direct_url:
        play_url(direct_url, iconimage, name)
    return  
    
def get_liveTv():
    q_list = ['720p','480p','360p','270p','180p']
    url_list=['VID_1280x720_HUN','VID_854x480_HUN','VID_640x360_HUN','VID_480x270_HUN','VID_320x180_HUN']
    r = client.source(mklikk_url + url)
    m = re.compile('player-inside.js(.+?)"').findall(r)
    r = client.source('http://player.mediaklikk.hu/player/player-inside-full2.php' + m[0])
    direct_url = re.compile("file: '(.+?)index").findall(r)
    dialog = xbmcgui.Dialog()
    q = dialog.select('Minőség', q_list)
    if q == -1: return
    direct_url = direct_url[0] + url_list[q] + '.m3u8'
    if direct_url:
        play_url(direct_url, iconimage, name)
    return   
   
def get_liveRadio():
    r = client.source(mklikk_url + url)
    direct_url = re.compile("url.+?'(.+?.mp3)'").findall(r)
    if direct_url:
        play_url(direct_url[0], iconimage, name)
    return   

def get_nava(url):    
    post = {'action': 'nava_object_ajax_action', 'param': '10', 'id' : url, 'act' : '1'}
    post = urllib.urlencode(post)
    i = client.source(ajax_url, post = post)
    
    if "ON_TAPE" in i:
        dialog = xbmcgui.Dialog()
        m = dialog.yesno("Videó visszatöltése", "A kért média jelenleg nem online állapotú. Kéri a visszatöltését?")

        if m == 1:
            post = {'action': 'nava_object_ajax_action', 'param': '10', 'id' : url, 'act' : '2'}
            post = urllib.urlencode(post)
            i = client.source(ajax_url, post = post)
            get_nava(url)
        else:
            return
    elif "IN_QUEUE" in i or "IS_RECALLING" in i:
        progress = xbmcgui.DialogProgress()
        progress.create("Videó visszatöltése", "'" + name + "'" + " - " + "visszatöltése elindult.", "Kérem várjon...")       
        time.sleep(5)
        if progress.iscanceled():
            progress.close()
            return
        get_nava(url)
        
    elif "ON_DISK" in i:
        post = {'action':'nava_object_ajax_action', 'param':'1', 'id':url, 'pos':'00:00:00', 'prev':'', 'virtual':'false'}
        post = urllib.urlencode(post)
        r = client.source(ajax_url, post = post)
        direct_url = re.compile('file.+?"(.+?m3u8)').findall(r)[0]
        play_url(direct_url, iconimage, name)
    
    else:
        dialog.ok("HIBA!", "A kért média nem elérhető!")
        return 

##########

def addDir(name, url, mode, iconimage, fanart, description, page):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def getKey(item):
    return item[0]

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = ''
page = 0
search_text = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    search_text = urllib.unquote_plus(params["description"])
except:
    pass

if mode==None:
    main_folders()
elif mode==1:
    musor_lista()
elif mode==2:
    epizod_lista()
elif mode==3:
    get_Tv()
elif mode==5:
    live_folders()
elif mode==6:
    live_tv()
elif mode==7:
    get_liveTv()
elif mode==8:
    live_radio()
elif mode==9:
    get_liveRadio()
elif mode==10:
    nava_episodes()
elif mode==11:
    get_nava(url)
elif mode==12:
    open_search_panel()
elif mode==13:
    nava_search(search_text, page)
elif mode==14:
    play_url(url, iconimage, name)
elif mode==15:
    nava_folders()
elif mode==16:
    nava_csat()
elif mode==17:
    nava_mufaj()
elif mode==18:
    nava_list()
elif mode==19:
    nava_musor()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
