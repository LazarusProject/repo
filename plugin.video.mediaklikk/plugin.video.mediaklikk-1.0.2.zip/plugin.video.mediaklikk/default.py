# -*- coding: utf-8 -*-
import xbmc, xbmcgui, urllib, re, xbmcplugin, xbmcaddon, os, time, datetime, json
from resources.lib import client, control, epglist


REMOTE_DBG = False


# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


thisAddon = xbmcaddon.Addon(id='plugin.video.mediaklikk')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media'))

mklikk_url = 'http://www.mediaklikk.hu/'
ajax_url = 'http://nava.hu/wp-admin/admin-ajax.php'
gmt_offset = int(control.setting('gmt.offset'))

def main_folders():
    addDir('ÉLŐ', '', 5, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', '', '')
    addDir('TV műsorok A-Z', 'http://www.mediaklikk.hu/mediatar/', 1, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', 'Tv', '')
    addDir('Rádió műsorok A-Z', 'http://www.mediaklikk.hu/mediatar/', 1, 'http://www.mediaklikk.hu/wp-content/uploads/sites/4/2013/11/mediaklikk_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', 'Rádió', '')
    addDir('NAVA', '', 15, MediaDir + '\\nava_logo.png', 'http://mediaklikk.cms.mtv.hu/file/sites/4/2013/12/body_bg_kozmedia_mediatar.jpg', '', '')
    return

def nava_folders():
    addDir('NAVA Kereső', '', 12, iconimage, fanart, '', '')
    addDir('Műsorok Csatorna szerint', '', 16, iconimage, fanart, '', '')
    addDir('Műsorok Műfaj szerint', '', 17, iconimage, fanart, '', '')

def nava_csat():
    addDir('M1', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:101)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('M2', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:102)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('DUNA TV', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:105)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('M3 Anno', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:142)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('Kossuth Rádió', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:120)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)
    addDir('Bartók Rádió', 'http://nava.hu/kereses-eredmenye/?advanced=&q=(collection:118)&fq=(type:document)AND(freeToAccess_technical:true)AND(collectable_technical:true)AND(hasVideo_technical:true)&kgy=&facet', 18, iconimage, fanart, '', 0)

def nava_mufaj():
    addDir('Mese, Animáció', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:mese%20OR%20genre:anim%C3%A1ci%C3%B3%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Tudományos, Ismeretterjesztő', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:tudom%C3%A1nyos%20OR%20genre:ismeretterjeszt%C5%91%20OR%20genre:%22ismeretterjeszt%C5%91/oktat%C3%B3%22%20OR%20genre:port%C3%A9%20OR%20genre:dokumentum%20OR%20genre:%22kultur%C3%A1lis/m%C5%B1v%C3%A9szeti%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Sport', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:sportmagazin%20OR%20sportk%C3%B6zvet%C3%ADt%C3%A9s%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Kultúra, Szórakozás', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:sz%C3%ADnh%C3%A1z%20OR%20genre:t%C3%A1nc%20OR%20genre:bulv%C3%A1r%20OR%20genre:variet%C3%A9%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Hírműsor', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:h%C3%ADrm%C5%B1sor%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Film, Tévésorozat', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A142+OR+collection%3A101+OR+collection%3A105+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:film%20OR%20genre:%22tv-sorozat%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Közszolgálati, Háttérműsor', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:besz%C3%A9lget%C3%A9s%20OR%20genre:interj%C3%BA%20OR%20genre:vita%20OR%20genre:%22inform%C3%A1ci%C3%B3s%20magazin%22%20OR%20genre:%22h%C3%A1tt%C3%A9r-%20%C3%A9s%20k%C3%B6z%C3%A9leti%20m%C5%B1sor%22%20OR%20genre:%22heti%20h%C3%ADr%C3%B6sszefoglal%C3%B3%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Vallási, Esélyegyenlőségi', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:%22vall%C3%A1si%20m%C5%B1sor%22%20OR%20genre:es%C3%A9lyegyenl%C5%91s%C3%A9gi%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Szabadidő, Életmód', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28collection%3A101+OR+collection%3A105+OR+collection%3A102%29+AND+%28genre:%22szabadid%C5%91/%C3%A9letm%C3%B3d%22%20OR%20genre:%22szolg%C3%A1ltat%C3%B3%20m%C5%B1sor%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)
    addDir('Regionális, Nemzetiségi', 'http://nava.hu/kereses-eredmenye/?advanced=&q=%28*%29+AND+%28genre%3A%22nemzetis%C3%A9gi+%2F+kisebbs%C3%A9gi+m%C5%B1sor%22+OR+genre%3A%22hat%C3%A1ront%C3%BAli+m%C5%B1sor%22+OR+genre%3A%22region%C3%A1lis+m%C5%B1sor%22%29&fq=%28collectable_technical%3Atrue%29+AND+%28hasVideo_technical%3Atrue%29+AND+%28freeToAccess_technical%3Atrue%29&facet', 18, iconimage, fanart, '', 0)

def live_folders():
    addDir('TV', '', 6, iconimage, fanart, 'Tv', '')
    addDir('Rádió', '', 8, iconimage, fanart, 'Rádió', '')

def musor_lista():
    radio_list = ['ks', 'pf', 'br', 'dk', 'nm', 'pm']
    tv_list = ['m1', 'm2', 'm4', 'dn', 'dw']
    if description == 'Tv': chan_list = tv_list
    else:
        chan_list = radio_list
    r = client.source(url)
    m = re.compile('\{"Id":([0-9]+),"Channel":"(.+?)","Title":"(.+?)"').findall(r)
    for id, chan, title in m:
        if chan in chan_list:
            addDir(title.decode('unicode-escape').encode('utf-8'), id, 2, iconimage, fanart, description, '')
    return

def epizod_lista():
    if description == 'Tv':
        r = client.source('http://www.mediaklikk.hu/wp-content/plugins/hms-mediaklikk/interfaces/mediaStoreData.php?action=videos&id=' + url)
        m = json.loads(r)['Items']
        for i in m:
            name = i['Date'] + ' - ' + i['Title']
            addFile(name.encode('utf-8'), i['Token'], 3, i['Image'], fanart, description)  
    elif description == 'Rádió':
        r = client.source('http://www.mediaklikk.hu/wp-content/plugins/hms-mediaklikk/interfaces/mediaStoreData.php?action=audios&id=' + url + '&page=0&count=100')
        m = re.compile('BeginDate":"(.+?)".+?from=(.+?)&').findall(r)
        for date, file in m:
            addFile(name + ' - ' + date, 'http://stream001.radio.hu:443/stream/' + file, 14, iconimage, fanart, description)
    return

def nava_list():
    r = client.source(url + '&start=' + str(page))
    r = r.replace('</b>', '')
    i = re.compile('facet-text.+?; (.+?)<a href="(.+?)"').findall(r)
    for a, b in i:
        addDir(a, b, 19, iconimage, fanart, '', '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 18, iconimage, fanart, '', page + 32)

def nava_musor():
    r = client.source(url + '&simple=&sort=datem&start=' + str(page))
    m = re.compile('/id/(.+?)/.+?strong>(.+?)<.+?tion">(.+?)<.+?date">(.+?)<').findall(r)
    for nava_id, title, ch, date in m:
        addFile(title + ' - ' + ch + ' ' + date, nava_id, 11, iconimage, fanart, '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 19, iconimage, fanart, '', page + 24)
    
def nava_episodes():
    r = client.source(url + str(page))
    m = re.compile('nava.hu/id/(.+?)/.+?date">(.+?)<').findall(r)
    for nava_id, title in m:
        addFile(description + ' ' + '-' + ' ' + title, nava_id, 11, iconimage, fanart, '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 10, iconimage, fanart, description, page + 24)
    return

def nava_search(search_text, page):
    search_url = 'http://nava.hu/kereses-eredmenye/?sc2=1&sc4=1&search=' + search_text + '&simple&start=' + str(page)
    r = client.source(search_url)
    m = re.compile('/id/(.+?)/.+?strong>(.+?)<.+?tion">(.+?)<.+?date">(.+?)<').findall(r)
    for nava_id, title, ch, date in m:
        addFile(title + ' - ' + ch + ' ' + date, nava_id, 11, iconimage, fanart, '')
    if 'kovetkezo.png' in r:       
        addDir('[COLOR green]Következő oldal[/COLOR]', '', 13, iconimage, fanart, search_text, page + 24)
    return

def live_tv():
    r = client.source(mklikk_url)
    m = client.parseDOM(r, 'div', attrs = {'class': 'liveStreamsMenu'})[0]
    m = client.parseDOM(m, 'div', attrs = {'class': 'col'})[0]
    m = client.parseDOM(m, 'li')
    for item in m:
        url = client.parseDOM(item, 'a', ret='href')[0]
        name = client.parseDOM(item, 'a')[0]
        name = name.split('>')[-1].strip()
        title = epglist.get_epg(name, active=True)
        addFile(title, url, 7, MediaDir + '\\' + name.upper() + '.png', fanart, name)
    return

def live_radio():
    addFile('Kossuth Rádió', 'kossuth-radio-elo/', 9, MediaDir + '\\Kossuth.png', fanart, '')
    addFile('Petőfi Rádió', 'petofi-radio-elo', 9, MediaDir + '\\Petofi.png', fanart, '')
    addFile('Bartók Rádió', 'bartok-radio-elo/', 9, MediaDir + '\\Bartok.png', fanart, '')
    addFile('Dankó Rádió', 'danko-radio-elo', 9, MediaDir + '\\Danko.png', fanart, '')
    addFile('Nemzetiségi Rádió', 'nemzetisegi-adasok-elo/', 9, MediaDir + '\\Nemzetisegi.png', fanart, '')
    addFile('Parlamenti Rádió', 'parlamenti-adasok-elo', 9, MediaDir + '\\Parlamenti.png', fanart, '')
    addFile('Duna World Rádió', 'duna-world-radio-elo/', 9, MediaDir + '\\DUNA WORLD.png', fanart, '')

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('' , 'Keresés')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()
        nava_search(search_text, 0)
        return

########## 

def get_epg():
    try:
        list = epglist.get_epg(name)
        programs = ['[B]%s[/B] - %s' % (i['start'], i['title']) for i in list]
        q = control.selectDialog(programs, name)
        if not q == -1: get_liveTv()
    except:
        return

def play_url(url, iconimage, name):
    videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': name})
    xbmc.Player().play(url, videoitem)
    
def get_Tv():
    qs = control.setting('quality')
    
    m = client.source('http://player.mediaklikk.hu/player/player-external-vod-full.php?token=' + url)
    m = m.replace('\'','')
    direct_url = re.compile('file.+?"?\'?\s?(http.+?m3u8)').findall(m)[-1]
    chunk_list = client.source(direct_url)
    chunk_list = chunk_list.replace('\n', '')
    chunk_list = re.compile('BANDWIDTH=([0-9]+)(.+?m3u8)').findall(chunk_list)
    if len(chunk_list) == 0: direct_url = direct_url[0]
    else:
        chunk_list = [(int(i[0]), i[1]) for i in chunk_list]
        chunk_list = sorted(chunk_list, reverse=True)
        q_list = [str(i[0]) for i in chunk_list]
        q_list = [q.replace('3000000', '720p').replace('1600000', '480p').replace('1200000', '360p').replace('800000', '290p').replace('400000', '180p') for q in q_list]
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        if qs == '0':
            dialog = xbmcgui.Dialog()
            q = dialog.select('Minőség', q_list)
            if q == -1: return
        else: q = int(qs) - 1
        direct_url = direct_url.split('playlist')[0] + chunk_list[q][1]
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    if direct_url:
        play_url(direct_url, iconimage, name)
    return  
    
def get_liveTv():
    try:
        qs = control.setting('quality')
    
        r = client.source(url)
        m = client.parseDOM(r, 'div', attrs = {'class': 'lb-live'})[0]
        streamid = client.parseDOM(m, 'script', ret='data-streamid')[0]
        userid = client.parseDOM(m, 'script', ret='data-userid')[0]
        
        r = client.source('http://player.mediaklikk.hu/player/player-inside-full3.php?userid=' + userid + '&streamid=' + streamid + '&flashmajor=23&flashminor=0')
        r = r.replace('\'','').replace('\n', '')
        direct_url = re.search('file\s*:\s*([^}]+)', r).group(1)
        result = client.request(direct_url)
        result = result.replace('\r', '').replace('\n', '')
        url_list = re.compile('RESOLUTION.+?x(\d+).+?(VID[^#]+)').findall(result)
        url_list = sorted(url_list, key=lambda tup: tup[0], reverse=True)
        q_list = [(x + 'p') for x,y in url_list]
        if qs == '0':
            dialog = xbmcgui.Dialog()
            q = dialog.select('Minőség', q_list)
            if q == -1: return
        else: q = int(qs) - 1
        direct_url = direct_url.split('index.m3u8')[0] + url_list[q][1]
        if direct_url:
            play_url(direct_url, iconimage, name)
    except:
        return
   
def get_liveRadio():
    r = client.source(mklikk_url + url)
    r = r.replace('\'','')
    direct_url = re.compile('radioStreamUrl\s*?=\s*?(http.+?mp3)').findall(r)
    if direct_url:
        play_url(direct_url[0], iconimage, name)
    return   

def get_nava(url):    
    post = {'action': 'nava_object_ajax_action', 'param': '10', 'id' : url, 'act' : '1'}
    post = urllib.urlencode(post)
    i = client.source(ajax_url, post = post)
    
    if "ON_TAPE" in i:
        dialog = xbmcgui.Dialog()
        m = dialog.yesno("Videó visszatöltése", "A kért média jelenleg nem online állapotú. Kéri a visszatöltését?")

        if m == 1:
            post = {'action': 'nava_object_ajax_action', 'param': '10', 'id' : url, 'act' : '2'}
            post = urllib.urlencode(post)
            i = client.source(ajax_url, post = post)
            get_nava(url)
        else:
            return
    elif "IN_QUEUE" in i or "IS_RECALLING" in i:
        progress = xbmcgui.DialogProgress()
        progress.create("Videó visszatöltése", "'" + name + "'" + " - " + "visszatöltése elindult.", "Kérem várjon...")       
        time.sleep(5)
        if progress.iscanceled():
            progress.close()
            return
        get_nava(url)
        
    elif "ON_DISK" in i:
        post = {'action':'nava_object_ajax_action', 'param':'1', 'id':url, 'pos':'00:00:00', 'prev':'', 'virtual':'false'}
        post = urllib.urlencode(post)
        r = client.source(ajax_url, post = post)
        direct_url = re.compile('file.+?"(.+?m3u8)').findall(r)[0]
        play_url(direct_url, iconimage, name)
    
    else:
        dialog.ok("HIBA!", "A kért média nem elérhető!")
        return 

##########

def addDir(name, url, mode, iconimage, fanart, description, page):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addFile(name, url, mode, iconimage, fanart, description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    cm = []
    cm.append((u'M\u0171sor\u00FAjs\u00E1g', 'RunPlugin(%s?mode=20&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(description))))
    liz.addContextMenuItems(cm, replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = ''
page = 0
search_text = ''

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    search_text = urllib.unquote_plus(params["description"])
except:
    pass

if mode==None:
    main_folders()
elif mode==1:
    musor_lista()
elif mode==2:
    epizod_lista()
elif mode==3:
    get_Tv()
elif mode==5:
    live_folders()
elif mode==6:
    live_tv()
elif mode==7:
    get_liveTv()
elif mode==8:
    live_radio()
elif mode==9:
    get_liveRadio()
elif mode==10:
    nava_episodes()
elif mode==11:
    get_nava(url)
elif mode==12:
    open_search_panel()
elif mode==13:
    nava_search(search_text, page)
elif mode==14:
    play_url(url, iconimage, name)
elif mode==15:
    nava_folders()
elif mode==16:
    nava_csat()
elif mode==17:
    nava_mufaj()
elif mode==18:
    nava_list()
elif mode==19:
    nava_musor()
elif mode==20:
    get_epg()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
