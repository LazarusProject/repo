# -*- coding: utf-8 -*-
import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin

def folders():
    addDir3('Origo filmklub', 'http://videa.hu/csatornak/97', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('Life.hu', 'http://videa.hu/csatornak/53', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('Origo', 'http://videa.hu/csatornak/2', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('XOXO', 'http://videa.hu/csatornak/93', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    #addDir3('*HairHungary', 'http://videa.hu/csatornak/83', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('LifeNetwork', 'http://videa.hu/csatornak/27', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('OzoneNetwork', 'http://videa.hu/csatornak/26', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    #addDir3('*Zeneakadémia', 'http://videa.hu/csatornak/87', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('HOT24', 'http://videa.hu/csatornak/88', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('MüPa', 'http://videa.hu/csatornak/80', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    addDir3('P+ TV', 'http://videa.hu/csatornak/79', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')
    #addDir3('*Zeneakadémia projekt', 'http://videa.hu/csatornak/94', 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')


def getvideos(url):
    r = requests.get(url)

    match = re.compile('thumb thumb_m thumb_ql channel channel_.+?<img src="(.+?)" alt="(.+?)"', re.DOTALL).findall(r.content.split('most nézik')[0])
    for img, name in match:
        url = img.split('.')
        url = 'http://videa.hu/static/video/'+url[2]+'.'+url[3]+'.'+url[4]
        addDir4(name, url, 2, 'http://videa.hu' + img, 'http://i.imgur.com/7sA9loV.jpg', name)

    match = re.compile('<a class="pager_right" href="(.+?)" ></a>').findall(r.content)
    addDir3('Következő oldal', 'http://videa.hu/csatornak/97'+match[0], 1, 'http://i.imgur.com/Wua1ajK.png', 'http://i.imgur.com/7sA9loV.jpg', '')

    return

def getvideo(url):
    xbmc.Player().play(url)
    return

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass

if mode==None or url==None or len(url)<1:
    folders()
elif mode==1:
    getvideos(url)
elif mode==2:
    getvideo(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))