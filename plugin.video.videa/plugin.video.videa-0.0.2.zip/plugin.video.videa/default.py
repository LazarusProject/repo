# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin
from resources.lib import client

thisAddon = xbmcaddon.Addon(id='plugin.video.videa')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')

def folders():
    r = client.source('http://videa.hu/')
    result = client.parseDOM(r, 'ul', attrs = {'class': 'main-menu-list'})[0]
    result = result.replace('\n','')
    result = re.compile('menu-channels">([\s\S]+)\/ul>').findall(result)[0]
    result = re.compile('<a href="?\'?([^"\'>]*).+?>(.+?)<').findall(result)
    for i in result:
        addDir3(i[1].encode('utf-8'), i[0], 1, thisAddonDir + '\\icon.png', thisAddonDir + '\\fanart.jpg', '', 1)
    
def getvideos():
    r = client.source(url + '?page=' + str(page))
    r = r.replace('\n','')
    match = client.parseDOM(r, 'div', attrs = {'class': 'panel panel-video'})
    try:
        for i in match:
            a = re.compile('video-link" href="?\'?([^"\'>]*).+?video-thumbnail.+?src="(.+?)".+?video-title.+?a href.+?>(.+?)<').findall(i)[0]
            vid_id = a[1].split('.')
            vid_id = vid_id[2]+'.'+vid_id[3]+'.'+vid_id[4]
            addDir4(client.replaceHTMLCodes(a[2]).encode('utf-8'), a[0], 2, 'http://videa.hu' + a[1], fanart, vid_id)
    except:
        pass
    try:
        match = client.parseDOM(r, 'ul', attrs = {'class': 'pagination'})[0]
        match = client.parseDOM(match, 'a', ret='href')[-1]
        match = re.compile('page=([0-9]+)').findall(match)[0]
        if int(match) == page: raise Exception
        addDir3('(' + str(page) + ') ' + '[COLOR green]Következő oldal[/COLOR]', url, 1, iconimage, fanart, '', int(match))
    except:
        pass
    return

def getvideo():
    result = client.source('http://videa.hu/videaplayer_get_xml.php?f=' + description + '&start=0&enablesnapshot=0&referrer=' + url)
    result = result.replace('\n','')
    result = re.compile('<video_sources>(.+?)</video_sources').findall(result)[0]
    q_list = client.parseDOM(result, 'video_source', ret='name')
    stream_list = re.compile('static/(.+?)<').findall(result)
    dialog = xbmcgui.Dialog()
    q = dialog.select('Minőség', q_list)
    if q == -1: return
    direct_url = 'http://videa.hu/static/' + stream_list[q]
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    if direct_url:
        videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels={'Title': name})
        xbmc.Player().play(direct_url, videoitem)
    return

def addDir3(name,url,mode,iconimage,fanart,description,page):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+str(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir4(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
        page=int(params["page"])
except:
        pass

if mode==None or url==None or len(url)<1:
    folders()
elif mode==1:
    getvideos()
elif mode==2:
    getvideo()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
