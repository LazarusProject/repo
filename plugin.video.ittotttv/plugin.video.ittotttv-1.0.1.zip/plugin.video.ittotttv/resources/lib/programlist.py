# -*- coding: utf-8 -*-

import os,xbmc,re,datetime
from resources.lib import cache, client, control

dnow = datetime.datetime.now().strftime('%H:%M')

base_link = 'http://ittott.tv/'

def plist():
    r = client.request(base_link)
    channels = client.parseDOM(r, 'div', attrs={'class':'channels'})
    channels = client.parseDOM(channels, 'div', attrs={'class':'carouselAbsolute'})
    channels = client.parseDOM(channels, 'div', attrs={'class':'item'})
    channels = client.parseDOM(channels, 'img', ret='title')
    
    programs = client.parseDOM(r, 'div', attrs={'class':'programs'})
    programs = client.parseDOM(programs, 'div', attrs={'class':'carouselAbsolute'})
    programs = client.parseDOM(programs, 'div', attrs={'class':'row clearfix'})
    programs = [(client.parseDOM(i, 'p')) for i in programs]
    schedule = zip(channels, programs)
    return schedule
    
def get_program(channel, active = None):
    channel = re.sub('\[[^\]]*\]', '', channel).strip()
    schedule = cache.get(plist, 1)
    program = [i[1] for i in schedule if channel == i[0]]

    if not active == True:
        try:
            pr = []
            for item in program[0]:
                try:
                    title, time = re.compile('title\s*=\s*"([^<]+).+?>([^<]+)').findall(item)[0]
                    pr.append({'title': title, 'time': time})
                except:
                    pass
            
            list = []
            for item in pr:  
                d_time = item['time'].split('&#8211;')
                title = '[B]%s[/B] %s' % (d_time[0], item['title'])
                title = client.replaceHTMLCodes(title)
                title.encode('utf-8')

                if d_time[0] < dnow < d_time[1]:
                    title = '[COLOR yellow]%s[/COLOR]' % title
                
                list.append(title)
            return list
        except:
            control.infoDialog('Műsorújság nem elérhető', channel)

    else:
        try:
            for item in program[0]:
                title, time = re.compile('title\s*=\s*"([^<]+).+?>([^<]+)').findall(item)[0]
                title = client.replaceHTMLCodes(title)
                
                d_time = time.split('&#8211;')
                if d_time[0] < dnow < d_time[1]:
                    time = client.replaceHTMLCodes(time)
                    program = title + ' ' + time
        except:
            program = ''
        return program
