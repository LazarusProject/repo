# -*- coding: utf-8 -*-

import os,xbmc,xbmcaddon,xbmcgui,xbmcvfs


setting = xbmcaddon.Addon().getSetting

addonInfo = xbmcaddon.Addon().getAddonInfo

dialog = xbmcgui.Dialog()

execute = xbmc.executebuiltin

makeFile = xbmcvfs.mkdir

dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')

cacheFile = os.path.join(dataPath, 'cache.db')


def addonIcon():
    try: return os.path.join(addonInfo('path'), 'icon.png')
    except: pass


def addonFanart():
    try: return os.path.join(addonInfo('path'), 'fanart2.jpg')
    except: pass


def addonBackground():
    try: return os.path.join(addonInfo('path'), 'background.jpg')
    except: pass


def yesnoDialog(line1, line2, line3, heading=addonInfo('name'), nolabel='', yeslabel=''):
    return dialog.yesno(heading, line1, line2, line3, nolabel, yeslabel)


def infoDialog(message, heading=addonInfo('name'), icon='', time=5000):
    if icon == '': icon = addonIcon()
    try: dialog.notification(heading, message, icon, time, sound=False)
    except: execute("Notification(%s,%s, %s, %s)" % (heading, message, time, icon))


def openSettings(id=addonInfo('id')):
    try:
        idle()
        execute('Addon.OpenSettings(%s)' % id)
    except:
        return


def idle():
    return execute('Dialog.Close(busydialog)')
