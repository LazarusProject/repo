# -*- coding: utf-8 -*-

import xbmc, xbmcgui, urllib, re, xbmcplugin, xbmcaddon, urlparse, json
from resources.lib import client
from resources.lib import control

mobile = control.setting('ittott.mobil')
password = control.setting('ittott.pass')
base_link = 'http://ittott.tv/'

def root():
    if (mobile == '' or password == ''):
        l = control.yesnoDialog('Kérlek add meg a bejelentkezéshez szükséges adataidat!', '', '', 'Bejelentkezés', 'Mégsem', 'OK')
        if l == 1: control.openSettings()
        sys.exit()

    login = urlparse.urljoin(base_link, '/?useraction=login')
    post = urllib.urlencode({'mode': 'ajax', 'login_humobilprefix[]': mobile[:2], 'login_humobilplus': mobile[2:], 'login_hupassword': password, 'loginsubmitIndicator': 'true'})
    r = client.request(login, post=post, output='extended', close=False)
    cookie = r[4]
   
    try:
        result = json.loads(r[0])
        result = result['content']['loginlogoutblock']['value']
        if not'?useraction=logout' in result: raise Exception()
    except:
        l = control.yesnoDialog('Sikertelen bejelentkezés!', 'Kérlek ellenőrizd a bejelentkezési adataidat és próbáld meg újra!', '', 'Bejelentkezés', 'Mégsem', 'OK')
        if l == 1: control.openSettings()
        sys.exit()
    
    mytv = urlparse.urljoin(base_link, '/mytv')
    post = urllib.urlencode({'mode': 'ajax'})
    r = client.request(mytv, post=post, cookie=cookie)
    result = json.loads(r)
    result = result['content']['ajaxpopup']['value']

    channels = client.parseDOM(result, 'li', attrs={'class':'item channelItem\s*active'})
    channels += client.parseDOM(result, 'li', attrs={'class':'item channelItem\s*'})

    for item in channels:
        try:
            url = client.parseDOM(item, 'a', ret='href')[0]
            url = urlparse.urljoin(base_link, url)
            url = url.encode('utf-8')
            
            title = re.search('title\s*=\s*"([^"]+)', item).group(1)
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
            
            img = client.parseDOM(item, 'img', ret='src')[0]
            img = urlparse.urljoin(base_link, img)
            img = img.encode('utf-8')
            addFile(title, url, 1, img, control.addonBackground(), '', cookie)
        except:
            pass


def getStream():
    try:
        post = urllib.urlencode({'mode': 'ajax'})
        r = client.request(url, post=post, cookie=cookie)
        result = json.loads(r)
        result = result['content']['ajaxpopup']['value']

        stream = client.parseDOM(result, 'source', ret='src')[0]
        
        videoitem = xbmcgui.ListItem(label=name, thumbnailImage=iconimage)
        videoitem.setInfo(type='Video', infoLabels={'Title': name})
        xbmc.Player().play(stream, videoitem)
    except:
        return


def addFile(name, url, mode, iconimage, fanart, description, cookie):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&cookie="+urllib.quote_plus(cookie)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
cookie = None

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    cookie = urllib.unquote_plus(params["cookie"])
except:
    pass


if mode==None or url==None or len(url)<1:
    root()
elif mode==1:
    getStream()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
