import os
import sys
import urllib
import urllib2
import re
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import time
import shutil
import json

REMOTE_DBG = False

#TRAKT
#josorozat --- ids = {"imdb": "tt4016454", "status": "Continuing", "season": "1", "tvshowtitle": "Supergirl", "episode": "2"}
#jomovie --- ids = {"imdb": "tt2379713", "year": "2015", "status": "Continuing", "title": "Spectre"}

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
	# stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)

thisAddon = xbmcaddon.Addon(id='plugin.video.movieshark')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
sys.path.append(os.path.join(thisAddonDir, 'resources', 'media'))
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media'))
SettingsDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources'))
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ) 

import jsunpack
import requests
import simplejson
import urlresolve

if sys.platform == 'win32':
    download_script = thisAddonDir + '\\default.py'
    favourite_file = UserDataDir + '\\favourite.dat'
    favourite_tmp = UserDataDir + '\\favourite.tmp'
    watched_file = UserDataDir + '\\watched.dat'
    watched_tmp = UserDataDir + '\\watched.tmp'
    playlist_file = UserDataDir + '\\playlist.dat'
    playlist_tmp = UserDataDir + '\\playlist.tmp'
    search_file = UserDataDir + '\\search.dat'
    settings_orig = SettingsDir + '\\settingsorig.xml'
    settings_temp = SettingsDir + '\\settingstemp.xml'
    settings_file = SettingsDir + '\\settings.xml'
else:
    download_script = thisAddonDir + '/default.py'
    favourite_file = UserDataDir + '/favourite.dat'
    favourite_tmp = UserDataDir + '/favourite.tmp'
    watched_file = UserDataDir + '/watched.dat'
    watched_tmp = UserDataDir + '/watched.tmp'
    playlist_file = UserDataDir + '/playlist.dat'
    playlist_tmp = UserDataDir + '/playlist.tmp'
    search_file = UserDataDir + '/search.dat'
    settings_orig = SettingsDir + '/settingsorig.xml'
    settings_temp = SettingsDir + '/settingstemp.xml'
    settings_file = SettingsDir + '/settings.xml'

sort_set = ['nezettseg','abc','feltoltve','imdb']

quality_set = ['0','2','3','4']

language_set = ['0','2','3']

category_set = ['0','18','akcio','animacio','anime','csaladi','dokumentum','drama','eletrajzi','fantasy','haborus','horror','kaland',
                'krimi','misztikus','romantikus','sci-fi','sorozat','sport','thriller','tortenelmi','vigjatek','western','zenes']

base_filmezz = thisAddon.getSetting('base_filmezz')
api_key = thisAddon.getSetting('api_key')

def gettrakt(imdbnum):
    if imdbnum[0] != '':
        top_url = 'http://akas.imdb.com/title/' + imdbnum[0]
        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return
        else:
            title = re.compile('<title>([^<]*)').findall(url_content)
            titleorig = re.compile('class="title-extra" itemprop="name">([^<]+)').findall(url_content)
            if titleorig:
                titleorig = re.compile('"([^"]+)').findall(titleorig[0])
                title.append(titleorig[0])
            return(title)
	return('')

def decode_movie_info(movie_info_data):
    if movie_info_data[1] == '3':
        movie_info = '[COLOR green] SZINKRON[/COLOR]'
    elif movie_info_data[1] == '2':
        movie_info = '[COLOR red] FELIRAT[/COLOR]'
    elif movie_info_data[1] == '1':
        movie_info = '[COLOR yellow] NINCS FELIRAT[/COLOR]'

    if movie_info_data[0] == '4':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[0] == '3':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[0] == '2':
        movie_info = movie_info + '[COLOR blue] TV[/COLOR]'
    elif movie_info_data[0] == '1':
        movie_info = movie_info + '[COLOR blue] CAM[/COLOR]'

    return movie_info

def decode_movie_info_neg(movie_info_data):
    if movie_info_data[0] == '3':
        movie_info = '[COLOR green] SZINKRON[/COLOR]'
    elif movie_info_data[0] == '2':
        movie_info = '[COLOR red] FELIRAT[/COLOR]'
    elif movie_info_data[0] == '1':
        movie_info = '[COLOR yellow] NINCS FELIRAT[/COLOR]'

    if movie_info_data[1] == '4':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[1] == '3':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[1] == '2':
        movie_info = movie_info + '[COLOR blue] TV[/COLOR]'
    elif movie_info_data[1] == '1':
        movie_info = movie_info + '[COLOR blue] CAM[/COLOR]'

    return movie_info

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('',u'Add meg a keresend\xF5 film c\xEDm\xE9t')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()

    return search_text

def find_read_error(top_url):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'en-US,en;q=0.8'})
        url_handler = urllib2.urlopen(req)
        url_content = url_handler.read()
        url_handler.close()
    except:
        url_content = 'HIBA'
        addon = xbmcaddon.Addon()
        addonname = addon.getAddonInfo('name')
        line1 = u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!'
        xbmcgui.Dialog().ok(addonname, line1)
        return url_content
    return url_content

def find_read_error_params(top_url, params):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'en-US,en;q=0.8'})
        url_handler = urllib2.urlopen(req, params)
        url_content = url_handler.read()
        url_handler.close()
    except:
        url_content = 'HIBA'
        addon = xbmcaddon.Addon()
        addonname = addon.getAddonInfo('name')
        line1 = u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!'
        xbmcgui.Dialog().ok(addonname, line1)
        return url_content
    return url_content

def just_beta(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = u'Ebben a verzi\xF3ban, ez a vide\xF3 kiszolg\xE1l\xF3 nem t\xE1mogatott!'
    cim = file_host.decode('utf-8')
    xbmcgui.Dialog().ok(addonname, line1, u'Vide\xF3 kiszolg\xE1l\xF3: ' + cim)  
    return

def just_removed(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = u'A keresett vide\xF3t elt\xE1vol\xEDtott\xE1k!'
    cim = file_host.decode('utf-8')
    xbmcgui.Dialog().ok(addonname, line1, u'Vide\xF3 c\xEDme: ' + cim)   
    return

def viewmode():
    addon_settings = xbmcaddon.Addon()
    mview = int(addon_settings.getSetting('mview'))

    if mview == 0:
        xbmc.executebuiltin('Container.SetViewMode(50)')
    elif mview == 1:
        xbmc.executebuiltin('Container.SetViewMode(500)')

    return

def find_fanart(imdbnum, videotype):
    fanart_info = [' ',' ','0',' ']
    image_url = ''
    year = ''
    genre = ''
    genre2 = ''
    overview = ''

    imdbnum = re.compile('([0-9]+)').findall(imdbnum)
    imdbnum = 'tt' + imdbnum[0]

    top_url = 'http://api.themoviedb.org/3/find/' + imdbnum +'?api_key=' + api_key + '&external_source=imdb_id&language=hu'
    
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    if '"overview":null' in url_content:
        top_url = 'http://api.themoviedb.org/3/find/' + imdbnum +'?api_key=' + api_key + '&external_source=imdb_id&language=en'
        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return

    if '"overview":null' not in url_content:
        if '"release_date"' in url_content:
            if '"release_date":null' not in url_content:
                year = re.compile('release_date":"([0-9]+)').findall(url_content)
        if '"first_air_date"' in url_content:
            if '"first_air_date":null' not in url_content:
                year = re.compile('"first_air_date":"([0-9]+)').findall(url_content)
        if '"backdrop_path":null' not in url_content:
            image_url = re.compile('backdrop_path":"([^"]+)').findall(url_content)
        else:
            if '"poster_path":null' not in url_content:
                image_url = re.compile('"poster_path":"([^"]+)').findall(url_content)

        overview = re.compile('overview":"(.+?(?=\",\"))').findall(url_content)
        genre = re.compile('vote_average":([^,]+)').findall(url_content)
        genre2 = re.compile('vote_count":([^"}"]+)').findall(url_content)
        if genre:
            genre = 'Pontszam: ' + genre[0]
        if genre2:
            genre = genre + ' Szavazat: ' + genre2[0]
		
        if image_url:
            fanart_info[0] = 'https://image.tmdb.org/t/p/w780' + image_url[0]

        if overview:
            fanart_info[1] = overview[0].strip(' \t\n\r')

        if year:
            fanart_info[2] = year[0]

        if genre:
            fanart_info[3] = genre
            
    return fanart_info

def download_video(videotitle, videourl):
    try:
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        savefolder = addon_settings.getSetting('savefolder').decode('utf-8')
        
        if savefolder == 'Nincs megadva!':
            xbmcgui.Dialog().ok(u'Let\xF6lt\xE9si hiba', u'Meg kell adnod egy let\xF6lt\xE9si k\xF6nyvt\xE1rat a be\xE1ll\xEDt\xE1sokban!')
            return
      
        headers = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'}
        r = requests.head(videourl)
        content = r.text
        file_size = r.headers['Content-Length']

        r = requests.get(videourl)

        videotitle = videotitle.decode('string_escape')
        videotitle = videotitle.decode('utf-8')
        videotitle = re.sub(r'[\\/:"*?<>|]+', '', videotitle)
        localfile = open(savefolder + videotitle, 'wb')
        file_size_dl = 0
        block_sz = 8192
        localfile.write(r)
        pDialog.close()
        localfile.close()
        url_handler.close()
        xbmcgui.Dialog().ok(u'A let\xF6lt\xE9s k\xE9sz!', videotitle)

        pDialog = xbmcgui.DialogProgress()
        pDialog.create(u'Let\xF6lt\xE9s folyamatban...')
        while True:
            buffer = r.content.iter_lines(chunk_size=512, decode_unicode=None, delimiter=None)
            if not buffer:
                break

            file_size_dl += len(buffer)
            localfile.write(buffer)
            status = int(file_size_dl * 100. / file_size)
            pDialog.update(status, videotitle, u'Vide\xF3 m\xE9rete: ' + str(int(file_size/1024/1024)) + ' MByte', u'Let\xF6lt\xF6tt adat: ' + str(int(file_size_dl/1024/1024)) + ' MByte')
        
            if pDialog.iscanceled():
                pDialog.close()
                localfile.close()
                url_handler.close()
                os.remove(savefolder + videotitle)
                return

        pDialog.close()
        localfile.close()
        url_handler.close()
        xbmcgui.Dialog().ok(u'A let\xF6lt\xE9s k\xE9sz!', videotitle)
    except:
        url_content = 'HIBA'
        addon = xbmcaddon.Addon(id='plugin.video.movieshark')
        addonname = addon.getAddonInfo('name')
        line1 = u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!'
        xbmcgui.Dialog().ok(addonname, line1)
        return url_content
    return

def decode_youtube_trailer(youtube_id):
    top_url = 'http://youtube.com/get_video_info?video_id=' + youtube_id

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    youtube_fmt = re.compile('url_encoded_fmt_stream_map=([^&]+)').findall(url_content)
    if youtube_fmt:
        url_content = urllib.unquote(youtube_fmt[0]).decode('utf-8')
        youtube_url_base = re.compile('url=([^&]+)').findall(url_content)
        youtube_url = urllib.unquote(youtube_url_base[0]).decode('utf-8')
        return urllib.unquote(youtube_url).decode('utf-8')

    return False
	
def build_kategoriak_directory(foldername, pagenum, action):
    for poz in range(len(category_set)):
        if category_set[poz] != '0':
            url = build_url({'mode': 'main_folder', 'foldername': poz, 'pagenum': '0', 'action' : 'none'})
            li = xbmcgui.ListItem(category_set[poz], iconImage=MediaDir + '\\Kategoriak.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_main_directory():
    url = build_url({'mode': 'main_folder', 'foldername': 'Kereses', 'pagenum': '0', 'action' : 'Firstrun'})
    li = xbmcgui.ListItem(u'Keres\xE9s', iconImage=MediaDir + '\\Kereses.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Kereses_szimpla', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Keres\xE9s szimpla', iconImage=MediaDir + '\\KeresesSimple.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
								
    url = build_url({'mode': 'main_folder', 'foldername': 'Filmek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Filmek', iconImage=MediaDir + '\\Filmek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Sorozatok', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Sorozatok', iconImage=MediaDir + '\\Sorozatok.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'kategoriak', 'foldername': 'Kategoriak', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Kateg\xF3ri\xE1k', iconImage=MediaDir + '\\Kategoriak.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Kedvencek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Kedvencek', iconImage=MediaDir + '\\Kedvencek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Playlist', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Lej\xE1tsz\xE1si lista', iconImage=MediaDir + '\\Playlist.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
								
    url = build_url({'mode': 'main_folder', 'foldername': 'Beallitasok', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Be\xE1ll\xEDt\xE1sok', iconImage=MediaDir + '\\Beallitasok.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=False)
    try:
        os.remove(search_file)
    except:
        pass

    #viewmode()
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_movie_directory(foldername, pagenum, action):
    try:
        the_file = open(search_file,'r')
        search_text = the_file.read().replace('\n', '')
        the_file.close()
    except:
        search_text = ''

    imdbnum = ''

    if foldername == 'Kereses' or foldername == 'Filmek' or foldername == 'Sorozatok' or foldername.isdigit():
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        msort = int(addon_settings.getSetting('msort'))
        mquality = int(addon_settings.getSetting('mquality'))
        mlanguage = int(addon_settings.getSetting('mlanguage'))
        mcategory = int(addon_settings.getSetting('mcategory'))
        myear = addon_settings.getSetting('myear')
        mtype = addon_settings.getSetting('mtype')
        msearch = addon_settings.getSetting('msearch')
     
        if foldername.isdigit():
            mcategory = int(foldername)

        if (action == 'Ujkereses' or action == 'Firstrun') and search_text == '':
                os.remove(settings_file)
                shutil.copyfile(settings_temp, settings_file)

                addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
                addon_settings.openSettings()

                msort = int(addon_settings.getSetting('msort'))
                mquality = int(addon_settings.getSetting('mquality'))
                mlanguage = int(addon_settings.getSetting('mlanguage'))
                mcategory = int(addon_settings.getSetting('mcategory'))
                myear = addon_settings.getSetting('myear')
                mtype = addon_settings.getSetting('mtype')
                msearch = addon_settings.getSetting('msearch')
        if action == 'Firstrun':
                os.remove(settings_file)
                shutil.copyfile(settings_orig, settings_file)

        if action == 'none' and os.path.getsize(settings_file) == os.path.getsize(settings_temp):
                os.remove(settings_file)
                shutil.copyfile(settings_orig, settings_file)
                pagenum = '0'

        try:
                os.remove(search_file)
        except:
                pass
	
        if myear == 'true':
                mfyear = int(addon_settings.getSetting('mfyear'))
        else:
                mfyear = 0

        if foldername == 'Filmek':
                mtype = '1'
        elif foldername == 'Sorozatok':
                mtype = '2'
        else:
                mtype = '0'

        top_url = base_filmezz + '/kereses.php?p=' + pagenum + '&s=' + msearch.replace(' ','+') + '&w=0&o=' + sort_set[msort] + '&q=' + quality_set[mquality] + '&l=' + language_set[mlanguage] + '&e=' + str(mfyear) + '&c=' + category_set[mcategory] + '&t=' + str(mtype) + '&h=0'

        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
                return

        movie_names = re.compile('<center><b>(.+)</b>').findall(url_content)
        if foldername == 'Filmek':
                movie_urls = re.compile('film\.php\?n=([^&]+)').findall(url_content)
        else:
                movie_urls = re.compile('film\.php\?n=([0-9a-zA-Z.-]+)').findall(url_content)

        movie_info_data = re.compile('qual\/([0-9]).+?([0-9])\.gif', re.DOTALL).findall(url_content)

        for poz in range(len(movie_urls)):
                url = build_url({'mode': 'movie_folder', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'image': movie_urls[poz]})
                movie_info = decode_movie_info(movie_info_data[poz])
                li = xbmcgui.ListItem(movie_names[poz].decode('utf-8') + movie_info, iconImage=base_filmezz + '/kiskep/' + movie_urls[poz] + '.jpg')
                file_data = movie_urls[poz] + '=spl=' + movie_names[poz] + '=spl=' + movie_info
                if file_data in watched_file_data:
                        li.setInfo( type='Video', infoLabels={ "Title": movie_names[poz].decode('utf-8') + movie_info, 'playcount': 1, 'overlay': 7})
                if addon_settings.getSetting('TMDB') == 'true' and api_key != '000':
                    imdbnum = find_imdb_num(movie_urls[poz], 'movie')
                    if imdbnum:
                        fanart_info = find_fanart(imdbnum[0], 'MOVIE')
                        li.setProperty('fanart_image', fanart_info[0])
                        li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf1 = {'mode': 'main_folder', 'foldername': foldername, 'pagenum': '0', 'action': 'Ujkereses'}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)

                url_conf = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDF', 'pagenum' : pagenum}
                favourite_args = '?' + urllib.urlencode(url_conf)

                url_conf2 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDW', 'pagenum' : 'SEARCH'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)

                url_conf3 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'REMOVEW', 'pagenum' : 'SEARCH'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
				
                url_conf4 = {'mode': 'main_folder', 'foldername': 'Kereses_szimpla', 'pagenum': '0', 'action': 'none'}
                favourite_args4 = '?' + urllib.urlencode(url_conf4)

                if foldername == 'Kereses':
                    li.addContextMenuItems([ (u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
					(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
					(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])
                else:
                    li.addContextMenuItems([ (u'\xDAj keres\xE9s', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'),
					#(u'Szimpla keres\xE9s', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args4 + ')'),
					(u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
					(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
					(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                        listitem=li, isFolder=True)

        if len(movie_urls) == 0:
                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': '0', 'action': 'Ujkereses'})
                li = xbmcgui.ListItem(u'[COLOR red]>> Nincs tal\xE1lat >>[/COLOR]', iconImage=MediaDir + '\\Kereses.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                                        listitem=li, isFolder=False)

        if pagenum != '0':
                pagenum = int(pagenum)
                pagenum -= 1
                pagenum = str(pagenum)                
                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': pagenum, 'action': 'none'})
                li = xbmcgui.ListItem(u'[COLOR blue]<< El\u0151z\u0151 oldal <<[/COLOR]', iconImage=MediaDir + '\\Elozo.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                                           listitem=li, isFolder=True)   
                pagenum = int(pagenum)
                pagenum += 1
                pagenum = str(pagenum) 

        if 'Oldalak:' in url_content and 'telekkel nincs tal' not in url_content:
                pagenum = int(pagenum)
                pagenum += 1
                pagenum = str(pagenum)

                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': pagenum, 'action': 'none'})
                li = xbmcgui.ListItem(u'[COLOR green]>> K\xF6vetkez\u0151 oldal >>[/COLOR]', iconImage=MediaDir + '\\Kovetkezo.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                   listitem=li, isFolder=True)   

        #viewmode()
        if args['pagenum'][0] != '0':
            xbmcplugin.endOfDirectory(addon_handle, updateListing = True)
        else:
            xbmcplugin.endOfDirectory(addon_handle, updateListing = False)	
        if action == 'Ujkereses':
                xbmc.executebuiltin('XBMC.Container.Refresh()')
        	

    elif foldername == 'Kereses_szimpla':
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        msort = int(addon_settings.getSetting('msort'))
        if search_text == '':
            search_text = open_search_panel()

        if search_text != '':
            top_url = base_filmezz + '/kereses.php?s=' + search_text.replace(' ','+') + '&w=0&o=' + str(msort) + '&q=&l=&e=&c=&t=0&h=0'

            url_content = find_read_error(top_url)
            if url_content == 'HIBA':
                return

            movie_names = re.compile('<center><b>(.+)</b>').findall(url_content)
            movie_urls = re.compile('film\.php\?n=([0-9a-zA-Z.-]+)').findall(url_content)
            movie_info_data = re.compile('qual\/([0-9]).+?([0-9])\.gif', re.DOTALL).findall(url_content)
               
            for poz in range(len(movie_urls)):
                url = build_url({'mode': 'movie_folder', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'image': movie_urls[poz]})
                movie_info = decode_movie_info(movie_info_data[poz])
                li = xbmcgui.ListItem(movie_names[poz].decode('utf-8') + movie_info, iconImage=base_filmezz + '/kiskep/' + movie_urls[poz] + '.jpg')
                file_data = movie_urls[poz] + '=spl=' + movie_names[poz] + '=spl=' + movie_info
                if file_data in watched_file_data:
                        li.setInfo( type='Video', infoLabels={ "Title": movie_names[poz].decode('utf-8') + movie_info, 'playcount': 1, 'overlay': 7})
                if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
                    imdbnum = find_imdb_num(movie_urls[poz], 'kerszimpla')
                    if imdbnum:
                        fanart_info = find_fanart(imdbnum[0], 'MOVIE')
                        li.setProperty('fanart_image', fanart_info[0])
                        li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDF', 'pagenum' : pagenum}
                favourite_args = '?' + urllib.urlencode(url_conf)

                url_conf2 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDW', 'pagenum' : search_text}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)

                url_conf3 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'REMOVEW', 'pagenum' : search_text}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
                li.addContextMenuItems([ (u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                        listitem=li, isFolder=True)

            #viewmode()
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
			
    elif foldername == 'Kedvencek':
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        try:
            the_file = open(favourite_file,'r')
            for line in the_file:
                movie_data = line.split('=spl=')
                url = build_url({'mode': 'movie_folder', 'foldername': movie_data[0], 'title': movie_data[1], 'image': movie_data[0]})
                li = xbmcgui.ListItem(movie_data[1].decode('utf-8') + movie_data[2], iconImage=base_filmezz + '/kiskep/' + movie_data[0] + '.jpg')
                file_data = movie_data[0] + '=spl=' + movie_data[1] + '=spl=' + movie_data[2].replace('\n', '')
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": movie_data[1].decode('utf-8') + movie_data[2], 'playcount': 1, 'overlay': 7})
                if addon_settings.getSetting('TMDB') == 'true' and api_key != '000':
                    imdbnum = find_imdb_num(movie_data[0], 'kedvencek')
                    if imdbnum:
                        fanart_info = find_fanart(imdbnum[0], 'MOVIE')
                        li.setProperty('fanart_image', fanart_info[0])
                        li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'REMOVEF', 'pagenum' : '0'}
                favourite_args = '?' + urllib.urlencode(url_conf)
            
                url_conf2 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2].replace('\n', ''), 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2].replace('\n', ''), 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
                li.addContextMenuItems([ (u'T\xF6rles a MovieShark kedvencekb\u0151l', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
                
            the_file.close()
            #viewmode()
            xbmcplugin.endOfDirectory(addon_handle)          
        except:
            #viewmode()
            xbmcplugin.endOfDirectory(addon_handle)

    elif foldername == 'Playlist':
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        try:
            the_file = open(playlist_file,'r')
            for line in the_file:
                movie_data = line.split('=spl=')
                iconimage = base_filmezz + '/kiskep/' + movie_data[2] + '.jpg'
                url = build_url({'mode': 'playlist_play', 'foldername': movie_data[0], 'title': movie_data[1], 'image': movie_data[2].replace('\n', '')})
                li = xbmcgui.ListItem(movie_data[1].decode('utf-8').replace('#',''), iconImage=base_filmezz + '/kiskep/' + movie_data[2].replace('\n', '') + '.jpg')
                file_data = movie_data[0] + '=spl=' + movie_data[1].rpartition('#')[0] + '=spl=' + movie_data[2].replace('\n', '')
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": movie_data[1].decode('utf-8').replace('#',''), 'playcount': 1, 'overlay': 7})
                
                url_conf1 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'REMOVEP', 'pagenum' : '0'}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)
            
                url_conf2 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1].rpartition('#')[0], 'info': movie_data[2].replace('\n', ''), 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1].rpartition('#')[0], 'info': movie_data[2].replace('\n', ''), 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)

                url_conf4 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'PURGEP', 'pagenum' : '0'}
                favourite_args4 = '?' + urllib.urlencode(url_conf4)

                li.addContextMenuItems([ (u'T\xF6rl\xE9s a lej\xE1tsz\xE1si list\xE1b\xF3l', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'), 
										(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
										(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')'), 
										(u'Lej\xE1tsz\xE1si lista ki\xFCr\xEDt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args4 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)
                
            the_file.close()
            #viewmode()
            xbmcplugin.endOfDirectory(addon_handle)          
        except:
            #viewmode()
            xbmcplugin.endOfDirectory(addon_handle)

    elif foldername == 'Beallitasok':
        if os.path.getsize(settings_file) == os.path.getsize(settings_temp):
            os.remove(settings_file)
            shutil.copyfile(settings_orig, settings_file)
        addon_settings = xbmcaddon.Addon()
        addon_settings.openSettings()

    try:
        os.remove(search_file)
    except:
        pass
		
    return

def playlist_play(foldername, foldertitle, folderimage):
    addon_settings = xbmcaddon.Addon()
    pl=xbmc.PlayList(1)
    pl.clear()
    good = False
    the_file = open(playlist_file,'r')
    for line in the_file:
        if foldername in line or good:
            movie_data = line.split('=spl=')
            foldername = movie_data[0]
            foldertitle = movie_data[1].replace('#','')
            folderimage = base_filmezz + '/kiskep/' + movie_data[2].replace('\n','') + '.jpg'
            try:
                traktids = movie_data[3]
            except:
                traktids = 'NOTRAKT'
            if addon_settings.getSetting('TRAKT') != 'true':
                traktids = 'NOTRAKT'
            elif 'NOTRAKT' not in traktids:
                traktids = eval(traktids)
                traktids = traktids[0]
                traktids = eval(traktids)
            good = True
            szolg = foldertitle.rpartition(']')[2].replace(' ','')
            if szolg == 'VidToMe':
                direct_url = find_vidtome_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage, )
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            elif szolg == 'Exashare':
                direct_url = find_exashare_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage)
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            elif szolg == 'Youwatch':
                direct_url = find_youwatch_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage)
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            elif szolg == 'CloudZilla':
                direct_url = find_cloudzilla_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage)
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            elif szolg == 'Flashx':
                direct_url = find_flashx_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage)
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            elif szolg == 'Openload':
                direct_url = find_openload_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage)
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            elif szolg == 'Allvid':
                direct_url = find_allvid_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
                listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage)
                listitem.setInfo(type='Video', infoLabels=traktids)
                xbmc.PlayList(1).add(direct_url, listitem)
            else:
                just_beta(szolg)
    the_file.close()
    xbmc.Player().play(pl)

    return

def find_exashare_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
   	
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    embed_url = re.compile('exashare\.com/embed-([0-9a-zA-Z]+-[0-9a-zA-Z]+)').findall(url_content)
    
    
    if embed_url:
        top_url = 'http://exashare.com/embed-' + embed_url[0] + '.html'

        direct_url = urlresolve.exashare(top_url)

        if direct_url and direct_url != 'HIBA':
            if isdownload == 'DOWNLOAD':
                foldertitle = foldertitle[:41] + '.mp4'
                download_video(foldertitle, direct_url)
            elif isdownload == 'playlist':
                return(direct_url)
            else:
                videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
                if traktid != 'NOTRAKT':
                    traktid = eval(traktid)
                    videoitem.setInfo(type='Video', infoLabels=traktid)
                pl=xbmc.PlayList(1)
                pl.clear()
                xbmc.PlayList(1).add(direct_url, videoitem)
                xbmc.Player().play(pl)
        else:
            just_removed(foldertitle)
    else:
        just_removed(foldertitle)

    return

def find_vidtome_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
            
    direct_url = urlresolve.vidtome(top_url)
    direct_url = direct_url.replace('[','%5B').replace(']','%5D')
    if direct_url and direct_url != 'HIBA':
        if isdownload == 'DOWNLOAD':
            foldertitle = foldertitle[:41] + '.mp4'
            download_video(foldertitle, direct_url)
        elif isdownload == 'playlist':
            return(direct_url)
        else:
            videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
            if traktid != 'NOTRAKT':
                traktid = eval(traktid)
                videoitem.setInfo(type='Video', infoLabels=traktid)
            pl=xbmc.PlayList(1)
            pl.clear()
            xbmc.PlayList(1).add(direct_url, videoitem)
            xbmc.Player().play(pl)
    else:
        just_removed(foldertitle)      

    return

def find_cloudzilla_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
            
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    embed_url = re.compile('neodrive\.co/embed/([0-9A-Z]+)').findall(url_content)

            
    if embed_url:
        top_url = 'http://www.neodrive.co/embed/' + embed_url[0] + '/'

        direct_url = urlresolve.cloudzilla(top_url)

        if direct_url and direct_url != 'HIBA':
            if isdownload == 'DOWNLOAD':
                foldertitle = foldertitle[:41] + '.mp4'
                download_video(foldertitle, direct_url)
            elif isdownload == 'playlist':
                return(direct_url)
            else:
                videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
                if traktid != 'NOTRAKT':
                    traktid = eval(traktid)
                    videoitem.setInfo(type='Video', infoLabels=traktid)
                pl=xbmc.PlayList(1)
                pl.clear()
                xbmc.PlayList(1).add(direct_url, videoitem)
                xbmc.Player().play(pl)
        else:
            just_removed(foldertitle)
    else:
        just_removed(foldertitle)

    return

def find_youwatch_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
   	
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    embed_url = re.compile('youwatch\.org/embed-([0-9a-zA-Z]+-[0-9a-zA-Z]+)').findall(url_content)
    
    
    if embed_url:
        top_url = 'http://youwatch.org/embed-' + embed_url[0] + '.html'

        direct_url = urlresolve.youwatch(top_url)

        if direct_url and direct_url != 'HIBA':
            if isdownload == 'DOWNLOAD':
                foldertitle = foldertitle[:41] + '.mp4'
                download_video(foldertitle, direct_url)
            elif isdownload == 'playlist':
                return(direct_url)
            else:
                videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
                if traktid != 'NOTRAKT':
                    traktid = eval(traktid)
                    videoitem.setInfo(type='Video', infoLabels=traktid)
                pl=xbmc.PlayList(1)
                pl.clear()
                xbmc.PlayList(1).add(direct_url, videoitem)
                xbmc.Player().play(pl)
        else:
            just_removed(foldertitle)
    else:
        just_removed(foldertitle)

    return

def find_flashx_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
            
    direct_url = urlresolve.flashx(top_url)
		
    if direct_url and direct_url != 'HIBA':
        if isdownload == 'DOWNLOAD':
            foldertitle = foldertitle[:41] + '.mp4'
            download_video(foldertitle, direct_url)
        elif isdownload == 'playlist':
            return(direct_url)
        else:
            videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
            if traktid != 'NOTRAKT':
                traktid = eval(traktid)
                videoitem.setInfo(type='Video', infoLabels=traktid)
            pl=xbmc.PlayList(1)
            pl.clear()
            xbmc.PlayList(1).add(direct_url, videoitem)
            xbmc.Player().play(pl)
    else:
        just_removed(foldertitle)      

    return

def find_openload_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
   	
    direct_url = urlresolve.openload(top_url)

    if direct_url and direct_url != 'HIBA':
        if isdownload == 'DOWNLOAD':
            foldertitle = foldertitle[:41] + '.mp4'
            download_video(foldertitle, direct_url)
        elif isdownload == 'playlist':
            return(direct_url)
        else:
            videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
            if traktid != 'NOTRAKT':
                traktid = eval(traktid)
                videoitem.setInfo(type='Video', infoLabels=traktid)
            pl=xbmc.PlayList(1)
            pl.clear()
            xbmc.PlayList(1).add(direct_url, videoitem)
            xbmc.Player().play(pl)
    else:
        just_removed(foldertitle)

    return

def find_allvid_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    top_url = base_filmezz + '/link_to.php?id=' + foldername
            
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    embed_url = re.compile('<IFRAME SRC="([^"]+)').findall(url_content)

            
    if embed_url:
        direct_url = urlresolve.allvid(embed_url[0])

        if direct_url and direct_url != 'HIBA':
            if isdownload == 'DOWNLOAD':
                foldertitle = foldertitle[:41] + '.mp4'
                download_video(foldertitle, direct_url)
            elif isdownload == 'playlist':
                return(direct_url)
            else:
                videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
                if traktid != 'NOTRAKT':
                    traktid = eval(traktid)
                    videoitem.setInfo(type='Video', infoLabels=traktid)
                pl=xbmc.PlayList(1)
                pl.clear()
                xbmc.PlayList(1).add(direct_url, videoitem)
                xbmc.Player().play(pl)
        else:
            just_removed(foldertitle)
    else:
        just_removed(foldertitle)

    return

def find_imdb_num(foldername, type):
    imdbnum = ''
    if type == 'playlist':
        top_url = base_filmezz + '/link_to.php?id=' + foldername
    else:
        top_url = base_filmezz + '/film.php?n=' + foldername

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return
    imdbnum = re.compile('m/title/([^/]+)').findall(url_content)
	
    return(imdbnum)

def build_movie_links(foldername, foldertitle, folderimage):
    imdbnum = ''
    top_url = base_filmezz + '/film.php?n=' + foldername

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    movie_page = re.compile('lang/([0-9])[^/]+/qual/([0-9])[^>]+>[^0-9a-zA-Z]+([^ |\.]+)[\s\S]+?<td>([^/]+)+[^\?]+\?id=([0-9]+)').findall(url_content)
    serie_info = re.compile('<td>(.?[0-9])\.').findall(url_content)
    fanart_info = [' ',' ','0',' ']
    youtube_id = re.compile('www\.youtube\.com/watch\?v=([^"]+)').findall(url_content)
    youtube_trailer = ''
    imdbnum = re.compile('m/title/([^/]+)').findall(url_content)

    if youtube_id:
        youtube_trailer = decode_youtube_trailer(youtube_id[0])
         
    addon_settings = xbmcaddon.Addon()

    if serie_info and 'epiz' in url_content:
        if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
            if imdbnum:
                 fanart_info = find_fanart(imdbnum[0], 'MOVIE')

        if (addon_settings.getSetting('trailer') == 'true') and (youtube_trailer):
            url = build_url({'mode': 'youtube_trailer', 'title': foldertitle, 'image': folderimage, 'url': youtube_trailer})
            li = xbmcgui.ListItem('[COLOR orange]' + foldertitle.decode('utf-8') + u' EL\u0150ZETES[/COLOR]', iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            li.setProperty('fanart_image', fanart_info[0])
            li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

        if imdbnum and addon_settings.getSetting('TRAKT') == 'true':
            trakt_title = gettrakt(imdbnum)
            try:
                ttitle = trakt_title[1]
            except:
                ttitle = re.compile('([^\(]*)').findall(trakt_title[0])
                ttitle = ttitle[0].rstrip()
        else:
            traktids = 'NOTRAKT'
            ttitle = ' '

        for mopage in range(len(serie_info)):
            is_good = addon_settings.getSetting(movie_page[mopage][2])
            if is_good == 'true':
                if imdbnum and addon_settings.getSetting('TRAKT') == 'true':
                    tseason = foldername.rpartition('-')[0][-2:].replace('-','')
                    if tseason == '':
                        tseason = '1'
                    traktids = {"imdb": imdbnum[0], "status": "Continuing", "season": tseason, "tvshowtitle": ttitle, "episode": serie_info[mopage].replace(' ','')}
                url_conf = {'mode': movie_page[mopage][2], 'foldername': movie_page[mopage][4], 'title': foldertitle, 'image': folderimage, 'isdownload' : ' ', 'traktid' : traktids}
                url = build_url(url_conf)
                url_conf = {'mode': movie_page[mopage][2], 'foldername': movie_page[mopage][4], 'title': foldertitle + ' ' + serie_info[mopage], 'image': folderimage, 'isdownload' : 'DOWNLOAD', 'traktid' : traktids}
                download_args = '?' + urllib.urlencode(url_conf)
                movie_info = decode_movie_info_neg(movie_page[mopage])
                umpage3 = movie_page[mopage][3].replace('<','').decode('utf-8')
                li = xbmcgui.ListItem(foldertitle.decode('utf-8') + ' ' + serie_info[mopage] + u'. epiz\xF3d' + movie_info + ' ' + movie_page[mopage][2] + ' [COLOR cyan]' + umpage3 + '[/COLOR]' ,
                                    iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                file_data = movie_page[mopage][4] + '=spl=' + foldertitle + '=spl=' + folderimage
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": foldertitle.decode('utf-8') + folderimage, 'playcount': 1, 'overlay': 7})
                li.setProperty('fanart_image', fanart_info[0])
                li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf1 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle + '#' + serie_info[mopage] + '. epizod' + movie_info + ' ' + movie_page[mopage][2], 'info': folderimage, 'function': 'ADDP', 'pagenum' : '0', 'traktid' : traktids}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)
				
                url_conf2 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)

                li.addContextMenuItems([ (u'Vide\xF3 Let\xF6lt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + download_args + ')'), 
				(u'Hozz\xE1ad\xE1s a lej\xE1tsz\xE1si list\xE1hoz', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
        #viewmode()
    else:
        if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
            if imdbnum:
                 fanart_info = find_fanart(imdbnum[0], 'MOVIE')

        if (addon_settings.getSetting('trailer') == 'true') and (youtube_trailer):
            url = build_url({'mode': 'youtube_trailer', 'title': foldertitle, 'image': folderimage, 'url': youtube_trailer})
            li = xbmcgui.ListItem('[COLOR orange]' + foldertitle.decode('utf-8') + u' EL\u0150ZETES[/COLOR]', iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            li.setProperty('fanart_image', fanart_info[0])
            li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

        if imdbnum and addon_settings.getSetting('TRAKT') == 'true':
            trakt_title = gettrakt(imdbnum)
            try:
                ttitle = trakt_title[1]
            except:
                ttitle = re.compile('([^(]+)').findall(trakt_title[0])
                ttitle = ttitle[0].rstrip()
            tyear = re.compile('(\([^)]+)').findall(trakt_title[0])
            tyear = tyear[0].rstrip()
            tyear = re.findall('\d+', tyear) 
            traktids = {"imdb": imdbnum[0], "status": "Continuing", "year": tyear[0], "title": ttitle}
        else:
            traktids = 'NOTRAKT'

        for mopage in range(len(movie_page)):
            is_good = addon_settings.getSetting(movie_page[mopage][2])
            if is_good == 'true':
                url_conf = {'mode': movie_page[mopage][2], 'foldername': movie_page[mopage][4], 'title': foldertitle, 'image': folderimage, 'isdownload' : ' ', 'traktid' : traktids}
                url = build_url(url_conf)
                url_conf = {'mode': movie_page[mopage][2], 'foldername': movie_page[mopage][4], 'title': foldertitle, 'image': folderimage, 'isdownload' : 'DOWNLOAD', 'traktid' : traktids}
                download_args = '?' + urllib.urlencode(url_conf)
                movie_info = decode_movie_info_neg(movie_page[mopage])
                umpage3 = movie_page[mopage][3].replace('<','').decode('utf-8')
                li = xbmcgui.ListItem(foldertitle.decode('utf-8') + movie_info + ' ' + movie_page[mopage][2] + ' [COLOR cyan]' + umpage3 + '[/COLOR]' ,
                                    iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                file_data = movie_page[mopage][4] + '=spl=' + foldertitle + '=spl=' + folderimage
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": foldertitle.decode('utf-8') + folderimage, 'playcount': 1, 'overlay': 7})
                li.setProperty('fanart_image', fanart_info[0])
                li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf1 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle + '#' + movie_info + ' ' + movie_page[mopage][2], 'info': folderimage, 'function': 'ADDP', 'pagenum' : '0', 'traktid' : traktids}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)

                url_conf2 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)

                li.addContextMenuItems([ (u'Vide\xF3 Let\xF6lt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + download_args + ')'), 
				(u'Hozz\xE1ad\xE1s a lej\xE1tsz\xE1si list\xE1hoz', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'),
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_file(foldername, foldertitle, movieinfo, function, pagenum, traktid):
    
    if function == 'ADDF' or function == 'REMOVEF' or function == 'PURGEF':
        file = favourite_file
        tmpfile = favourite_tmp
    elif function == 'ADDW' or function == 'REMOVEW' or function == 'PURGEW':
        file = watched_file
        tmpfile = watched_tmp
    elif function == 'ADDP' or function == 'REMOVEP' or function == 'PURGEP':
        file = playlist_file
        tmpfile = playlist_tmp
    elif function == 'NEWSEARCH':
        file = search_file
    else:
        return

    traktid = str(traktid)

    if function == 'ADDP':
        file_data = foldername + '=spl=' + foldertitle + '=spl=' + movieinfo + '=spl=' + traktid
    else:
        file_data = foldername + '=spl=' + foldertitle + '=spl=' + movieinfo
    file_data = file_data.replace('\n','')
    
    if (function == 'ADDW' or function == 'REMOVEW') and pagenum != '0':
        the_file = open(search_file,'w+')
        the_file.write(pagenum + '\n')
        the_file.close()

    if ('ADDF' in function and file_data not in favourite_file_data) or ('ADDW' in function and file_data not in watched_file_data) or ('ADDP' in function and file_data not in playlist_file_data):
        the_file = open(file,'a+')
        the_file.write(file_data + '\n')
        the_file.close()
        the_tmp = open(tmpfile,'a+')
        the_tmp.write(file_data + '\n')
        the_tmp.close()
        if 'ADDW' in function:
            xbmc.executebuiltin("Container.Refresh")
    elif ('REMOVEF' in function and file_data in favourite_file_data) or ('REMOVEW' in function and file_data in watched_file_data) or ('REMOVEP' in function and file_data in playlist_file_data):
        the_tmp = open(tmpfile,'r')
        the_file = open(file,'w')
        for line in the_tmp:
            if file_data not in line:
                the_file.write(line)
        the_file.close()
        the_tmp.close()

        os.remove(tmpfile)
        shutil.copyfile(file, tmpfile)
            
        xbmc.executebuiltin("Container.Refresh")
    elif function == 'NEWSEARCH' or function == 'PURGEP':
        try:
            os.remove(file)
            os.remove(tmpfile)
        except:
            the_file = open(file,'w')
            the_file.close()
            the_file = open(tmpfile,'w')
            the_file.close()
        xbmc.executebuiltin("Container.Refresh")

    return

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)
traktid = args.get('traktid', 'NOTRAKT')

try:
    the_file = open(favourite_file,'r')
    favourite_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    favourite_file_data = ''

try:
    the_file = open(watched_file,'r')
    watched_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    watched_file_data = ''

try:
    the_file = open(playlist_file,'r')
    playlist_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    playlist_file_data = ''

if mode is None:

    build_main_directory()
    
elif mode[0] == 'main_folder':

    build_movie_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])

elif mode[0] == 'kategoriak':

    build_kategoriak_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])

elif mode[0] == 'movie_folder':

    build_movie_links(args['foldername'][0], args['title'][0], args['image'][0])

elif mode[0] == 'back_one_folder':

    xbmc.executebuiltin('Action(ParentDir)')

elif mode[0] == 'favourite':

    build_file(args['foldername'][0], args['title'][0], args['info'][0], args['function'][0], args['pagenum'][0], traktid)

elif mode[0] == 'playlist_play':
    
    playlist_play(args['foldername'][0], args['title'][0], args['image'][0])

elif mode[0] == 'youtube_trailer':

    videoitem = xbmcgui.ListItem(label=args['title'][0].decode('utf-8'), thumbnailImage=base_filmezz + '/kiskep/' + args['image'][0] + '.jpg')
    videoitem.setInfo(type='Video', infoLabels={'Title': '[COLOR orange]' + args['title'][0].decode('utf-8') + u' EL\u0150ZETES[/COLOR]'})
    xbmc.Player().play(args['url'][0], videoitem)

elif mode[0] == 'Exashare':

    find_exashare_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

elif mode[0] == 'Youwatch':
    
    find_youwatch_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

elif mode[0] == 'CloudZilla':
    
    find_cloudzilla_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

elif mode[0] == 'Flashx':
    
    find_flashx_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

elif mode[0] == 'VidToMe':
    
    find_vidtome_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

elif mode[0] == 'Openload':
    
    find_openload_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

elif mode[0] == 'Allvid':
    
    find_allvid_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])

else:

    just_beta(mode[0])
