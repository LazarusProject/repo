# -*- coding: utf-8 -*-

from resources.lib import client, control

import os,sys,re,json,urllib,urlparse

tvdb_info_link = 'http://thetvdb.com/api/%s/series/%s/hu.xml' % ('MjgyM0VEMTNCQkVERURDOA=='.decode('base64'), '%s')
tvdb_by_imdb = 'http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s'
tvdb_image = 'http://thetvdb.com/banners/'
trakt_lang_link = 'http://api-v2launch.trakt.tv/movies/%s/translations/hu'
imdb_info_link = 'http://www.omdbapi.com/?i=%s&plot=full&r=json'
tmdb_info_link = 'https://api.themoviedb.org/3/movie/%s/images?api_key=%s&language=hu&include_image_language=hu,null'
tm_img_link = 'https://image.tmdb.org/t/p/w%s%s'
tm_user = control.setting('api_key')

if tm_user == '':
    tmdb_info_link = tmdb_info_link % ('%s', 'MjBiMjBiMjY1MDM3MjZhNDRkNWIzNzg4ZTA3NGE2NmE='.decode('base64'))
else:
    tmdb_info_link = tmdb_info_link % ('%s', tm_user)


def get_info(imdb, title, mtype=None):
    if ('. évad' in title or '. Évad' in title) or mtype == '2': return get_tvshow(imdb, title)
    else: return get_movie(imdb, title)


def get_movie(imdb, title):
    meta = {'fanart': ''}
    try:
            url = imdb_info_link % imdb

            item = client.request(url, timeout='10')
            item = json.loads(item)

            title = item['Title']
            title = title.encode('utf-8')
            if not title == '0': meta.update({'title': title})

            year = item['Year']
            year = year.encode('utf-8')
            if not year == '0': meta.update({'year': year})

            imdb = item['imdbID']
            if imdb == None or imdb == '' or imdb == 'N/A': imdb = '0'
            imdb = imdb.encode('utf-8')
            if not imdb == '0': meta.update({'imdb': imdb, 'code': imdb})

            premiered = item['Released']
            if premiered == None or premiered == '' or premiered == 'N/A': premiered = '0'
            premiered = re.findall('(\d*) (.+?) (\d*)', premiered)
            try: premiered = '%s-%s-%s' % (premiered[0][2], {'Jan':'01', 'Feb':'02', 'Mar':'03', 'Apr':'04', 'May':'05', 'Jun':'06', 'Jul':'07', 'Aug':'08', 'Sep':'09', 'Oct':'10', 'Nov':'11', 'Dec':'12'}[premiered[0][1]], premiered[0][0])
            except: premiered = '0'
            premiered = premiered.encode('utf-8')
            if not premiered == '0': meta.update({'premiered': premiered})

            genre = item['Genre']
            if genre == None or genre == '' or genre == 'N/A': genre = '0'
            genre = genre.replace(', ', ' / ')
            genre = genre.encode('utf-8')
            if not genre == '0': meta.update({'genre': genre})

            duration = item['Runtime']
            if duration == None or duration == '' or duration == 'N/A': duration = '0'
            duration = re.sub('[^0-9]', '', str(duration))
            duration = duration.encode('utf-8')
            if not duration == '0': meta.update({'duration': duration})
            try: meta.update({'duration': str(int(meta['duration']) * 60)})
            except: pass

            rating = item['imdbRating']
            if rating == None or rating == '' or rating == 'N/A' or rating == '0.0': rating = '0'
            rating = rating.encode('utf-8')
            if not rating == '0': meta.update({'rating': rating})

            votes = item['imdbVotes']
            try: votes = str(format(int(votes),',d'))
            except: pass
            if votes == None or votes == '' or votes == 'N/A': votes = '0'
            votes = votes.encode('utf-8')
            if not votes == '0': meta.update({'votes': votes})

            mpaa = item['Rated']
            if mpaa == None or mpaa == '' or mpaa == 'N/A': mpaa = '0'
            mpaa = mpaa.encode('utf-8')
            if not mpaa == '0': meta.update({'mpaa': mpaa})

            director = item['Director']
            if director == None or director == '' or director == 'N/A': director = '0'
            director = director.replace(', ', ' / ')
            director = re.sub(r'\(.*?\)', '', director)
            director = ' '.join(director.split())
            director = director.encode('utf-8')
            if not director == '0': meta.update({'director': director})

            writer = item['Writer']
            if writer == None or writer == '' or writer == 'N/A': writer = '0'
            writer = writer.replace(', ', ' / ')
            writer = re.sub(r'\(.*?\)', '', writer)
            writer = ' '.join(writer.split())
            writer = writer.encode('utf-8')
            if not writer == '0': meta.update({'writer': writer})

            cast = item['Actors']
            if cast == None or cast == '' or cast == 'N/A': cast = '0'
            cast = [x.strip() for x in cast.split(',') if not x == '']
            try: cast = [(x.encode('utf-8'), '') for x in cast]
            except: cast = []
            if cast == []: cast = '0'
            if not cast == '0': meta.update({'cast': cast})

            plot = item['Plot']
            if plot == None or plot == '' or plot == 'N/A': plot = '0'
            plot = client.replaceHTMLCodes(plot)
            plot = plot.encode('utf-8')
            if not plot == '0': meta.update({'plot': plot})

            poster = item['Poster']
            if poster == None or poster == '' or poster == 'N/A': poster = '0'
            if '/nopicture/' in poster: poster = '0'
            poster = re.sub('(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.', '_SX500.', poster)
            poster = poster.encode('utf-8')
            if not poster == '0': meta.update({'poster': poster})

            try:
                if not control.setting('fan_art') == 'true': raise Exception()

                url = tmdb_info_link % imdb
                item = client.request(url, timeout='10', error=True)
                item = json.loads(item)

                try:
                    poster2 = item['posters']
                    poster2 = [x for x in poster2 if x.get('iso_639_1') == 'en'] + [x for x in poster2 if not x.get('iso_639_1') == 'en']
                    poster2 = [(x['width'], x['file_path']) for x in poster2]
                    poster2 = [(x[0], x[1]) if x[0] < 300 else ('300', x[1]) for x in poster2]
                    poster2 = tm_img_link % poster2[0]
                    poster2 = poster2.encode('utf-8')
                except:
                    poster2 = '0'
                if not poster2 == '0': meta.update({'poster': poster2})
    
                try:
                    fanart = item['backdrops']
                    fanart = [x for x in fanart if x.get('iso_639_1') == 'en'] + [x for x in fanart if not x.get('iso_639_1') == 'en']
                    fanart = [x for x in fanart if x.get('width') == 1920] + [x for x in fanart if x.get('width') < 1920]
                    fanart = [(x['width'], x['file_path']) for x in fanart]
                    fanart = [(x[0], x[1]) if x[0] < 1280 else ('1280', x[1]) for x in fanart]
                    fanart = tm_img_link % fanart[0]
                    fanart = fanart.encode('utf-8')
                except:
                    fanart = '0'
                if not fanart == '0': meta.update({'fanart': fanart})
            except:
                pass


            url = trakt_lang_link % (imdb)

            try:
                item = getTrakt(url)
                item = json.loads(item)[0]

                t = item['title']
                if not (t == None or t == ''): title = t
                try: title = title.encode('utf-8')
                except: pass
                if not title == '0': meta.update({'title': title})

                t = item['overview']
                if not (t == None or t == ''): plot = t
                try: plot = plot.encode('utf-8')
                except: pass
                if not plot == '0': meta.update({'plot': plot})
            except:
                pass
            
            #meta.update({'trailer': 'plugin://script.extendedinfo/?info=playtrailer&&id=%s' % imdb})
            meta.update({'trailer': '%s?mode=trailer&title=%s&content=None' % (sys.argv[0], title)})

            return meta
    except:
        return meta


def get_tvshow(imdb, title):
    meta = {'fanart': ''}
        
    try:
        url = tvdb_by_imdb % imdb
    
        result = client.request(url, timeout='10')
    
        try: tvdb = client.parseDOM(result, 'seriesid')[0]
        except: tvdb = '0'
    
        try: name = client.parseDOM(result, 'SeriesName')[0]
        except: name = '0'
        dupe = re.compile('[***]Duplicate (\d*)[***]').findall(name)
        if len(dupe) > 0: tvdb = str(dupe[0])
    
        if tvdb == '': tvdb = '0'
    
        url = tvdb_info_link % tvdb
        item = client.request(url, timeout='10')
 

        try: year = client.parseDOM(item, 'FirstAired')[0]
        except: year = ''
        try: year = re.compile('(\d{4})').findall(year)[0]
        except: year = ''
        if year == '': year = '0'
        year = year.encode('utf-8')
        if not year == '0': meta.update({'year': year})

        try: poster = client.parseDOM(item, 'poster')[0]
        except: poster = ''
        if not poster == '': poster = tvdb_image + poster
        else: poster = '0'
        poster = client.replaceHTMLCodes(poster)
        poster = poster.encode('utf-8')

        try: banner = client.parseDOM(item, 'banner')[0]
        except: banner = ''
        if not banner == '': banner = tvdb_image + banner
        else: banner = '0'
        banner = client.replaceHTMLCodes(banner)
        banner = banner.encode('utf-8')

        try: fanart = client.parseDOM(item, 'fanart')[0]
        except: fanart = ''
        if not fanart == '': fanart = tvdb_image + fanart
        else: fanart = '0'
        fanart = client.replaceHTMLCodes(fanart)
        fanart = fanart.encode('utf-8')
        if not fanart == '0': meta.update({'fanart': fanart})

        if not poster == '0': meta.update({'poster': poster})
        elif not fanart == '0': meta.update({'poster': fanart})
        elif not banner == '0': meta.update({'poster': banner})

        try: premiered = client.parseDOM(item, 'FirstAired')[0]
        except: premiered = '0'
        if premiered == '': premiered = '0'
        premiered = client.replaceHTMLCodes(premiered)
        premiered = premiered.encode('utf-8')
        if not premiered == '0': meta.update({'premiered': premiered})

        try: studio = client.parseDOM(item, 'Network')[0]
        except: studio = ''
        if studio == '': studio = '0'
        studio = client.replaceHTMLCodes(studio)
        studio = studio.encode('utf-8')
        if not studio == '0': meta.update({'studio': studio})

        try: genre = client.parseDOM(item, 'Genre')[0]
        except: genre = ''
        genre = [x for x in genre.split('|') if not x == '']
        genre = ' / '.join(genre)
        if genre == '': genre = '0'
        genre = client.replaceHTMLCodes(genre)
        genre = genre.encode('utf-8')
        if not genre == '0': meta.update({'genre': genre})
        
        try: duration = client.parseDOM(item, 'Runtime')[0]
        except: duration = ''
        if duration == '': duration = '0'
        duration = client.replaceHTMLCodes(duration)
        duration = duration.encode('utf-8')
        if not duration == '0': meta.update({'duration': duration})
        try: meta.update({'duration': str(int(meta['duration']) * 60)})
        except: pass
        
        try: rating = client.parseDOM(item, 'Rating')[0]
        except: rating = ''
        if rating == '': rating = '0'
        rating = client.replaceHTMLCodes(rating)
        rating = rating.encode('utf-8')
        if not rating == '0': meta.update({'rating': rating})

        try: votes = client.parseDOM(item, 'RatingCount')[0]
        except: votes = ''
        if votes == '': votes = '0'
        votes = client.replaceHTMLCodes(votes)
        votes = votes.encode('utf-8')
        if not votes == '0': meta.update({'votes': votes})

        try: mpaa = client.parseDOM(item, 'ContentRating')[0]
        except: mpaa = ''
        if mpaa == '': mpaa = '0'
        mpaa = client.replaceHTMLCodes(mpaa)
        mpaa = mpaa.encode('utf-8')
        if not mpaa == '0': meta.update({'mpaa': mpaa})

        try: cast = client.parseDOM(item, 'Actors')[0]
        except: cast = ''
        cast = [x for x in cast.split('|') if not x == '']
        try: cast = [(x.encode('utf-8'), '') for x in cast]
        except: cast = []
        if len(cast) > 0: meta.update({'cast': cast})

        try: plot = client.parseDOM(item, 'Overview')[0]
        except: plot = ''
        if plot == '': plot = '0'
        plot = client.replaceHTMLCodes(plot)
        plot = plot.encode('utf-8')
        if not plot == '0': meta.update({'plot': plot}) 
        
        meta.update({'trailer': '%s?mode=trailer&title=%s&content=None' % (sys.argv[0], title)})
        return meta
    except:
        return meta


def getTrakt(url):
    try:
        url = urlparse.urljoin('http://api-v2launch.trakt.tv', url)

        headers = {'Content-Type': 'application/json', 'trakt-api-key': '03a3443d7d3d3e66f949cfd4adfda59ed7e22d182bd0c1e3a0d7e3383c3a209f', 'trakt-api-version': '2'}

        result = client.request(url, headers=headers)
        return result
    except:
        pass
