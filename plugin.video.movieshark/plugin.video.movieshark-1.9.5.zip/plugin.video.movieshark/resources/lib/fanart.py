# -*- coding: utf-8 -*-

import os,sys,re,urlparse

from resources.lib import client
from resources.lib import control

base_filmezz = control.setting('base_filmezz')


def get(title, url):
    try:
        meta = {'fanart': control.addonFanart()}

        top_url = urlparse.urljoin(base_filmezz, '/film.php?n=%s' % url)

        r = client.request(top_url)
        result = client.parseDOM(r, 'div', attrs = {'class': 'boxcont'})[0]
        result = result.replace('\n', '').replace('\r', '').replace('\t', '')
        try: result = result.encode('utf-8')
        except: pass
        
        try:
            title = re.sub('\d+\.\s*.vad', '', title.decode('utf-8')).strip()
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')
        except:
            pass
        meta.update({'title': title, 'label': title})

        try:
            imdb = re.search('/title/(tt\d{5,7})', result).group(1)
            imdb = imdb.encode('utf-8')
        except:
            imdb = '0'
        if not imdb == '0': meta.update({'imdb': imdb})

        try:
            director = re.search('Rendező.+?>([^<]+)', result).group(1).strip()
        except:
            director = '0'
        if not director == '0': meta.update({'director': director})

        try:
            cast = re.search('Szereplők\s*:\s*</b>(.+?)</', result).group(1)
            cast = cast.split('<br>')
            cast = [x.strip() for x in cast if x.strip()]
        except:
            cast = '0'
        if not cast == '0': meta.update({'cast': cast})

        try:
            genre = client.parseDOM(result, 'span', attrs = {'class': 'menuup'})
            genre = client.parseDOM(genre, 'a')
            genre = ' / '.join(genre)
            genre = genre.encode('utf-8')
        except:
            genre = '0'
        if not genre == '0': meta.update({'genre': genre})
        
        try:
            year = client.parseDOM(r, 'div', attrs = {'class': 'boxup'})[0]
            year = re.findall('\((\d{4})\)', year)[-1]
            year = year.encode('utf-8')
        except:
            year = '0'
        if not year == '0': meta.update({'year': year})
        
        try:
            rating = client.parseDOM(result, 'div', attrs = {'class': 'szoveg'})
            rating = client.parseDOM(rating, 'b')[1]
            rating = rating.encode('utf-8')
        except:
            rating = '0'
        if not rating == '0': meta.update({'rating': rating})
            
        try:
            votes = client.parseDOM(result, 'div', attrs = {'class': 'szoveg'})[0]
            votes = re.search('<br>\s*\((\d+)\s*db', votes).group(1)
            votes = votes.encode('utf-8')
        except:
            votes = '0'
        if not votes == '0': meta.update({'votes': votes})

        try:
            poster = client.parseDOM(result, 'img', ret = 'src')[0]
            poster = urlparse.urljoin(base_filmezz, poster)
            poster = poster.encode('utf-8')
        except:
            poster = '0'
        if not poster == '0': meta.update({'poster': poster})
        
        try:
            plot = client.parseDOM(result, 'div', attrs = {'id': 'desc'})[0]
            plot = re.search('/b>(.*)', plot).group(1)
            plot = plot.replace('<br>', '\n').strip()
            plot = client.replaceHTMLCodes(plot)
            plot = plot.encode('utf-8')
        except:
            plot = '0'
        if not plot == '0': meta.update({'plot': plot})
        
        try:
            youtube = re.search('www\.youtube\.com/watch\?v=([^"]+)', result).group(1)
            youtube = youtube.encode('utf-8')
        except:
            youtube = '0'
        if not youtube == '0': 
            meta.update({'youtube': youtube})

        meta.update({'trailer': '%s?mode=trailer&title=%s&id=%s' % (sys.argv[0], title, youtube)})

        return meta
    except:
        return meta
