import os
import sys
import urllib
import urllib2
import re
import urlparse
import xbmcaddon
import xbmcgui
import xbmcplugin
import time
import shutil
import json
import jsunpack
import requests
import simplejson

from openload import AADecoder

headers = [
    ['User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:38.0) Gecko/20100101 Firefox/38.0'],
    ['Accept-Encoding', 'gzip, deflate']
]

def get_video_url(page_url, premium=False, user="", password="", video_password=""):
    video_urls = []

    r = requests.get(page_url)
    data = r.content

    data = data.replace('\\/', '/') \
        .replace('&amp;', '&') \
        .replace('\xc9', 'E') \
        .replace('&#8211;', '-') \
        .replace('&#038;', '&') \
        .replace('&rsquo;', '\'') \
        .replace('\r', '') \
        .replace('\n', '') \
        .replace('\t', '') \
        .replace('&#039;', "'")

    content = ''

    patron = "<video(?:.|\s)*?<script\s[^>]*?>((?:.|\s)*?)<\/script"
    matches = re.compile(patron, re.IGNORECASE).findall(data)
    if len(matches) > 0:
        content = AADecoder(matches[0]).decode()

    if content:
        patron = r'window\.vr\s*=\s*"(.*?)\?'
        matches = re.compile(patron, re.IGNORECASE).findall(content.replace('\\', ''))
        if len(matches) > 0:
            _headers = urllib.urlencode(dict(headers))
            url = matches[0] + '|' + _headers
            video_urls.append([".mp4" + " [Openload]", url])

    return video_urls

def find_read_error(top_url):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req)
        url_content = url_handler.read()
        url_handler.close()
    except:
        return('HIBA')
    return(url_content)

def find_read_error_params(top_url, params):
    try:
        req = urllib2.Request(top_url, None, {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                                            'Accept-Language': 'hu-HU,hu;q=0.8'})
        url_handler = urllib2.urlopen(req, params)
        url_content = url_handler.read()
        url_handler.close()
    except:
        return('HIBA')
    return(url_content)

def exashare(top_url):

    r = requests.get(top_url)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers
    htopurl = urllib.quote_plus(top_url)
    
    embed_url1 = re.compile('src="([^"]+)').findall(rcontent)
    embed_url1 = embed_url1[0].replace('\n','')
    hembeded_url1 = urllib.quote_plus(embed_url1)
    header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                        'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : top_url}
    cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    r = requests.get(embed_url1, headers = header, cookies = cook)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers

    #embed_url2 = re.compile('src="([^"]+)').findall(rcontent)
    #embed_url2 = embed_url2[0].replace('\n','')
    #hembeded_url2 = urllib.quote_plus(embed_url2)
    #header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
    #                    'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : embed_url1}
    #cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    #r = requests.get(embed_url2, headers = header, cookies = cook)
    #rtext = r.text
    #lrtext = len(rtext)
    #rcontent = r.content
    #lrcontent = len(rcontent)
    #rhead = r.headers

    direct_url = re.compile('file:"(.+?mp4)"').findall(rcontent)
    direct_url = direct_url[0]

    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def vidtome(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    hidden_data = re.compile('type="(?:hidden|submit)?" name="(.+?)"\s* value="?(.+?)">').findall(url_content)

    if hidden_data:
        top_url = 'http://vidto.me/' + hidden_data[2][1] + '.html'
    time.sleep(6)

    hidden_params = {
        'op': hidden_data[0][1],
        'usr_login': '',
        'id': hidden_data[2][1],
        'fname': hidden_data[3][1],
        'referer': '',
        'hash': hidden_data[5][1],
    }
    encoded_params = urllib.urlencode(hidden_params)

    url_content = find_read_error_params(top_url, encoded_params)
    if url_content == 'HIBA':
        return

    direct_url = re.compile('<a id="lnk_download" href="(.+?)"').findall(url_content)
    direct_url = direct_url[0]
    
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def cloudzilla(top_url):
    
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    direct_url = re.compile('vurl = "(.+?)"').findall(url_content)
    direct_url = direct_url[0]

    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def youwatch(top_url):
    
    r = requests.get(top_url)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers
    htopurl = urllib.quote_plus(top_url)
    
    embed_url1 = re.compile('iframe src="([^"]+)').findall(rcontent)
    embed_url1 = embed_url1[0].replace('\n','')
    hembeded_url1 = urllib.quote_plus(embed_url1)
    header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
                        'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : top_url}
    cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    r = requests.get(embed_url1, headers = header, cookies = cook)
    rtext = r.text
    lrtext = len(rtext)
    rcontent = r.content
    lrcontent = len(rcontent)
    rhead = r.headers

    #embed_url2 = re.compile('iframe src="([^"]+)').findall(rcontent)
    #embed_url2 = embed_url2[0].replace('\n','')
    #hembeded_url2 = urllib.quote_plus(embed_url2)
    #header = {'User-agent' : 'Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.9.1.5) Gecko/20091102 Firefox/3.5.5',
    #                    'Accept-Language': 'hu-HU,hu;q=0.8', 'Referer' : embed_url1}
    #cook = {'lang' : '1', 'file_id' : '1', 'ref_url' : hembeded_url1, '_ga' : 'GA1.2.311300316.1451349698'}

    #r = requests.get(embed_url2, headers = header, cookies = cook)
    #rtext = r.text
    #lrtext = len(rtext)
    #rcontent = r.content
    #lrcontent = len(rcontent)
    #rhead = r.headers

    direct_url = re.compile('file:"(.+?mp4)"').findall(rcontent)
    direct_url = direct_url[0]

    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def flashx(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    hidden_data = re.compile('type="(?:hidden|submit)?" name="(.+?)"\s* value="?(.+?)">').findall(url_content)

    if hidden_data:
        top_url = 'http://flashx.tv/dl?' + hidden_data[2][1]    
    time.sleep(6)

    hidden_params = {
        'op': hidden_data[0][1],
        'usr_login': '',
        'id': hidden_data[2][1],
        'fname': hidden_data[3][1],
        'referer': '',
        'hash': hidden_data[5][1],
    }
    encoded_params = urllib.urlencode(hidden_params)

    url_content = find_read_error_params(top_url, encoded_params)
    if url_content == 'HIBA':
        return
    packed_data = re.compile('(eval\(function\(p,a,c,k,e,d\).+\)\))').findall(url_content)
    unpacked_data = jsunpack.unpack(packed_data[0])

    direct_url = re.compile('{file:"(.+?mp4)"').findall(unpacked_data)
    direct_url = direct_url[0]
    
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')    

def openload(top_url):
    video_urls = []

    r = requests.get(top_url)
    data = r.content
    
    data = data.replace('\\/', '/') \
        .replace('&amp;', '&') \
        .replace('\xc9', 'E') \
        .replace('&#8211;', '-') \
        .replace('&#038;', '&') \
        .replace('&rsquo;', '\'') \
        .replace('\r', '') \
        .replace('\n', '') \
        .replace('\t', '') \
        .replace('&#039;', "'")

    content = ''

    patron = "<video(?:.|\s)*?<script\s[^>]*?>((?:.|\s)*?)<\/script"
    matches = re.compile(patron, re.IGNORECASE).findall(data)
    if len(matches) > 0:
        content = AADecoder(matches[0]).decode()

    if content:
        patron = r'window\.vr=\'(.*?)\?'
        matches = re.compile(patron, re.IGNORECASE).findall(content.replace('\\', ''))
        if len(matches) > 0:
            direct_url = matches[0]
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')

def allvid(top_url):
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    packed_data = re.compile('(eval\(function\(p,a,c,k,e,d\).+\)\))').findall(url_content)
    unpacked_data = jsunpack.unpack(packed_data[0])

    direct_url = re.compile('{file:"(.+?mp4)"').findall(unpacked_data)

    if direct_url:
        return(direct_url[0])
    else:
        return('HIBA')
		
def indavideo(top_url):         
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    embed_url_hash = re.compile('indavideo\.hu/player/video/([0-9a-f]+)').findall(url_content)
   
    if embed_url_hash:
        top_url = 'http://amfphp.indavideo.hu/SYm0json.php/player.playerHandler.getVideoData/' + embed_url_hash[0]

        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return

        direct_url = re.compile('video_file":"([^"]+)"').findall(url_content)
        direct_url = direct_url[0].replace('\\','')
		
    if direct_url:
        return(direct_url)
    else:
        return('HIBA')