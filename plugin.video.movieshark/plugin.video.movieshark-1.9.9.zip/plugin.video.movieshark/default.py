import os, sys, urllib, re, urlparse, xbmcaddon, xbmcgui, xbmcplugin, shutil, json, datetime
import urlresolver

from resources.lib import client
from resources.lib import control
from resources.lib import fanart
from resources.lib import metacache
from resources.lib import cache


REMOTE_DBG = False


# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)


thisAddon = xbmcaddon.Addon(id='plugin.video.movieshark')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
sys.path.append(os.path.join(thisAddonDir, 'resources', 'media'))
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')
SettingsDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources')).decode('utf-8')
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ).decode('utf-8')


if sys.platform == 'win32':
    download_script = thisAddonDir + '\\default.py'
    favourite_file = UserDataDir + '\\favourite.dat'
    favourite_tmp = UserDataDir + '\\favourite.tmp'
    watched_file = UserDataDir + '\\watched.dat'
    watched_tmp = UserDataDir + '\\watched.tmp'
    search_file = UserDataDir + '\\search.dat'
    settings_orig = SettingsDir + '\\settingsorig.xml'
    settings_temp = SettingsDir + '\\settingstemp.xml'
    settings_file = SettingsDir + '\\settings.xml'
    usersettings_file = UserDataDir + '\\settings.xml'
else:
    download_script = thisAddonDir + '/default.py'
    favourite_file = UserDataDir + '/favourite.dat'
    favourite_tmp = UserDataDir + '/favourite.tmp'
    watched_file = UserDataDir + '/watched.dat'
    watched_tmp = UserDataDir + '/watched.tmp'
    search_file = UserDataDir + '/search.dat'
    settings_orig = SettingsDir + '/settingsorig.xml'
    settings_temp = SettingsDir + '/settingstemp.xml'
    settings_file = SettingsDir + '/settings.xml'
    usersettings_file = UserDataDir + '/settings.xml'

sort_set = ['nezettseg','abc','feltoltve','imdb']

quality_set = ['0','2','3','4','5']

language_set = ['0','2','3']

category_set = [['0', '0'], ['18', '18+'], ['akcio', u'Akci\xF3'], ['animacio', u'Anim\xE1ci\xF3'], ['anime', 'Anime'], ['csaladi', u'Csal\xE1di'], ['dokumentum', 'Dokumentum'], ['dorama', u'\xC1zsiai'], ['drama', u'Dr\xE1ma'], ['eletrajzi', u'\xC9letrajzi'], ['fantasy', 'Fantasy'], ['haborus', u'H\xE1bor\xFAs'], ['horror', 'Horror'], ['kaland', 'Kaland'],
    ['krimi', 'Krimi'], ['misztikus', 'Misztikus'], ['romantikus', 'Romantikus'], ['sci-fi', 'Sci-Fi'], ['sorozat', 'Sorozat'], ['sport', 'Sport'], ['thriller', 'Thriller'], ['tortenelmi', u'T\xF6rt\xE9nelmi'], ['vigjatek', u'V\xEDgj\xE1t\xE9k'], ['western', 'Western'], ['zenes', u'Zen\xE9s']]

def get_cookie(url, param):
    if control.setting('filmezz_login') == 'true':
        query = urlparse.urljoin(url, '/bejelentkezes.php')
        post = urllib.urlencode({ 'ref': url, 'logname': filmezz_user, 'logpass': filmezz_pass})
        cookie = client.request(query, post = post, output = 'cookie')
    else:
        cookie = client.request(url, output = 'cookie')
    return cookie

base_filmezz = control.setting('base_filmezz')
filmezz_user = control.setting('filmezz_user')
filmezz_pass = control.setting('filmezz_pass')

if control.setting('filmezz_login') == 'true' and (filmezz_pass == '' or filmezz_user == ''):
    l = control.yesnoDialog(u'K\u00E9rlek add meg a bejelentkez\u00E9shez sz\u00FCks\u00E9ges adatokat!', '', '')
    if l == 1: control.openSettings('0.12')
    sys.exit(1)

filmezz_cookie = cache.get(get_cookie, 12, base_filmezz, 'cookie')

def decode_movie_info(lang, qual):
    l = lang.lower()
    if l == 'lhun':
        movie_info = '[COLOR green] SZINKRON[/COLOR]'
    elif l == 'lsub':
        movie_info = '[COLOR red] FELIRAT[/COLOR]'
    else:
        movie_info = '[COLOR yellow] NINCS FELIRAT[/COLOR]'

    movie_info = movie_info + '[COLOR blue] %s[/COLOR]' % qual

    return movie_info

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('',u'Add meg a keresend\xF5 film c\xEDm\xE9t')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()

    return search_text

def setviewmode(mode):
    mainview = int(control.setting('mainview'))
    streamview = int(control.setting('streamview'))
    viewmodes = [0, 502, 51, 500, 501, 508, 504, 503, 515]
    
    if mode == 'main_folder':
        return viewmodes[mainview]
    elif mode == 'movie_folder':
        return viewmodes[streamview] 

def get_trailer(title, id):
    try:
        from resources.lib import trailer
        trailer.trailer().play(title, id)
    except:
        return

def build_kategoriak_directory(foldername, pagenum, action):
    for poz in range(len(category_set)):
        if not category_set[poz][0] == '0':
            try:
                url = build_url({'mode': 'main_folder', 'foldername': poz, 'pagenum': '0', 'action' : 'none'})
                li = xbmcgui.ListItem(category_set[poz][1].encode('utf-8'), iconImage=MediaDir + '\\Kategoriak.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
            except:
                pass
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_evek_directory(foldername, pagenum, action):
    for poz in range(1950,datetime.date.today().year+1,1):
        url = build_url({'mode': 'main_folder', 'foldername': poz, 'pagenum': '0', 'action' : 'none'})
        li = xbmcgui.ListItem(str(poz), iconImage=MediaDir + '\\Evek.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                     listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

    return	
	
def build_main_directory():
    url = build_url({'mode': 'main_folder', 'foldername': 'Kereses', 'pagenum': '0', 'action' : 'Firstrun'})
    li = xbmcgui.ListItem(u'Keres\xE9s', iconImage=MediaDir + '\\Kereses.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Kereses_szimpla', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Keres\xE9s szimpla', iconImage=MediaDir + '\\KeresesSimple.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
								
    url = build_url({'mode': 'main_folder', 'foldername': 'Filmek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Filmek', iconImage=MediaDir + '\\Filmek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Sorozatok', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Sorozatok', iconImage=MediaDir + '\\Sorozatok.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'kategoriak', 'foldername': 'Kategoriak', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Kateg\xF3ri\xE1k', iconImage=MediaDir + '\\Kategoriak.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
								
    url = build_url({'mode': 'evek', 'foldername': 'Evek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'\xC9vsz\xE1mok', iconImage=MediaDir + '\\Evek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Kedvencek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Kedvencek', iconImage=MediaDir + '\\Kedvencek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'openPlaylist'})
    li = xbmcgui.ListItem(u'Lej\xE1tsz\xE1si lista', iconImage=MediaDir + '\\Playlist.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    savefolder = control.setting('savefolder').decode('utf-8')
    if not savefolder == 'Nincs megadva!':
        url = savefolder
        li = xbmcgui.ListItem(u'Let\u00F6lt\u00E9sek', iconImage=MediaDir + '\\Kategoriak.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Beallitasok', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Be\xE1ll\xEDt\xE1sok', iconImage=MediaDir + '\\Beallitasok.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=False)

    try:
        os.remove(search_file)
    except:
        pass

    #viewmode()
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_movie_directory(foldername, pagenum, action):
    try:
        the_file = open(search_file,'r')
        search_text = the_file.read().replace('\n', '')
        the_file.close()
    except:
        search_text = ''


    if foldername == 'Kereses' or foldername == 'Filmek' or foldername == 'Sorozatok' or foldername.isdigit():
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        movsort = addon_settings.getSetting('msort')
        if movsort == '0':
           msort = 'feltoltve'
        elif movsort == '1':
           msort = 'abc'
        elif movsort == '2':
           msort = 'nezettseg'
        else:
           msort = 'imdbrating'

        mquality = int(addon_settings.getSetting('mquality'))
        mlanguage = int(addon_settings.getSetting('mlanguage'))
        mcategory = int(addon_settings.getSetting('mcategory'))
        myear = addon_settings.getSetting('myear')
        mtype = addon_settings.getSetting('mtype')
        msearch = addon_settings.getSetting('msearch')

        if foldername.isdigit() and len(foldername) < 4:
            mcategory = int(foldername)
     

        if (action == 'Ujkereses' or action == 'Firstrun') and search_text == '':
                os.remove(settings_file)
                shutil.copyfile(settings_temp, settings_file)

                addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
                addon_settings.setSetting('msearch', '')
                addon_settings.openSettings()

                msort = addon_settings.getSetting('msort')
                mquality = int(addon_settings.getSetting('mquality'))
                mlanguage = int(addon_settings.getSetting('mlanguage'))
                mcategory = int(addon_settings.getSetting('mcategory'))
                myear = addon_settings.getSetting('myear')
                mtype = addon_settings.getSetting('mtype')
                msearch = addon_settings.getSetting('msearch')
        if action == 'Firstrun':
                os.remove(settings_file)
                shutil.copyfile(settings_orig, settings_file)

        if action == 'none' and os.path.getsize(settings_file) == os.path.getsize(settings_temp):
                os.remove(settings_file)
                shutil.copyfile(settings_orig, settings_file)
                pagenum = '0'

        try:
                os.remove(search_file)
        except:
                pass

        if foldername == 'Filmek':
                mtype = '1'
                msearch = ''
        elif foldername == 'Sorozatok':
                mtype = '2'
                msearch = ''
        else:
            mtype = '0'

        if foldername.isdigit() and len(foldername) == 4:
            mfyear = int(foldername)
            mtype = '1'
        elif myear == 'true':
            mfyear = int(control.setting('mfyear'))
        else:
            mfyear = 0

        top_url = base_filmezz + '/kereses.php?p=' + pagenum + '&s=' + msearch.replace(' ','+') + '&w=0&o=' + msort + '&q=' + quality_set[mquality] + '&l=' + language_set[mlanguage] + '&e=' + str(mfyear) + '&c=' + category_set[mcategory][0] + '&t=' + str(mtype) + '&h=0'

        url_content = client.request(top_url, cookie=filmezz_cookie)

        result = client.parseDOM(url_content, 'ul', attrs={'class': 'row list-unstyled movie-list'})
        items = client.parseDOM(result, 'li', attrs={'class': 'col-md-2.+?'})

        for item in items:
            title = client.parseDOM(item, 'span', attrs={'class': 'title'})[0]
            title = client.replaceHTMLCodes(title).encode('utf-8')
            
            link = client.parseDOM(item, 'a', ret='href')[0]
            link = link.encode('utf-8')
            
            img = client.parseDOM(item, 'img', ret='src')[0]
            img = img.encode('utf-8')
            
            url = build_url({'mode': 'movie_folder', 'foldername': link, 'title': title, 'image': img})
            
            movie_info = client.parseDOM(item, 'ul', attrs={'class': 'list-inline cover-element movie-icons'})[0]
            lang = client.parseDOM(movie_info, 'li', ret='class')[0]
            qual = client.parseDOM(movie_info, 'li', ret='title')[1]
            movie_info = decode_movie_info(lang.strip().encode('utf-8'), qual.strip().encode('utf-8'))
 
            li = xbmcgui.ListItem(title + movie_info, iconImage=img)
            file_data = link + '=spl=' + title + '=spl=' + movie_info
            if file_data in watched_file_data:
                li.setInfo( type='Video', infoLabels={ "Title": title + movie_info, 'playcount': 1, 'overlay': 7})
            if control.setting('TMDB')=='true' and control.setting('TMDBMain')=='true':
                meta = metacache.get(fanart.get, 720, title, link, filmezz_cookie)
            else: meta = {}
            try: poster = meta['poster']
            except: poster = img
            li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
            if control.setting('fan_art') == 'true':
                if 'fanart' in meta and not meta['fanart'] == '0':
                    li.setProperty('fanart_image', meta['fanart'])
                else:
                    li.setProperty('fanart_image', poster)
            li.setInfo(type='Video', infoLabels = meta)
            url_conf1 = {'mode': 'main_folder', 'foldername': foldername, 'pagenum': '0', 'action': 'Ujkereses'}
            favourite_args1 = '?' + urllib.urlencode(url_conf1)

            url_conf = {'mode': 'favourite', 'foldername': link, 'title': title, 'info': movie_info, 'function': 'ADDF', 'pagenum' : pagenum}
            favourite_args = '?' + urllib.urlencode(url_conf)

            url_conf2 = {'mode': 'favourite', 'foldername': link, 'title': title, 'info': movie_info, 'function': 'ADDW', 'pagenum' : 'SEARCH'}
            favourite_args2 = '?' + urllib.urlencode(url_conf2)

            url_conf3 = {'mode': 'favourite', 'foldername': link, 'title': title, 'info': movie_info, 'function': 'REMOVEW', 'pagenum' : 'SEARCH'}
            favourite_args3 = '?' + urllib.urlencode(url_conf3)
				
            url_conf4 = {'mode': 'main_folder', 'foldername': 'Kereses_szimpla', 'pagenum': '0', 'action': 'none'}
            favourite_args4 = '?' + urllib.urlencode(url_conf4)

            if foldername == 'Kereses':
                li.addContextMenuItems([ (u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])
            else:
                li.addContextMenuItems([ (u'\xDAj keres\xE9s', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'),
				#(u'Szimpla keres\xE9s', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args4 + ')'),
				(u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                listitem=li, isFolder=True)

        if len(items) == 0:
                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': '0', 'action': 'Ujkereses'})
                li = xbmcgui.ListItem(u'[COLOR red]>> Nincs tal\xE1lat >>[/COLOR]', iconImage=MediaDir + '\\Kereses.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                                        listitem=li, isFolder=False)

        if pagenum != '0':
                pagenum = int(pagenum)
                pagenum -= 1
                pagenum = str(pagenum)                
                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': pagenum, 'action': 'none'})
                li = xbmcgui.ListItem(u'[COLOR blue]<< El\u0151z\u0151 oldal <<[/COLOR]', iconImage=MediaDir + '\\Elozo.png')
                poster = MediaDir + '\\Elozo.png'
                li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                                           listitem=li, isFolder=True)   
                pagenum = int(pagenum)
                pagenum += 1
                pagenum = str(pagenum) 

        if 'list-inline pagination' in url_content and 'telekkel nincs tal' not in url_content:
                pagenum = int(pagenum)
                pagenum += 1
                pagenum = str(pagenum)

                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': pagenum, 'action': 'none'})
                li = xbmcgui.ListItem(u'[COLOR green]>> K\xF6vetkez\u0151 oldal >>[/COLOR]', iconImage=MediaDir + '\\Kovetkezo.png')
                poster = MediaDir + '\\Kovetkezo.png'
                li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                   listitem=li, isFolder=True)   

        if args['pagenum'][0] != '0':
            xbmcplugin.endOfDirectory(addon_handle, updateListing = True)
        else:
            xbmcplugin.endOfDirectory(addon_handle, updateListing = False)	
        viewmode = setviewmode('main_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
        if action == 'Ujkereses':
                xbmc.executebuiltin('XBMC.Container.Refresh()')
        	

    elif foldername == 'Kereses_szimpla':
        msort = control.setting('msort')
        if search_text == '':
            search_text = open_search_panel()

        if search_text != '':
            top_url = base_filmezz + '/kereses.php?s=' + search_text.replace(' ','+') + '&o=' + str(msort)

            url_content = client.request(top_url, cookie=filmezz_cookie)

            result = client.parseDOM(url_content, 'ul', attrs={'class': 'row list-unstyled movie-list'})
            items = client.parseDOM(result, 'li', attrs={'class': 'col-md-2.+?'})
               
            for item in items:
                title = client.parseDOM(item, 'span', attrs={'class': 'title'})[0]
                title = client.replaceHTMLCodes(title).encode('utf-8')
            
                link = client.parseDOM(item, 'a', ret='href')[0]
                link = link.encode('utf-8')
            
                img = client.parseDOM(item, 'img', ret='src')[0]
                img = img.encode('utf-8')
            
                url = build_url({'mode': 'movie_folder', 'foldername': link, 'title': title, 'image': img})
            
                movie_info = client.parseDOM(item, 'ul', attrs={'class': 'list-inline cover-element movie-icons'})[0]
                lang = client.parseDOM(movie_info, 'li', ret='class')[0]
                qual = client.parseDOM(movie_info, 'li', ret='title')[1]
                movie_info = decode_movie_info(lang.strip().encode('utf-8'), qual.strip().encode('utf-8'))

                li = xbmcgui.ListItem(title + movie_info, iconImage=img)
                file_data = link + '=spl=' + title + '=spl=' + movie_info
                if control.setting('TMDB') == 'true' and control.setting('TMDBMain')=='true':
                    meta = metacache.get(fanart.get, 720, title, link, filmezz_cookie)
                else: meta = {}
                file_data = link + '=spl=' + title + '=spl=' + movie_info
                if file_data in watched_file_data:
                        meta.update=({ "Title": title + movie_info, 'playcount': 1, 'overlay': 7})
                try: poster = meta['poster']
                except: poster = img
                li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
                if control.setting('fan_art') == 'true':
                    if 'fanart' in meta and not meta['fanart'] == '0':
                        li.setProperty('fanart_image', meta['fanart'])
                    else:
                        li.setProperty('fanart_image', poster)
                li.setInfo(type='Video', infoLabels = meta)

                url_conf = {'mode': 'favourite', 'foldername': link, 'title': title, 'info': movie_info, 'function': 'ADDF', 'pagenum' : pagenum}
                favourite_args = '?' + urllib.urlencode(url_conf)

                url_conf2 = {'mode': 'favourite', 'foldername': link, 'title': title, 'info': movie_info, 'function': 'ADDW', 'pagenum' : search_text}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)

                url_conf3 = {'mode': 'favourite', 'foldername': link, 'title': title, 'info': movie_info, 'function': 'REMOVEW', 'pagenum' : search_text}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
                li.addContextMenuItems([ (u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                        listitem=li, isFolder=True)

            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
        viewmode = setviewmode('main_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)		
		
    elif foldername == 'Kedvencek':
        try:
            the_file = open(favourite_file,'r')
            for line in the_file:
                movie_data = line.split('=spl=')
                img = base_filmezz + '/nagykep/' + re.search('n=([^\&]+)', movie_data[0]).group(1) + '.jpg'
                url = build_url({'mode': 'movie_folder', 'foldername': movie_data[0], 'title': movie_data[1], 'image': img})
                li = xbmcgui.ListItem(movie_data[1].decode('utf-8') + movie_data[2], iconImage=img)
                file_data = movie_data[0] + '=spl=' + movie_data[1] + '=spl=' + movie_data[2].replace('\n', '')
                if control.setting('TMDB') == 'true' and control.setting('TMDBMain')=='true':
                    meta = metacache.get(fanart.get, 720, movie_data[1], movie_data[0], filmezz_cookie)
                else: meta = {}
                file_data = movie_data[0] + '=spl=' + movie_data[1] + '=spl=' + movie_data[2].replace('\n', '')
                if file_data in watched_file_data:
                    meta.update=({ "Title": movie_data[1].decode('utf-8') + movie_data[2], 'playcount': 1, 'overlay': 7})
                try: poster = meta['poster']
                except: poster = img
                li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
                if control.setting('fan_art') == 'true':
                    if 'fanart' in meta and not meta['fanart'] == '0':
                        li.setProperty('fanart_image', meta['fanart'])
                    else:
                        li.setProperty('fanart_image', poster)
                li.setInfo(type='Video', infoLabels = meta)
                url_conf = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'REMOVEF', 'pagenum' : '0'}
                favourite_args = '?' + urllib.urlencode(url_conf)
            
                url_conf2 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2].replace('\n', ''), 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2].replace('\n', ''), 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
                li.addContextMenuItems([ (u'T\xF6rles a MovieShark kedvencekb\u0151l', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)

            the_file.close()
            xbmcplugin.endOfDirectory(addon_handle)          
        except:
            xbmcplugin.endOfDirectory(addon_handle)
        viewmode = setviewmode('main_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)

    elif foldername == 'Beallitasok':
        if os.path.getsize(settings_file) == os.path.getsize(settings_temp):
            os.remove(settings_file)
            shutil.copyfile(settings_orig, settings_file)
        control.openSettings()

    try:
        os.remove(search_file)
    except:
        pass
		
    return

def find_videourl(foldername, foldertitle, folderimage, isdownload, meta):
    try:
        error = '0'
        domain = '0'
        control.busy()

        top_url = base_filmezz + '/link_to.php?id=' + foldername
        r = client.request(top_url, output='headers', redirect=False, cookie=filmezz_cookie).headers
        try: location = [i.replace('Location:', '').strip() for i in r if 'Location:' in i][0]
        except: location = client.request(top_url, cookie=filmezz_cookie)
        if not location.startswith('http'):
            try: location = client.parseDOM(location, 'iframe', ret='src')[0]
            except: location = client.parseDOM(location, 'IFRAME', ret='SRC')[0]
        if not location.startswith('http'): raise Exception()
        location = client.replaceHTMLCodes(location)
        u = re.sub(r'^"|"$', '', location).strip()

        direct_url = None

        hmf = urlresolver.HostedMediaFile(url=u, include_disabled=True, include_universal=False)

        if hmf.valid_url() == True: 
            domain = hmf._domain
            try: direct_url = hmf.resolve()
            except Exception as e:
                error = 'Hiba: %s' % e

        if not error == '0' or direct_url == False or direct_url == None: raise Exception()

        control.idle()

        if isdownload == 'DOWNLOAD':
            savefolder = control.setting('savefolder').decode('utf-8')
        
            if savefolder == 'Nincs megadva!':
                xbmcgui.Dialog().ok(u'Let\xF6lt\xE9si hiba', u'Meg kell adnod egy let\xF6lt\xE9si k\xF6nyvt\xE1rat a be\xE1ll\xEDt\xE1sokban!')
                return
            from resources.lib import downloader
            try: 
                downloader.download(foldertitle, folderimage, direct_url)
                return
            except: 
                raise Exception()

        else:
            videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=folderimage)
            if not control.setting('TRAKT') == 'true':
                meta = {}
            else:
                meta = eval(meta)
            videoitem.setInfo(type='Video', infoLabels = meta)
            xbmc.Player().play(direct_url, videoitem)

            control.resolve(int(sys.argv[1]), True, videoitem)
            
            if 'imdb' in meta:
                control.window.setProperty('script.trakt.ids', json.dumps({'imdb': meta['imdb']}))
    except:
        control.idle()
        control.infoDialog(u'Lej\u00E1tsz\u00E1s sikertelen', domain)

def build_movie_links(foldername, foldertitle, folderimage):
    top_url = urlparse.urljoin(base_filmezz, foldername)

    meta = metacache.get(fanart.get, 720, foldertitle, foldername, filmezz_cookie)

    try: poster = meta['poster']
    except: poster = urlparse.urljoin(base_filmezz, olderimage)

    try: youtube_id = meta['youtube']
    except: youtube_id = '0'

    url_content = client.request(top_url, cookie=filmezz_cookie)
    
    result = client.parseDOM(url_content, 'ul', attrs={'class': 'list-unstyled table-horizontal url-list'})[0]
    result = result.replace('\n', '').replace('\r', '').replace('\t', '')
    items = result.split('<li>')

    hostDict = getConstants()
    locDict = [(i.rsplit('.', 1)[0], i) for i in hostDict]

    try:
        if not control.setting('trailer') == 'true': raise Exception()
        url = build_url({'mode': 'trailer', 'title': foldertitle, 'id': youtube_id})
        li = xbmcgui.ListItem('[COLOR orange]' + foldertitle.decode('utf-8') + u' EL\u0150ZETES[/COLOR]', iconImage=base_filmezz + '/nagykep/' + folderimage + '.jpg')
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
        li.setProperty('fanart_image', meta['fanart'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)
    except:
        pass

    for item in items:
        try:
            host = re.search('/ul>([^<]+)', item).group(1)
            host = host.strip().lower().rsplit('.', 1)[0]
            host = [x[1] for x in locDict if host == x[0]][0]
            if not host in hostDict: raise Exception()
            vid_id = re.search('\?id=(\d+)', item).group(1).encode('utf-8')
            try: serie_info = re.search('(\d+)\.?\s+epiz', item).group(1).encode('utf-8')
            except: serie_info = '-1'
            if not serie_info == '-1':
                try: tseason = str(int(foldername.rsplit('-', 2)[-2]))
                except: tseason = '1'
                meta.update({'tvshowtitle': meta['title'], 'type': 'episode', 'season': tseason, 'mediatype': 'episode', 'episode': serie_info})
            url_conf = {'mode': 'find_directurl', 'foldername': vid_id, 'title': foldertitle, 'image': folderimage, 'isdownload' : ' ', 'meta' : meta}
            url = build_url(url_conf)
            url_conf = {'mode': 'find_directurl', 'foldername': vid_id, 'title': foldertitle + ' ' + serie_info, 'image': folderimage, 'isdownload' : 'DOWNLOAD', 'meta' : meta}
            download_args = '?' + urllib.urlencode(url_conf)
            
            try:
                info = client.parseDOM(item, 'div', attrs={'class': 'col-sm-4 col-xs-12'})[0]
                info = client.replaceHTMLCodes(info)
                info = info.strip().encode('utf-8')
            except:
                info = ''
            
            lang = client.parseDOM(item, 'li', ret='class')[0]
            qual = client.parseDOM(item, 'li', ret='title')[1]
            movie_info = decode_movie_info(lang.strip().encode('utf-8'), qual.strip().encode('utf-8'))

            if not serie_info == '-1':
                content = 'episodes'
                li = xbmcgui.ListItem(foldertitle + ' ' + serie_info + u'. epiz\xF3d'.encode('utf-8') + movie_info + ' ' + host.upper(),
                                    iconImage=folderimage)
            else:
                content = 'movies'
                li = xbmcgui.ListItem(foldertitle + movie_info + ' ' + host.upper() + '[COLOR cyan] %s[/COLOR]' % info,
                                    iconImage=folderimage)
            file_data = vid_id + '=spl=' + foldertitle + '=spl=' + folderimage
            if file_data in watched_file_data:                           
                meta.update({ "Title": foldertitle + folderimage, 'playcount': 1, 'overlay': 7})
            li.setArt({'icon': poster, 'thumb': poster, 'poster': poster})
            if control.setting('fan_art') == 'true':
                if 'fanart' in meta and not meta['fanart'] == '0':
                    li.setProperty('fanart_image', meta['fanart'])
                else:
                    li.setProperty('fanart_image', poster)
            li.setInfo(type='Video', infoLabels = meta)

            url_conf1 = {'mode': 'queueItem'}
            favourite_args1 = '?' + urllib.urlencode(url_conf1)

            url_conf2 = {'mode': 'favourite', 'foldername': vid_id, 'title': foldertitle, 'info': folderimage, 'function': 'ADDW', 'pagenum' : '0'}
            favourite_args2 = '?' + urllib.urlencode(url_conf2)

            url_conf3 = {'mode': 'favourite', 'foldername': vid_id, 'title': foldertitle, 'info': folderimage, 'function': 'REMOVEW', 'pagenum' : '0'}
            favourite_args3 = '?' + urllib.urlencode(url_conf3)

            li.addContextMenuItems([ (u'Vide\xF3 Let\xF6lt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + download_args + ')'), 
			(u'Hozz\xE1ad\xE1s a lej\xE1tsz\xE1si list\xE1hoz', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'), 
			(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
			(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')'),
			(u'Lej\xE1tsz\xF3 kiv\xE1laszt\xE1sa','Action(SwitchPlayer)')])

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)
            control.content(int(sys.argv[1]), 'episodes')
        except:
            pass
        #viewmode()

    xbmcplugin.endOfDirectory(addon_handle)
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)

    return

def getConstants():
    hostcapDict = ['kingfiles', 'openload', 'thevideo', 'torba', 'flashx', 'streamin']
    try:
        try: hosts = urlresolver.relevant_resolvers(order_matters=True)
        except: hosts = urlresolver.plugnplay.man.implementors(urlresolver.UrlResolver)
        hostDict = [i.domains for i in hosts if not '*' in i.domains]
        hostDict = [i.lower() for i in reduce(lambda x, y: x+y, hostDict)]
        hostDict += [i.name.lower() for i in hosts if not '*' in i.domains]
        hostDict.append('vidtome')
        hostDict = [i.split('.')[0] for i in hostDict]
        hostDict = list(set(hostDict))
        if control.setting('hostcap') == 'true':
            hostDict = [i for i in hostDict if not i in hostcapDict]
    except:
        hostDict = []
    return hostDict

def build_file(foldername, foldertitle, movieinfo, function, pagenum, traktid):
    
    if function == 'ADDF' or function == 'REMOVEF' or function == 'PURGEF':
        file = favourite_file
        tmpfile = favourite_tmp
    elif function == 'ADDW' or function == 'REMOVEW' or function == 'PURGEW':
        file = watched_file
        tmpfile = watched_tmp
    elif function == 'NEWSEARCH':
        file = search_file
    else:
        return

    file_data = foldername + '=spl=' + foldertitle + '=spl=' + movieinfo
    file_data = file_data.replace('\n','')
    
    if (function == 'ADDW' or function == 'REMOVEW') and pagenum != '0':
        the_file = open(search_file,'w+')
        the_file.write(pagenum + '\n')
        the_file.close()

    if ('ADDF' in function and file_data not in favourite_file_data) or ('ADDW' in function and file_data not in watched_file_data):
        the_file = open(file,'a+')
        the_file.write(file_data + '\n')
        the_file.close()
        the_tmp = open(tmpfile,'a+')
        the_tmp.write(file_data + '\n')
        the_tmp.close()
        if 'ADDW' in function:
            xbmc.executebuiltin("Container.Refresh")
    elif ('REMOVEF' in function and file_data in favourite_file_data) or ('REMOVEW' in function and file_data in watched_file_data):
        the_tmp = open(tmpfile,'r')
        the_file = open(file,'w')
        for line in the_tmp:
            if file_data not in line:
                the_file.write(line)
        the_file.close()
        the_tmp.close()

        os.remove(tmpfile)
        shutil.copyfile(file, tmpfile)
            
        xbmc.executebuiltin("Container.Refresh")
    elif function == 'NEWSEARCH' or function == 'PURGEP':
        try:
            os.remove(file)
            os.remove(tmpfile)
        except:
            the_file = open(file,'w')
            the_file.close()
            the_file = open(tmpfile,'w')
            the_file.close()
        xbmc.executebuiltin("Container.Refresh")

    return

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)
meta = args.get('meta', 'NOTRAKT')

try:
    the_file = open(favourite_file,'r')
    favourite_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    favourite_file_data = ''

try:
    the_file = open(watched_file,'r')
    watched_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    watched_file_data = ''

if mode is None:

    build_main_directory()
    
elif mode[0] == 'main_folder':

    build_movie_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])

elif mode[0] == 'kategoriak':

    build_kategoriak_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])

elif mode[0] == 'evek':

    build_evek_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])
	
elif mode[0] == 'movie_folder':

    build_movie_links(args['foldername'][0], args['title'][0], args['image'][0])

elif mode[0] == 'back_one_folder':

    xbmc.executebuiltin('Action(ParentDir)')

elif mode[0] == 'favourite':

    build_file(args['foldername'][0], args['title'][0], args['info'][0], args['function'][0], args['pagenum'][0], meta)

elif mode[0] == 'find_directurl':
    
    find_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['meta'][0])

elif mode[0] == 'trailer':
    
    get_trailer(args['title'][0], args['id'][0])
    
elif mode[0] == 'clear_cache':
    from resources.lib import cache 
    cache.clear()

elif mode[0] == 'clear_meta':
    metacache.clear()

elif mode[0] == 'queueItem':
    control.queueItem()
    
elif mode[0] == 'openPlaylist':
    control.openPlaylist()
