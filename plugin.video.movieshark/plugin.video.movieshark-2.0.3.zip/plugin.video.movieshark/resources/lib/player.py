# -*- coding: utf-8 -*-

import sys,json,xbmc
import hashlib

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

from resources.lib import control


class player(xbmc.Player):
    def __init__ (self):
        xbmc.Player.__init__(self)


    def run(self, title, year, meta, poster, url):
        try:
            control.sleep(200)

            self.totalTime = 0 ; self.currentTime = 0

            self.name = title ; self.year = year

            self.DBID = None

            self.offset = bookmarks().get(self.name, self.year)

            item = control.item(path=url)
            item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'tvshow.poster': poster, 'season.poster': poster})
            item.setInfo(type='Video', infoLabels = meta)
            
            control.player.play(url, item)
            #control.resolve(int(sys.argv[1]), True, item)

            if control.setting('TRAKT') == 'true':
                control.window.setProperty('script.trakt.ids', json.dumps({'imdb': meta['imdb']}))
            
            self.keepPlaybackAlive()
            
            control.window.clearProperty('script.trakt.ids')
        except:
            return
    
    
    def keepPlaybackAlive(self):
        for i in range(0, 240):
            if self.isPlayingVideo(): break
            xbmc.sleep(1000)

        while self.isPlayingVideo():
            try:
                self.totalTime = self.getTotalTime()
                self.currentTime = self.getTime()
            except:
                pass
            xbmc.sleep(2000)
    

    def idleForPlayback(self):
        for i in range(0, 200):
            if control.condVisibility('Window.IsActive(busydialog)') == 1: control.idle()
            else: break
            control.sleep(100)


    def onPlayBackStarted(self):
        control.execute('Dialog.Close(all,true)')
        if not self.offset == '0': self.seekTime(float(self.offset))
        self.idleForPlayback()


    def onPlayBackStopped(self):
        bookmarks().reset(self.currentTime, self.totalTime, self.name, self.year)


    def onPlayBackEnded(self):
        self.onPlayBackStopped()


class bookmarks:
    def get(self, name, year='0'):
        try:
            offset = '0'

            if not control.setting('bookmarks') == 'true': raise Exception()

            idFile = hashlib.md5()
            for i in name: idFile.update(str(i))
            for i in year: idFile.update(str(i))
            idFile = str(idFile.hexdigest())

            dbcon = database.connect(control.bookmarksFile)
            dbcur = dbcon.cursor()
            dbcur.execute("SELECT * FROM bookmark WHERE idFile = '%s'" % idFile)
            match = dbcur.fetchone()
            self.offset = str(match[1])
            dbcon.commit()

            if self.offset == '0': raise Exception()

            minutes, seconds = divmod(float(self.offset), 60) ; hours, minutes = divmod(minutes, 60)
            label = '%02d:%02d:%02d' % (hours, minutes, seconds)
            label = (u'Folytat\u00E1s innen: %s' % label).encode('utf-8')

            try: yes = control.dialog.contextmenu([label, u'Lej\u00E1tsz\u00E1s az elej\u00E9r\u0151l'.encode('utf-8'), ])
            except: yes = control.yesnoDialog(label, '', '', str(name), u'Folytat\u00E1s'.encode('utf-8'), u'Lej\u00E1tsz\u00E1s az elej\u00E9r\u0151l'.encode('utf-8'))

            if yes: self.offset = '0'

            return self.offset
        except:
            return offset


    def reset(self, currentTime, totalTime, name, year='0'):
        try:
            if not control.setting('bookmarks') == 'true': raise Exception()

            timeInSeconds = str(currentTime)
            ok = int(currentTime) > 180 and (currentTime / totalTime) <= .92

            idFile = hashlib.md5()
            for i in name: idFile.update(str(i))
            for i in year: idFile.update(str(i))
            idFile = str(idFile.hexdigest())

            control.makeFile(control.dataPath)
            dbcon = database.connect(control.bookmarksFile)
            dbcur = dbcon.cursor()
            dbcur.execute("CREATE TABLE IF NOT EXISTS bookmark (""idFile TEXT, ""timeInSeconds TEXT, ""UNIQUE(idFile)"");")
            dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
            if ok: dbcur.execute("INSERT INTO bookmark Values (?, ?)", (idFile, timeInSeconds))
            dbcon.commit()
        except:
            pass
