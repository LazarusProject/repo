import os, sys, urllib, urllib2, re, urlparse, xbmcaddon, xbmcgui, xbmcplugin, shutil, msresolver
from resources.lib import client, cache, control

#TRAKT
#josorozat --- ids = {"imdb": "tt4016454", "status": "Continuing", "season": "1", "tvshowtitle": "Supergirl", "episode": "2"}
#jomovie --- ids = {"imdb": "tt2379713", "year": "2015", "status": "Continuing", "title": "Spectre"}

thisAddon = xbmcaddon.Addon(id='plugin.video.movieshark')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
sys.path.append(os.path.join(thisAddonDir, 'resources', 'media'))
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')
SettingsDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources')).decode('utf-8')
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ).decode('utf-8')


if sys.platform == 'win32':
    download_script = thisAddonDir + '\\default.py'
    favourite_file = UserDataDir + '\\favourite.dat'
    favourite_tmp = UserDataDir + '\\favourite.tmp'
    watched_file = UserDataDir + '\\watched.dat'
    watched_tmp = UserDataDir + '\\watched.tmp'
    playlist_file = UserDataDir + '\\playlist.dat'
    playlist_tmp = UserDataDir + '\\playlist.tmp'
    search_file = UserDataDir + '\\search.dat'
    settings_orig = SettingsDir + '\\settingsorig.xml'
    settings_temp = SettingsDir + '\\settingstemp.xml'
    settings_file = SettingsDir + '\\settings.xml'
    usersettings_file = UserDataDir + '\\settings.xml'
else:
    download_script = thisAddonDir + '/default.py'
    favourite_file = UserDataDir + '/favourite.dat'
    favourite_tmp = UserDataDir + '/favourite.tmp'
    watched_file = UserDataDir + '/watched.dat'
    watched_tmp = UserDataDir + '/watched.tmp'
    playlist_file = UserDataDir + '/playlist.dat'
    playlist_tmp = UserDataDir + '/playlist.tmp'
    search_file = UserDataDir + '/search.dat'
    settings_orig = SettingsDir + '/settingsorig.xml'
    settings_temp = SettingsDir + '/settingstemp.xml'
    settings_file = SettingsDir + '/settings.xml'
    usersettings_file = UserDataDir + '/settings.xml'

sort_set = ['nezettseg','abc','feltoltve','imdb']

quality_set = ['0','2','3','4']

language_set = ['0','2','3']

category_set = ['0','18','akcio','animacio','anime','csaladi','dokumentum','drama','eletrajzi','fantasy','haborus','horror','kaland',
                'krimi','misztikus','romantikus','sci-fi','sorozat','sport','thriller','tortenelmi','vigjatek','western','zenes']

base_filmezz = thisAddon.getSetting('base_filmezz')
api_key = thisAddon.getSetting('api_key')

def gettrakt(imdbnum):
    if imdbnum[0] != '':
        top_url = 'http://akas.imdb.com/title/' + imdbnum[0]
        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return
        else:
            title = re.compile('<title>([^<]*)').findall(url_content)
            titleorig = re.compile('class="title-extra" itemprop="name">([^<]+)').findall(url_content)
            if titleorig:
                titleorig = re.compile('"([^"]+)').findall(titleorig[0])
                title.append(titleorig[0])
            return(title)
	return('')

def decode_movie_info(movie_info_data):
    if movie_info_data[1] == '3':
        movie_info = '[COLOR green] SZINKRON[/COLOR]'
    elif movie_info_data[1] == '2':
        movie_info = '[COLOR red] FELIRAT[/COLOR]'
    elif movie_info_data[1] == '1':
        movie_info = '[COLOR yellow] NINCS FELIRAT[/COLOR]'
    else:
        movie_info = '[COLOR tan] ISMERETLEN[/COLOR]'

    if movie_info_data[0] == '4':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[0] == '3':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[0] == '2':
        movie_info = movie_info + '[COLOR blue] TV[/COLOR]'
    elif movie_info_data[0] == '1':
        movie_info = movie_info + '[COLOR blue] CAM[/COLOR]'
    else:
        movie_info = movie_info + '[COLOR tan] ISMERETLEN[/COLOR]'

    return movie_info

def decode_movie_info_neg(movie_info_data):
    if movie_info_data[0] == '3':
        movie_info = '[COLOR green] SZINKRON[/COLOR]'
    elif movie_info_data[0] == '2':
        movie_info = '[COLOR red] FELIRAT[/COLOR]'
    elif movie_info_data[0] == '1':
        movie_info = '[COLOR yellow] NINCS FELIRAT[/COLOR]'
    else:
        movie_info = '[COLOR tan] ISMERETLEN[/COLOR]'

    if movie_info_data[1] == '4':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[1] == '3':
        movie_info = movie_info + '[COLOR blue] DVD[/COLOR]'
    elif movie_info_data[1] == '2':
        movie_info = movie_info + '[COLOR blue] TV[/COLOR]'
    elif movie_info_data[1] == '1':
        movie_info = movie_info + '[COLOR blue] CAM[/COLOR]'
    else:
        movie_info = movie_info + '[COLOR tan] ISMERETLEN[/COLOR]'
		
    return movie_info

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('',u'Add meg a keresend\xF5 film c\xEDm\xE9t')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()

    return search_text

def find_read_error(top_url):
    try:
        url_content = client.request(top_url)
    except:
        url_content = 'HIBA'
        control.infoDialog(u'Az internetes adatb\xE1zishoz val\xF3 csatlakoz\xE1s sikertelen!', time=5000)
    return url_content

def just_removed(file_host):
    control.infoDialog(u'Vide\xF3 c\xEDme: ' + file_host.decode('utf-8'), u'A keresett vide\xF3t elt\xE1vol\xEDtott\xE1k!', time=5000) 
    return

def setviewmode(mode):
    addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
    mainview = int(addon_settings.getSetting('mainview'))
    streamview = int(addon_settings.getSetting('streamview'))

    if mode == 'main_folder':
        if mainview == 1:
            mainview = 502
        elif mainview == 2:
            mainview = 51
        elif mainview == 3:
            mainview = 500
        elif mainview == 4:
            mainview = 501
        elif mainview == 5:
            mainview = 508
        elif mainview == 6:
            mainview = 504
        elif mainview == 7:
            mainview = 503
        elif mainview == 8:
            mainview = 515	
        else:
            mainview = 0
        return(mainview)
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %mainview)
    elif mode == 'movie_folder':
        if streamview == 1:
            streamview = 502
        elif streamview == 2:
            streamview = 51
        elif streamview == 3:
            streamview = 500
        elif streamview == 4:
            streamview = 501
        elif streamview == 5:
            streamview = 508
        elif streamview == 6:
            streamview = 504
        elif streamview == 7:
            streamview = 503
        elif streamview == 8:
            streamview = 515
        else:
            streamview = 0
        return(streamview)			
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %streamview)
 
    return

def find_fanart(imdbnum, videotype):
    fanart_info = [' ',' ','0',' ']
    image_url = ''
    year = ''
    genre = ''
    genre2 = ''
    overview = ''

    imdbnum = re.compile('([0-9]+)').findall(imdbnum)
    imdbnum = 'tt' + imdbnum[0]

    top_url = 'http://api.themoviedb.org/3/find/' + imdbnum +'?api_key=' + api_key + '&external_source=imdb_id&language=hu'
    
    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    if '"overview":null' in url_content:
        top_url = 'http://api.themoviedb.org/3/find/' + imdbnum +'?api_key=' + api_key + '&external_source=imdb_id&language=en'
        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return

    if '"overview":null' not in url_content:
        if '"release_date"' in url_content:
            if '"release_date":null' not in url_content:
                year = re.compile('release_date":"([0-9]+)').findall(url_content)
        if '"first_air_date"' in url_content:
            if '"first_air_date":null' not in url_content:
                year = re.compile('"first_air_date":"([0-9]+)').findall(url_content)
        if '"backdrop_path":null' not in url_content:
            image_url = re.compile('backdrop_path":"([^"]+)').findall(url_content)
        else:
            if '"poster_path":null' not in url_content:
                image_url = re.compile('"poster_path":"([^"]+)').findall(url_content)

        overview = re.compile('overview":"(.+?(?=\",\"))').findall(url_content)
        genre = re.compile('vote_average":([^,]+)').findall(url_content)
        genre2 = re.compile('vote_count":([^"}"]+)').findall(url_content)
        if genre:
            genre = 'Pontszam: ' + genre[0]
        if genre2:
            genre = genre + ' Szavazat: ' + genre2[0]
		
        if image_url:
            fanart_info[0] = 'https://image.tmdb.org/t/p/w780' + image_url[0]

        if overview:
            fanart_info[1] = overview[0].strip(' \t\n\r')

        if year:
            fanart_info[2] = year[0]

        if genre:
            fanart_info[3] = genre
            
    return fanart_info

def decode_youtube_trailer(title, image, youtube_id):
    top_url = 'http://youtube.com/get_video_info?video_id=' + youtube_id
    try:
        url_content = find_read_error(top_url)
        if url_content == 'HIBA':
            return
    
        youtube_fmt = re.compile('url_encoded_fmt_stream_map=([^&]+)').findall(url_content)
        if youtube_fmt:
            url_content = urllib.unquote(youtube_fmt[0]).decode('utf-8')
            youtube_url_base = re.compile('url=([^&]+)').findall(url_content)
            youtube_url = urllib.unquote(youtube_url_base[0]).decode('utf-8')
            direct_link = urllib.unquote(youtube_url).decode('utf-8')
        videoitem = xbmcgui.ListItem(label=title.decode('utf-8'), thumbnailImage=base_filmezz + '/kiskep/' + image + '.jpg')
        videoitem.setInfo(type='Video', infoLabels={'Title': '[COLOR orange]' + title.decode('utf-8') + u' EL\u0150ZETES[/COLOR]'})
        xbmc.Player().play(direct_link, videoitem)
    except:
        return
	
def build_kategoriak_directory(foldername, pagenum, action):
    for poz in range(len(category_set)):
        if category_set[poz] != '0':
            url = build_url({'mode': 'main_folder', 'foldername': poz, 'pagenum': '0', 'action' : 'none'})
            li = xbmcgui.ListItem(category_set[poz], iconImage=MediaDir + '\\Kategoriak.png')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_evek_directory(foldername, pagenum, action):
    addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
    for poz in range(1950,int(addon_settings.getSetting('mfyear'))+1,1):
        url = build_url({'mode': 'main_folder', 'foldername': poz, 'pagenum': '0', 'action' : 'none'})
        li = xbmcgui.ListItem(str(poz), iconImage=MediaDir + '\\Evek.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                     listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

    return	
	
def build_main_directory():
    url = build_url({'mode': 'main_folder', 'foldername': 'Kereses', 'pagenum': '0', 'action' : 'Firstrun'})
    li = xbmcgui.ListItem(u'Keres\xE9s', iconImage=MediaDir + '\\Kereses.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Kereses_szimpla', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Keres\xE9s szimpla', iconImage=MediaDir + '\\KeresesSimple.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
								
    url = build_url({'mode': 'main_folder', 'foldername': 'Filmek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Filmek', iconImage=MediaDir + '\\Filmek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Sorozatok', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Sorozatok', iconImage=MediaDir + '\\Sorozatok.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'kategoriak', 'foldername': 'Kategoriak', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Kateg\xF3ri\xE1k', iconImage=MediaDir + '\\Kategoriak.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
								
    url = build_url({'mode': 'evek', 'foldername': 'Evek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'\xC9vsz\xE1mok', iconImage=MediaDir + '\\Evek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Kedvencek', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Kedvencek', iconImage=MediaDir + '\\Kedvencek.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'main_folder', 'foldername': 'Playlist', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Lej\xE1tsz\xE1si lista', iconImage=MediaDir + '\\Playlist.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    
    addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
    savefolder = addon_settings.getSetting('savefolder').decode('utf-8')
    if not savefolder == 'Nincs megadva!':
        url = savefolder
        li = xbmcgui.ListItem(u'Let\u00F6lt\u00E9sek', iconImage=MediaDir + '\\Kategoriak.png')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=True)
								
    url = build_url({'mode': 'main_folder', 'foldername': 'Beallitasok', 'pagenum': '0', 'action' : 'none'})
    li = xbmcgui.ListItem(u'Be\xE1ll\xEDt\xE1sok', iconImage=MediaDir + '\\Beallitasok.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=False)

    try:
        os.remove(search_file)
    except:
        pass

    #viewmode()
    xbmcplugin.endOfDirectory(addon_handle)

    return

def build_movie_directory(foldername, pagenum, action):
    try:
        the_file = open(search_file,'r')
        search_text = the_file.read().replace('\n', '')
        the_file.close()
    except:
        search_text = ''

    imdbnum = ''

    if foldername == 'Kereses' or foldername == 'Filmek' or foldername == 'Sorozatok' or foldername.isdigit():
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        msort = int(addon_settings.getSetting('msort'))
        mquality = int(addon_settings.getSetting('mquality'))
        mlanguage = int(addon_settings.getSetting('mlanguage'))
        mcategory = int(addon_settings.getSetting('mcategory'))
        myear = addon_settings.getSetting('myear')
        mtype = addon_settings.getSetting('mtype')
        msearch = addon_settings.getSetting('msearch')
     
        if foldername.isdigit() and len(foldername) < 4:
            mcategory = int(foldername)
           		

        if (action == 'Ujkereses' or action == 'Firstrun') and search_text == '':
                os.remove(settings_file)
                shutil.copyfile(settings_temp, settings_file)

                addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
                addon_settings.setSetting('msearch', '')
                addon_settings.openSettings()

                msort = int(addon_settings.getSetting('msort'))
                mquality = int(addon_settings.getSetting('mquality'))
                mlanguage = int(addon_settings.getSetting('mlanguage'))
                mcategory = int(addon_settings.getSetting('mcategory'))
                myear = addon_settings.getSetting('myear')
                mtype = addon_settings.getSetting('mtype')
                msearch = addon_settings.getSetting('msearch')
        if action == 'Firstrun':
                os.remove(settings_file)
                shutil.copyfile(settings_orig, settings_file)

        if action == 'none' and os.path.getsize(settings_file) == os.path.getsize(settings_temp):
                os.remove(settings_file)
                shutil.copyfile(settings_orig, settings_file)
                pagenum = '0'

        try:
                os.remove(search_file)
        except:
                pass

        if foldername == 'Filmek':
                mtype = '1'
                msearch = ''
        elif foldername == 'Sorozatok':
                mtype = '2'
                msearch = ''
        else:
                mtype = '0'
				
        if foldername.isdigit() and len(foldername) == 4:
            mfyear = int(foldername)
            mtype = '1'			
        elif myear == 'true':
            mfyear = int(addon_settings.getSetting('mfyear'))
        else:
            mfyear = 0

        top_url = base_filmezz + '/kereses.php?p=' + pagenum + '&s=' + msearch.replace(' ','+') + '&w=0&o=' + sort_set[msort] + '&q=' + quality_set[mquality] + '&l=' + language_set[mlanguage] + '&e=' + str(mfyear) + '&c=' + category_set[mcategory] + '&t=' + str(mtype) + '&h=0'

        url_content = cache.get(find_read_error, 12, top_url)
        if url_content == 'HIBA':
                return

        movie_names = re.compile('<center><b>(.+)</b>').findall(url_content)
        if foldername == 'Filmek':
                movie_urls = re.compile('film\.php\?n=([^&]+)').findall(url_content)
        else:
                #movie_urls = re.compile('film\.php\?n=([0-9a-zA-Z.-]+)').findall(url_content)
				movie_urls = re.compile('film\.php\?n=([^&]+)').findall(url_content)

        movie_info_data = re.compile('qual\/([0-9]).+?([0-9])\.gif', re.DOTALL).findall(url_content)

        for poz in range(len(movie_urls)):
                url = build_url({'mode': 'movie_folder', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'image': movie_urls[poz]})
                movie_info = decode_movie_info(movie_info_data[poz])
                li = xbmcgui.ListItem(movie_names[poz].decode('utf-8') + movie_info, iconImage=base_filmezz + '/kiskep/' + movie_urls[poz] + '.jpg')
                file_data = movie_urls[poz] + '=spl=' + movie_names[poz] + '=spl=' + movie_info
                if file_data in watched_file_data:
                        li.setInfo( type='Video', infoLabels={ "Title": movie_names[poz].decode('utf-8') + movie_info, 'playcount': 1, 'overlay': 7})
                if addon_settings.getSetting('TMDB') == 'true' and api_key != '000' and addon_settings.getSetting('TMDBMain')=='true':
                    imdbnum = cache.get(find_imdb_num, 24, movie_urls[poz], 'movie')
                    if imdbnum:
                        fanart_info = cache.get(find_fanart, 24, imdbnum[0], 'MOVIE')
                        li.setProperty('fanart_image', fanart_info[0])
                        li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf1 = {'mode': 'main_folder', 'foldername': foldername, 'pagenum': '0', 'action': 'Ujkereses'}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)

                url_conf = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDF', 'pagenum' : pagenum}
                favourite_args = '?' + urllib.urlencode(url_conf)

                url_conf2 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDW', 'pagenum' : 'SEARCH'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)

                url_conf3 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'REMOVEW', 'pagenum' : 'SEARCH'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
				
                url_conf4 = {'mode': 'main_folder', 'foldername': 'Kereses_szimpla', 'pagenum': '0', 'action': 'none'}
                favourite_args4 = '?' + urllib.urlencode(url_conf4)

                if foldername == 'Kereses':
                    li.addContextMenuItems([ (u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
					(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
					(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])
                else:
                    li.addContextMenuItems([ (u'\xDAj keres\xE9s', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'),
					#(u'Szimpla keres\xE9s', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args4 + ')'),
					(u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
					(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
					(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                        listitem=li, isFolder=True)

        if len(movie_urls) == 0:
                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': '0', 'action': 'Ujkereses'})
                li = xbmcgui.ListItem(u'[COLOR red]>> Nincs tal\xE1lat >>[/COLOR]', iconImage=MediaDir + '\\Kereses.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                                        listitem=li, isFolder=False)

        if pagenum != '0':
                pagenum = int(pagenum)
                pagenum -= 1
                pagenum = str(pagenum)                
                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': pagenum, 'action': 'none'})
                li = xbmcgui.ListItem(u'[COLOR blue]<< El\u0151z\u0151 oldal <<[/COLOR]', iconImage=MediaDir + '\\Elozo.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                                           listitem=li, isFolder=True)   
                pagenum = int(pagenum)
                pagenum += 1
                pagenum = str(pagenum) 

        if 'Oldalak:' in url_content and 'telekkel nincs tal' not in url_content:
                pagenum = int(pagenum)
                pagenum += 1
                pagenum = str(pagenum)

                url = build_url({'mode': 'main_folder', 'foldername': foldername, 'pagenum': pagenum, 'action': 'none'})
                li = xbmcgui.ListItem(u'[COLOR green]>> K\xF6vetkez\u0151 oldal >>[/COLOR]', iconImage=MediaDir + '\\Kovetkezo.png')
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                   listitem=li, isFolder=True)   

        if args['pagenum'][0] != '0':
            xbmcplugin.endOfDirectory(addon_handle, updateListing = True)
        else:
            xbmcplugin.endOfDirectory(addon_handle, updateListing = False)	
        viewmode = setviewmode('main_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
        if action == 'Ujkereses':
                xbmc.executebuiltin('XBMC.Container.Refresh()')
        	

    elif foldername == 'Kereses_szimpla':
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        msort = int(addon_settings.getSetting('msort'))
        if search_text == '':
            search_text = open_search_panel()

        if search_text != '':
            top_url = base_filmezz + '/kereses.php?s=' + search_text.replace(' ','+') + '&w=0&o=' + str(msort) + '&q=&l=&e=&c=&t=0&h=0'

            url_content = cache.get(find_read_error, 12, top_url)
            if url_content == 'HIBA':
                return

            movie_names = re.compile('<center><b>(.+)</b>').findall(url_content)
            movie_urls = re.compile('film\.php\?n=([0-9a-zA-Z.-]+)').findall(url_content)
            movie_info_data = re.compile('qual\/([0-9]).+?([0-9])\.gif', re.DOTALL).findall(url_content)
               
            for poz in range(len(movie_urls)):
                url = build_url({'mode': 'movie_folder', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'image': movie_urls[poz]})
                movie_info = decode_movie_info(movie_info_data[poz])
                li = xbmcgui.ListItem(movie_names[poz].decode('utf-8') + movie_info, iconImage=base_filmezz + '/kiskep/' + movie_urls[poz] + '.jpg')
                file_data = movie_urls[poz] + '=spl=' + movie_names[poz] + '=spl=' + movie_info
                if file_data in watched_file_data:
                        li.setInfo( type='Video', infoLabels={ "Title": movie_names[poz].decode('utf-8') + movie_info, 'playcount': 1, 'overlay': 7})
                if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
                    imdbnum = cache.get(find_imdb_num, 24, movie_urls[poz], 'kerszimpla')
                    if imdbnum:
                        fanart_info = cache.get(find_fanart, 24, imdbnum[0], 'MOVIE')
                        li.setProperty('fanart_image', fanart_info[0])
                        li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDF', 'pagenum' : pagenum}
                favourite_args = '?' + urllib.urlencode(url_conf)

                url_conf2 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'ADDW', 'pagenum' : search_text}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)

                url_conf3 = {'mode': 'favourite', 'foldername': movie_urls[poz], 'title': movie_names[poz], 'info': movie_info, 'function': 'REMOVEW', 'pagenum' : search_text}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
                li.addContextMenuItems([ (u'Hozz\xE1ad\xE1s a MovieShark kedvencekhez', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                        listitem=li, isFolder=True)

            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcplugin.endOfDirectory(addon_handle)
        viewmode = setviewmode('main_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)		
		
    elif foldername == 'Kedvencek':
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        try:
            the_file = open(favourite_file,'r')
            for line in the_file:
                movie_data = line.split('=spl=')
                url = build_url({'mode': 'movie_folder', 'foldername': movie_data[0], 'title': movie_data[1], 'image': movie_data[0]})
                li = xbmcgui.ListItem(movie_data[1].decode('utf-8') + movie_data[2], iconImage=base_filmezz + '/kiskep/' + movie_data[0] + '.jpg')
                file_data = movie_data[0] + '=spl=' + movie_data[1] + '=spl=' + movie_data[2].replace('\n', '')
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": movie_data[1].decode('utf-8') + movie_data[2], 'playcount': 1, 'overlay': 7})
                if addon_settings.getSetting('TMDB') == 'true' and api_key != '000' and addon_settings.getSetting('TMDBMain')=='true':
                    imdbnum = cache.get(find_imdb_num, 24, movie_data[0], 'kedvencek')
                    if imdbnum:
                        fanart_info = cache.get(find_fanart, 24, imdbnum[0], 'MOVIE')
                        li.setProperty('fanart_image', fanart_info[0])
                        li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'REMOVEF', 'pagenum' : '0'}
                favourite_args = '?' + urllib.urlencode(url_conf)
            
                url_conf2 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2].replace('\n', ''), 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2].replace('\n', ''), 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)
                li.addContextMenuItems([ (u'T\xF6rles a MovieShark kedvencekb\u0151l', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
                
            the_file.close()
            xbmcplugin.endOfDirectory(addon_handle)          
        except:
            xbmcplugin.endOfDirectory(addon_handle)
        viewmode = setviewmode('main_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)


    elif foldername == 'Playlist':
        addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
        try:
            the_file = open(playlist_file,'r')
            for line in the_file:
                movie_data = line.split('=spl=')
                iconimage = base_filmezz + '/kiskep/' + movie_data[2] + '.jpg'
                url = build_url({'mode': 'playlist_play', 'foldername': movie_data[0], 'title': movie_data[1], 'image': movie_data[2].replace('\n', '')})
                li = xbmcgui.ListItem(movie_data[1].decode('utf-8').replace('#',''), iconImage=base_filmezz + '/kiskep/' + movie_data[2].replace('\n', '') + '.jpg')
                file_data = movie_data[0] + '=spl=' + movie_data[1].rpartition('#')[0] + '=spl=' + movie_data[2].replace('\n', '')
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": movie_data[1].decode('utf-8').replace('#',''), 'playcount': 1, 'overlay': 7})
                
                url_conf1 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'REMOVEP', 'pagenum' : '0'}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)
            
                url_conf2 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1].rpartition('#')[0], 'info': movie_data[2].replace('\n', ''), 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1].rpartition('#')[0], 'info': movie_data[2].replace('\n', ''), 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)

                url_conf4 = {'mode': 'favourite', 'foldername': movie_data[0], 'title': movie_data[1], 'info': movie_data[2], 'function': 'PURGEP', 'pagenum' : '0'}
                favourite_args4 = '?' + urllib.urlencode(url_conf4)

                li.addContextMenuItems([ (u'T\xF6rl\xE9s a lej\xE1tsz\xE1si list\xE1b\xF3l', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'), 
										(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
										(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')'), 
										(u'Lej\xE1tsz\xE1si lista ki\xFCr\xEDt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args4 + ')')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)
                
            the_file.close()
            xbmcplugin.endOfDirectory(addon_handle)          
        except:
            xbmcplugin.endOfDirectory(addon_handle)
        viewmode = setviewmode('movie_folder')
        if viewmode != 0:
            xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)


    elif foldername == 'Beallitasok':
        if os.path.getsize(settings_file) == os.path.getsize(settings_temp):
            os.remove(settings_file)
            shutil.copyfile(settings_orig, settings_file)
        addon_settings = xbmcaddon.Addon()
        addon_settings.openSettings()

    try:
        os.remove(search_file)
    except:
        pass
		
    return

def playlist_play(foldername, foldertitle, folderimage):
    addon_settings = xbmcaddon.Addon()
    pl=xbmc.PlayList(1)
    pl.clear()
    good = False
    the_file = open(playlist_file,'r')
    for line in the_file:
        if foldername in line or good:
            movie_data = line.split('=spl=')
            foldername = movie_data[0]
            foldertitle = movie_data[1].replace('#','')
            folderimage = base_filmezz + '/kiskep/' + movie_data[2].replace('\n','') + '.jpg'
            try:
                traktids = movie_data[3]
            except:
                traktids = 'NOTRAKT'
            if addon_settings.getSetting('TRAKT') != 'true':
                traktids = 'NOTRAKT'
            elif 'NOTRAKT' not in traktids:
                traktids = eval(traktids)
                traktids = traktids[0]
                traktids = eval(traktids)
            good = True
            direct_url = find_videourl(foldername, foldertitle, folderimage,'playlist', traktids)
            listitem = xbmcgui.ListItem(foldertitle,thumbnailImage=folderimage, )
            listitem.setInfo(type='Video', infoLabels=traktids)
            xbmc.PlayList(1).add(direct_url, listitem)

    the_file.close()
    xbmc.Player().play(pl)
    return

class NoRedirection(urllib2.HTTPErrorProcessor):
        def http_response(self, request, response):
            return response

def getLocation(url):
    opener = urllib2.build_opener(NoRedirection)
    location = opener.open(url).info().getheader('Location')
    return location

def find_videourl(foldername, foldertitle, folderimage, isdownload, traktid):
    try:
        top_url = base_filmezz + '/linkek.php?id=' + foldername
        location = cache.get(getLocation, 24, top_url)
        if location == None:
            try:
                url_content = cache.get(find_read_error, 24, top_url)
                if url_content == 'HIBA': raise Exception()
                try: location = client.parseDOM(url_content, 'iframe', ret='src')[0]
                except: location = client.parseDOM(url_content, 'IFRAME', ret='SRC')[0]
            except:
                just_removed(foldertitle)

        direct_url = msresolver.resolve(location)

        if isinstance(direct_url, basestring):
            if isdownload == 'DOWNLOAD':
                addon_settings = xbmcaddon.Addon(id='plugin.video.movieshark')
                savefolder = addon_settings.getSetting('savefolder').decode('utf-8')
        
                if savefolder == 'Nincs megadva!':
                    xbmcgui.Dialog().ok(u'Let\xF6lt\xE9si hiba', u'Meg kell adnod egy let\xF6lt\xE9si k\xF6nyvt\xE1rat a be\xE1ll\xEDt\xE1sokban!')
                    return
                from resources.lib import downloader
                try: downloader.download(foldertitle, base_filmezz + '/kiskep/' + folderimage + '.jpg', direct_url)
                except: raise Exception()
            elif isdownload == 'playlist':
                return(direct_url)
            else:
                videoitem = xbmcgui.ListItem(label=foldertitle, thumbnailImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                videoitem.setInfo(type='Video', infoLabels={'Title': foldertitle})
                if traktid != 'NOTRAKT':
                    traktid = eval(traktid)
                    videoitem.setInfo(type='Video', infoLabels=traktid)
                pl=xbmc.PlayList(1)
                pl.clear()
                xbmc.PlayList(1).add(direct_url, videoitem)
                xbmc.Player().play(pl)
        else:
            just_removed(foldertitle)
    except:
        just_removed(foldertitle)
	
def find_imdb_num(foldername, type):
    imdbnum = ''
    if type == 'playlist':
        top_url = base_filmezz + '/linkek.php?id=' + foldername
    else:
        top_url = base_filmezz + '/film.php?n=' + foldername

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return
    imdbnum = re.compile('m/title/([^/]+)').findall(url_content)
	
    return(imdbnum)

def build_movie_links(foldername, foldertitle, folderimage):    
    imdbnum = ''
    top_url = base_filmezz + '/film.php?n=' + foldername

    url_content = find_read_error(top_url)
    if url_content == 'HIBA':
        return

    movie_page = re.compile('lang/([0-9])[^/]+/qual/([0-9])[^>]+>[^0-9a-zA-Z]+([^ |\.]+)[\s\S]+?<td>([^/]+)+[^\?]+\?id=([0-9]+)').findall(url_content)
    serie_info = re.compile('<td>(.?[0-9])\.').findall(url_content)
    fanart_info = [' ',' ','0',' ']
    youtube_id = re.compile('www\.youtube\.com/watch\?v=([^"]+)').findall(url_content)
    imdbnum = re.compile('m/title/([^/]+)').findall(url_content)
         
    addon_settings = xbmcaddon.Addon()
    hostDict = getConstants()

    if serie_info and 'epiz' in url_content:
        if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
            if imdbnum:
                 fanart_info = cache.get(find_fanart, 24, imdbnum[0], 'MOVIE')

        if addon_settings.getSetting('trailer') == 'true':
            url = build_url({'mode': 'youtube_trailer', 'title': foldertitle, 'image': folderimage, 'url': youtube_id[0]})
            li = xbmcgui.ListItem('[COLOR orange]' + foldertitle.decode('utf-8') + u' EL\u0150ZETES[/COLOR]', iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            li.setProperty('fanart_image', fanart_info[0])
            li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

        if imdbnum and addon_settings.getSetting('TRAKT') == 'true':
            trakt_title = gettrakt(imdbnum)
            try:
                ttitle = trakt_title[1]
            except:
                ttitle = re.compile('([^\(]*)').findall(trakt_title[0])
                ttitle = ttitle[0].rstrip()
        else:
            traktids = 'NOTRAKT'
            ttitle = ' '

        for mopage in range(len(serie_info)):
            is_good = 'true' if (movie_page[mopage][2]).lower() in hostDict else 'false'
            if is_good == 'true':
                if imdbnum and addon_settings.getSetting('TRAKT') == 'true':
                    tseason = foldername.rpartition('-')[0][-2:].replace('-','')
                    if tseason == '':
                        tseason = '1'
                    traktids = {"imdb": imdbnum[0], "status": "Continuing", "season": tseason, "tvshowtitle": ttitle, "episode": serie_info[mopage].replace(' ','')}
                url_conf = {'mode': 'find_directurl', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'image': folderimage, 'isdownload' : ' ', 'traktid' : traktids}
                url = build_url(url_conf)
                url_conf = {'mode': 'find_directurl', 'foldername': movie_page[mopage][4], 'title': foldertitle + ' ' + serie_info[mopage], 'image': folderimage, 'isdownload' : 'DOWNLOAD', 'traktid' : traktids}
                download_args = '?' + urllib.urlencode(url_conf)
                movie_info = decode_movie_info_neg(movie_page[mopage])
                umpage3 = movie_page[mopage][3].replace('<','').decode('utf-8')
                li = xbmcgui.ListItem(foldertitle.decode('utf-8') + ' ' + serie_info[mopage] + u'. epiz\xF3d' + movie_info + ' ' + movie_page[mopage][2] + ' [COLOR cyan]' + umpage3 + '[/COLOR]' ,
                                    iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                file_data = movie_page[mopage][4] + '=spl=' + foldertitle + '=spl=' + folderimage
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": foldertitle.decode('utf-8') + folderimage, 'playcount': 1, 'overlay': 7})
                li.setProperty('fanart_image', fanart_info[0])
                li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf1 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle + '#' + serie_info[mopage] + '. epizod' + movie_info + ' ' + movie_page[mopage][2], 'info': folderimage, 'function': 'ADDP', 'pagenum' : '0', 'traktid' : traktids}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)
				
                url_conf2 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)

                li.addContextMenuItems([ (u'Vide\xF3 Let\xF6lt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + download_args + ')'), 
				(u'Hozz\xE1ad\xE1s a lej\xE1tsz\xE1si list\xE1hoz', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'), 
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')'),
				(u'Lej\xE1tsz\xF3 kiv\xE1laszt\xE1sa','Action(SwitchPlayer)')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
        #viewmode()
    else:
        if addon_settings.getSetting('TMDB') == 'true' and thisAddon.getSetting('api_key') != '000':
            if imdbnum:
                 fanart_info = cache.get(find_fanart, 24, imdbnum[0], 'MOVIE')

        if addon_settings.getSetting('trailer') == 'true':
            url = build_url({'mode': 'youtube_trailer', 'title': foldertitle, 'image': folderimage, 'url': youtube_id[0]})
            li = xbmcgui.ListItem('[COLOR orange]' + foldertitle.decode('utf-8') + u' EL\u0150ZETES[/COLOR]', iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
            li.setProperty('fanart_image', fanart_info[0])
            li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=False)

        if imdbnum and addon_settings.getSetting('TRAKT') == 'true':
            trakt_title = gettrakt(imdbnum)
            try:
                ttitle = trakt_title[1]
            except:
                ttitle = re.compile('([^(]+)').findall(trakt_title[0])
                ttitle = ttitle[0].rstrip()
            tyear = re.compile('(\([^)]+)').findall(trakt_title[0])
            tyear = tyear[0].rstrip()
            tyear = re.findall('\d+', tyear) 
            traktids = {"imdb": imdbnum[0], "status": "Continuing", "year": tyear[0], "title": ttitle}
        else:
            traktids = 'NOTRAKT'

        for mopage in range(len(movie_page)):
            is_good = 'true' if (movie_page[mopage][2]).lower() in hostDict else 'false'
            if is_good == 'true':
                url_conf = {'mode': 'find_directurl', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'image': folderimage, 'isdownload' : ' ', 'traktid' : traktids}
                url = build_url(url_conf)
                url_conf = {'mode': 'find_directurl', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'image': folderimage, 'isdownload' : 'DOWNLOAD', 'traktid' : traktids}
                download_args = '?' + urllib.urlencode(url_conf)
                movie_info = decode_movie_info_neg(movie_page[mopage])
                umpage3 = movie_page[mopage][3].replace('<','').decode('utf-8')
                li = xbmcgui.ListItem(foldertitle.decode('utf-8') + movie_info + ' ' + movie_page[mopage][2] + ' [COLOR cyan]' + umpage3 + '[/COLOR]' ,
                                    iconImage=base_filmezz + '/kiskep/' + folderimage + '.jpg')
                file_data = movie_page[mopage][4] + '=spl=' + foldertitle + '=spl=' + folderimage
                if file_data in watched_file_data:
                    li.setInfo( type='Video', infoLabels={ "Title": foldertitle.decode('utf-8') + folderimage, 'playcount': 1, 'overlay': 7})
                li.setProperty('fanart_image', fanart_info[0])
                li.setInfo('video', { 'year': int(fanart_info[2]), 'genre': fanart_info[3], 'plot': fanart_info[1] })

                url_conf1 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle + '#' + movie_info + ' ' + movie_page[mopage][2], 'info': folderimage, 'function': 'ADDP', 'pagenum' : '0', 'traktid' : traktids}
                favourite_args1 = '?' + urllib.urlencode(url_conf1)

                url_conf2 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'ADDW', 'pagenum' : '0'}
                favourite_args2 = '?' + urllib.urlencode(url_conf2)
            
                url_conf3 = {'mode': 'favourite', 'foldername': movie_page[mopage][4], 'title': foldertitle, 'info': folderimage, 'function': 'REMOVEW', 'pagenum' : '0'}
                favourite_args3 = '?' + urllib.urlencode(url_conf3)

                li.addContextMenuItems([ (u'Vide\xF3 Let\xF6lt\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + download_args + ')'), 
				(u'Hozz\xE1ad\xE1s a lej\xE1tsz\xE1si list\xE1hoz', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args1 + ')'),
				(u'Jel\xF6l\xE9s megtekintettk\xE9nt', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args2 + ')'),
				(u'Megtekintett jel\xF6l\xE9s t\xF6rl\xE9se', 'XBMC.RunScript(' + download_script + ',' + str(addon_handle) + ',' + favourite_args3 + ')'),
				(u'Lej\xE1tsz\xF3 kiv\xE1laszt\xE1sa','Action(SwitchPlayer)')])

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                        listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)

    return

def getConstants():
        try:
            try: hosts = msresolver.relevant_resolvers(order_matters=True)
            except: hosts = msresolver.plugnplay.man.implementors(msresolver.UrlResolver)
            hostDict = [i.domains for i in hosts if not '*' in i.domains]
            hostDict = [i.lower() for i in reduce(lambda x, y: x+y, hostDict)]
            hostDict += [i.name.lower() for i in hosts if not '*' in i.domains]
            hostDict = [i.split('.')[0] for i in hostDict]
            hostDict = list(set(hostDict))
        except:
            hostDict = []
        return hostDict

def build_file(foldername, foldertitle, movieinfo, function, pagenum, traktid):
    
    if function == 'ADDF' or function == 'REMOVEF' or function == 'PURGEF':
        file = favourite_file
        tmpfile = favourite_tmp
    elif function == 'ADDW' or function == 'REMOVEW' or function == 'PURGEW':
        file = watched_file
        tmpfile = watched_tmp
    elif function == 'ADDP' or function == 'REMOVEP' or function == 'PURGEP':
        file = playlist_file
        tmpfile = playlist_tmp
    elif function == 'NEWSEARCH':
        file = search_file
    else:
        return

    traktid = str(traktid)

    if function == 'ADDP':
        file_data = foldername + '=spl=' + foldertitle + '=spl=' + movieinfo + '=spl=' + traktid
    else:
        file_data = foldername + '=spl=' + foldertitle + '=spl=' + movieinfo
    file_data = file_data.replace('\n','')
    
    if (function == 'ADDW' or function == 'REMOVEW') and pagenum != '0':
        the_file = open(search_file,'w+')
        the_file.write(pagenum + '\n')
        the_file.close()

    if ('ADDF' in function and file_data not in favourite_file_data) or ('ADDW' in function and file_data not in watched_file_data) or ('ADDP' in function and file_data not in playlist_file_data):
        the_file = open(file,'a+')
        the_file.write(file_data + '\n')
        the_file.close()
        the_tmp = open(tmpfile,'a+')
        the_tmp.write(file_data + '\n')
        the_tmp.close()
        if 'ADDW' in function:
            xbmc.executebuiltin("Container.Refresh")
    elif ('REMOVEF' in function and file_data in favourite_file_data) or ('REMOVEW' in function and file_data in watched_file_data) or ('REMOVEP' in function and file_data in playlist_file_data):
        the_tmp = open(tmpfile,'r')
        the_file = open(file,'w')
        for line in the_tmp:
            if file_data not in line:
                the_file.write(line)
        the_file.close()
        the_tmp.close()

        os.remove(tmpfile)
        shutil.copyfile(file, tmpfile)
            
        xbmc.executebuiltin("Container.Refresh")
    elif function == 'NEWSEARCH' or function == 'PURGEP':
        try:
            os.remove(file)
            os.remove(tmpfile)
        except:
            the_file = open(file,'w')
            the_file.close()
            the_file = open(tmpfile,'w')
            the_file.close()
        xbmc.executebuiltin("Container.Refresh")

    return

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)
traktid = args.get('traktid', 'NOTRAKT')

try:
    the_file = open(favourite_file,'r')
    favourite_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    favourite_file_data = ''

try:
    the_file = open(watched_file,'r')
    watched_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    watched_file_data = ''

try:
    the_file = open(playlist_file,'r')
    playlist_file_data = the_file.read().replace('\n', '')
    the_file.close()
except:
    playlist_file_data = ''

if mode is None:

    build_main_directory()
    
elif mode[0] == 'main_folder':

    build_movie_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])

elif mode[0] == 'kategoriak':

    build_kategoriak_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])

elif mode[0] == 'evek':

    build_evek_directory(args['foldername'][0], args['pagenum'][0], args['action'][0])
	
elif mode[0] == 'movie_folder':

    build_movie_links(args['foldername'][0], args['title'][0], args['image'][0])

elif mode[0] == 'back_one_folder':

    xbmc.executebuiltin('Action(ParentDir)')

elif mode[0] == 'favourite':

    build_file(args['foldername'][0], args['title'][0], args['info'][0], args['function'][0], args['pagenum'][0], traktid)

elif mode[0] == 'playlist_play':
    
    playlist_play(args['foldername'][0], args['title'][0], args['image'][0])

elif mode[0] == 'youtube_trailer':
    
    decode_youtube_trailer(args['title'][0], args['image'][0], args['url'][0])

elif mode[0] == 'find_directurl':
    
    find_videourl(args['foldername'][0], args['title'][0], args['image'][0], args['isdownload'][0], args['traktid'][0])
    
elif mode[0] == 'clear_cache':
    cache.clear()
    
