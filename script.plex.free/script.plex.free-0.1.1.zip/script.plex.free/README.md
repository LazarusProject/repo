Unofficial Plex addon for Kodi

Please PR contributions against the `develop` branch.
