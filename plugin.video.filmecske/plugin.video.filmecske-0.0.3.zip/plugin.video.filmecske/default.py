# -*- coding: utf-8 -*-
import requests, xbmc, xbmcgui, urllib, re, xbmcplugin, xbmcaddon, os, msresolver

thisAddon = xbmcaddon.Addon(id='plugin.video.filmecske')
thisAddonDir = xbmc.translatePath(thisAddon.getAddonInfo('path')).decode('utf-8')
sys.path.append(os.path.join(thisAddonDir, 'resources', 'lib'))
MediaDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources', 'media')).decode('utf-8')
SettingsDir = xbmc.translatePath(os.path.join(thisAddonDir, 'resources')).decode('utf-8')
UserDataDir = xbmc.translatePath(thisAddon.getAddonInfo('profile') ).decode('utf-8')

from BeautifulSoup import BeautifulStoneSoup
from msresolver.types import HostedMediaFile
#import urlresolve

filmecske_url = 'http://www.filmecske.hu/'
supported = ["vidtome", "exashare", "youwatch", "flashxtv", "neodrive", "allvid"]
addon_handle = int(sys.argv[1])

REMOTE_DBG = False

# append pydev remote debugger
if REMOTE_DBG:
    # Make pydev debugger works for auto reload.
    # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
    try:
        sys.path.append("C:\\Users\\User\\.p2\\pool\\plugins\\org.python.pydev_4.4.0.201510052309\\pysrc")
        import pydevd # with the addon script.module.pydevd, only use `import pydevd`
    # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)
    except ImportError:
        sys.stderr.write("Error: " +
            "You must add org.python.pydev.debug.pysrc to your PYTHONPATH.")
        sys.exit(1)

def just_removed(file_host):
    addon = xbmcaddon.Addon()
    addonname = addon.getAddonInfo('name')
    line1 = 'A keresett videót eltávolították'
    xbmcgui.Dialog().ok(addonname, line1, file_host.upper())   
    return

def setviewmode(mode):
    addon_settings = xbmcaddon.Addon(id='plugin.video.filmecske')
    mainview = int(addon_settings.getSetting('mainview'))
    streamview = int(addon_settings.getSetting('streamview'))

    if mode == 'main_folder':
        if mainview == 1:
            mainview = 502
        elif mainview == 2:
            mainview = 51
        elif mainview == 3:
            mainview = 500
        elif mainview == 4:
            mainview = 501
        elif mainview == 5:
            mainview = 508
        elif mainview == 6:
            mainview = 504
        elif mainview == 7:
            mainview = 503
        elif mainview == 8:
            mainview = 515    
        else:
            mainview = 0
        return(mainview)
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %mainview)
    elif mode == 'movie_folder':
        if streamview == 1:
            streamview = 502
        elif streamview == 2:
            streamview = 51
        elif streamview == 3:
            streamview = 500
        elif streamview == 4:
            streamview = 501
        elif streamview == 5:
            streamview = 508
        elif streamview == 6:
            streamview = 504
        elif streamview == 7:
            streamview = 503
        elif streamview == 8:
            streamview = 515
        else:
            streamview = 0
        return(streamview)            
        #xbmc.executebuiltin('Container.SetViewMode(%s)' %streamview)
 
    return


def folders():

    addDir("Legújabb", 'legujabb-filmek', 2, '', '', '', 0, '')
    addDir("Legnézettebb", 'legnezettebb-filmek', 2, '', '', '', 0, '')
    addDir("Kategóriák", '', 4, '', '', '', '', '')
    addDir("Keresés", '', 5, '', '', '', '', '')
    return

def listak():
    i = requests.get(filmecske_url + url + '?start=' + str(page))
    r = re.compile('<a href="/(.+?)" title="(.+?(?=- [Oo]nline|-[Oo]nline)).+?\n.+?\n.+?src="(.+?)"').findall(i.content)
    for a, b, c in r: 
        b = BeautifulStoneSoup(b, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
        b = (b.text).encode("UTF-8")
        addDir(b, a, 3, filmecske_url + c, filmecske_url + c, '', '', '')    
    if '<a title="Utolsó"' in i.content:
        addDir('[COLOR green]Következő oldal[/COLOR]', url, 2, '', '', '', page + 50, '')
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def kategoriak():
    i = requests.get(filmecske_url)
    i = re.compile('<a href="/kategoriak/(.+?)" >(.+?)</a>').findall(i.content)
    for a, b in i:
        addDir(b, 'kategoriak/' + a, 2, '', '', '', 0, '')
    return

def kereses(search_text, page):
    i = requests.get(filmecske_url + 'film-kereso/itemlist/filterfork2?&f[g][text]=' + search_text)
    r = re.compile('href="/(.+?)" title=".+?;(.+?)..[o,O]nline.+?>\n\n.+?src="/(.+?)"').findall(i.content)
    for a, b, c in r: 
        b = BeautifulStoneSoup(b, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
        b = (b.text).encode("UTF-8")
        addDir(b, a, 3, filmecske_url + c, filmecske_url + c, '', 1, '')
    #addDir('[COLOR green]Következő oldal[/COLOR]', '', 3, '', '', '', page + 1, search_text, '', '', '','')
    viewmode = setviewmode('main_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def forrasok():
    genre = year = plot = ''
    
    i = requests.get(filmecske_url + url)
    movie_info = re.compile('<p>(.+?), ((?:(?:19|20)[0-9]{2}))').findall(i.content)
    if movie_info:
        for a, b in movie_info:
            a = BeautifulStoneSoup(a, convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
            a = (a.text).encode("UTF-8")
            genre = a
            year = b
    plot_info = movie_info = re.compile('<p>(.+?)</p>\n</div').findall(i.content)
    if plot_info:
            plot = BeautifulStoneSoup(plot_info[0], convertEntities=BeautifulStoneSoup.HTML_ENTITIES)
            plot = (plot.text).encode("UTF-8")
    #fan_art = re.compile('FullText">[\w\W]+<img src="/(images.+?.jpg).+?').findall(i.content)   
    #if fan_art: 
    #    fan_art = filmecske_url + fan_art[0]
    #else:
    fan_art = iconimage

    youtube_id = re.compile('youtube.com/embed/(.+?(?=\?|"))').findall(i.content)
    if youtube_id:
        addFile('[COLOR orange]' + name + ' - ' + 'ELŐZETES''[/COLOR]', name, youtube_id[0], '', 7, iconimage, fan_art, plot, year, genre)   
    
    hosts = re.compile('felirat" /></p>([\s\S]*?)</tbody').findall(i.content)
    hosts = re.compile('http://filmraktar.info/filmek/(.+?)".+?src=".+?(.)\.gif" alt="([a-z]*)').findall(hosts[0])
    for a, b, c in hosts:
        if c.lower().strip() in supported:    
                if b == 'K':
                    b = 'KAMERÁS'
                else:
                    b = 'DVD minőség'
                addFile('[COLOR blue]' + b + '[/COLOR]' + ' ' + 'magyar szinkron' + ' ' + '[COLOR green]' + c.upper().strip() + '[/COLOR]', name, a, c, 6, iconimage, fan_art, plot, year, genre)
    
    viewmode = setviewmode('movie_folder')
    if viewmode != 0:
        xbmc.executebuiltin('Container.SetViewMode(%s)' %viewmode)
    return

def getvideo(name, title, url, host, mode, iconimage, fanart, description):

    videoitem = xbmcgui.ListItem(label=title, thumbnailImage=iconimage)   
    videoitem.setInfo(type='Video', infoLabels={'OriginalTitle': title})
    xbmc.Player().play(getMovieSource(url, host), videoitem)
    return

def open_search_panel():
    search_text = ''
    keyb = xbmc.Keyboard('' , 'Keresés')
    keyb.doModal()
 
    if (keyb.isConfirmed()):
        search_text = keyb.getText()
        kereses(search_text, 1)
        return

def youtube_trailer():
    
    direct_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + url
    videoitem = xbmcgui.ListItem(label=title, thumbnailImage=iconimage)
    videoitem.setInfo(type='Video', infoLabels={'Title': title})
    xbmc.Player().play(direct_url, videoitem)   
    return
    
##########
def getMovieSource(url, type):

    i = requests.get('http://filmraktar.info/filmek/' + url)
    top_url = re.compile('videoWrapper.+?(?:src|SRC)(?:="|=\')(.+?)["|\']').findall(i.content)
    
    direct_url = msresolver.resolve(top_url[0])
    if direct_url != False:
        return direct_url
    
    else:
        just_removed(type)
  
##########

def addDir(name, url, mode, iconimage, fanart, description, page, category):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+str(page)+"&category="+urllib.quote_plus(category)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    xbmcplugin.setContent(addon_handle, 'movies')
    return ok

def addFile(name, title, url, host, mode, iconimage, fanart, description, year, genre):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&title="+urllib.quote_plus(title)+"&host="+urllib.quote_plus(host)+"&year="+urllib.quote_plus(year)+"&genre="+urllib.quote_plus(genre)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description, "Year": year, "Genre": genre } )
    liz.setProperty( "Fanart_Image", fanart )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    xbmcplugin.setContent(addon_handle, 'movies')
    return ok

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
fanart = None
description = None
page = -10

try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:        
    mode = int(params["mode"])
except:
    pass
try:        
    fanart = urllib.unquote_plus(params["fanart"])
except:
    pass
try:        
    description = urllib.unquote_plus(params["description"])
except:
    pass
try:        
    page = int(params["page"])
except:
    pass
try:        
    category = urllib.unquote_plus(params["category"])
except:
    pass
try:        
    title = urllib.unquote_plus(params["title"])
except:
    pass
try:        
    host = urllib.unquote_plus(params["host"])
except:
    pass
try:        
    year = urllib.unquote_plus(params["year"])
except:
    pass
try:        
    genre = urllib.unquote_plus(params["genre"])
except:
    pass

if mode==None:
    folders()
elif mode==2:
    listak()
elif mode==3:
    forrasok()
elif mode==4:
    kategoriak()
elif mode==5:
    open_search_panel()
elif mode==6:
    getvideo(name, title, url, host, mode, iconimage, fanart, description)
elif mode==7:
    youtube_trailer()
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))
